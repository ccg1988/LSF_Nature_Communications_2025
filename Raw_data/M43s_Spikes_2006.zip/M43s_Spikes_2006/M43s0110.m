function x = M43s0110()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 11:56:53';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6581;
x.unit_number = 5;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	8.0000	60.0000	5.0000	200.0000	12.0000	0.2500	1221821255.0000	2617631222.0000
	2.0000	8.0000	60.0000	5.0000	200.0000	12.0000	0.5000	1725815768.0000	2612603463.0000
	3.0000	8.0000	60.0000	5.0000	200.0000	12.0000	0.7500	1673261301.0000	935808560.0000
	4.0000	8.0000	60.0000	5.0000	200.0000	12.0000	1.0000	2958448014.0000	1515370229.0000
	5.0000	8.0000	60.0000	5.0000	200.0000	12.0000	1.2500	1589460512.0000	1352282435.0000
	6.0000	8.0000	60.0000	5.0000	200.0000	12.0000	1.5000	3150159461.0000	2236340295.0000
	7.0000	8.0000	60.0000	5.0000	200.0000	12.0000	1.7500	546874096.0000	943984989.0000
	8.0000	8.0000	60.0000	5.0000	200.0000	12.0000	2.0000	3596683195.0000	1628695174.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  12       Bandwidth  0.25, randn_seed 1221821255 2617631222'
	'Stimulus 2 : NOISE: Center Frequency  12       Bandwidth  0.5, randn_seed 1725815768 2612603463'
	'Stimulus 3 : NOISE: Center Frequency  12       Bandwidth  0.75, randn_seed 1673261301 935808560'
	'Stimulus 4 : NOISE: Center Frequency  12       Bandwidth  1, randn_seed 2958448014 1515370229'
	'Stimulus 5 : NOISE: Center Frequency  12       Bandwidth  1.25, randn_seed 1589460512 1352282435'
	'Stimulus 6 : NOISE: Center Frequency  12       Bandwidth  1.5, randn_seed 3150159461 2236340295'
	'Stimulus 7 : NOISE: Center Frequency  12       Bandwidth  1.75, randn_seed 546874096 943984989'
	'Stimulus 8 : NOISE: Center Frequency  12       Bandwidth  2, randn_seed 3596683195 1628695174'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	260039
	4	1	1	274758
	4	1	1	288938
	4	1	1	340375
	4	1	1	358754
	4	1	1	411775
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	243114
	5	1	1	252214
	5	1	1	307273
	5	1	1	544312
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	262633
	2	1	1	271272
	2	1	1	354272
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	1	244806
	8	1	1	260486
	8	1	1	272825
	8	1	1	311324
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	6	1	1	-1
	6	1	1	245683
	6	1	1	273562
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	6	2	1	-1
	6	2	1	120123
	6	2	1	242479
	6	2	1	248481
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	3	2	1	-1
	3	2	1	312618
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	8	2	1	-1
	8	2	1	273078
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	2	2	1	-1
	2	2	1	153858
	2	2	1	287456
	2	2	1	303894
	2	2	1	308756
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	1	281473
	5	2	1	304752
	5	2	1	377791
	5	2	1	394712
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	2	1	-1
	1	2	1	629546
	1	2	1	649928
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	2	1	-1
	4	2	1	244909
	4	2	1	320549
	4	2	1	355289
	4	2	1	382907
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	7	2	1	-1
	7	2	1	249650
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	7	3	1	-1
	7	3	1	46129
	7	3	1	95368
	7	3	1	245327
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	2	3	1	-1
	2	3	1	346262
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	4	3	1	-1
	4	3	1	244143
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	8	3	1	-1
	8	3	1	254599
	8	3	1	290016
	8	3	1	297317
	8	3	1	354078
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	6	3	1	-1
	6	3	1	615351
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	3	3	1	-1
	3	3	1	317573
	3	3	1	412589
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	3	4	1	-1
	3	4	1	261852
	3	4	1	278952
	3	4	1	301689
	3	4	1	336809
	3	4	1	359290
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	6	4	1	-1
	6	4	1	213249
	6	4	1	234331
	6	4	1	246770
	6	4	1	269067
	6	4	1	279630
	6	4	1	387008
	6	4	1	401387
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	1	333328
	7	4	1	349107
	7	4	1	380444
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	8	4	1	-1
	8	4	1	379684
	8	4	1	396462
	8	4	1	554581
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	4	1	-1
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	262201
	4	4	1	287401
	4	4	1	310541
	4	4	1	317740
	4	4	1	355739
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	1	378296
	5	4	1	421419
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	4	1	-1
	2	4	1	349556
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	4	5	1	-1
	4	5	1	236756
	4	5	1	246535
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	268212
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	7	5	1	-1
	7	5	1	286888
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	6	5	1	-1
	6	5	1	234565
	6	5	1	289606
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	8	5	1	-1
	8	5	1	257901
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE