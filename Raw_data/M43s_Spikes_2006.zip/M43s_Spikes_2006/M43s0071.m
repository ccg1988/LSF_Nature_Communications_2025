function x = M43s0071()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Tone Based';
x.analysis_code = 1850;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 10:20:59';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6257;
x.unit_number = 3;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' Tones Per Octave' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	1.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
	2.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
	3.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
	4.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	4.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
	5.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	5.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	70.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	901440
	1	1	1	964781
	1	1	1	1163060
	1	1	1	1536754
	1	1	1	1564674
	1	1	1	1578215
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	1440203
	2	1	1	1530020
	2	1	1	1536981
	2	1	1	1550940
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	668355
	3	1	1	1320270
	3	1	1	1422910
	3	1	1	1459328
	3	1	1	1471669
	3	1	1	1486149
	3	1	1	1530767
	3	1	1	1537567
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	798279
	4	1	1	1503554
	4	1	1	1532033
	4	1	1	1541793
	4	1	1	1552271
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	601768
	5	1	1	631227
	5	1	1	1575438
	5	1	1	1593137
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	2	1	-1
	1	2	1	779972
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	1460016
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	1	68238
	4	2	1	606193
	4	2	1	767829
	4	2	1	896989
	4	2	1	967666
	4	2	1	1332264
	4	2	1	1349686
	4	2	1	1527722
	4	2	1	1538561
	4	2	1	1573682
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	1004574
	5	2	1	1048311
	5	2	1	1357269
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	3	1	-1
	1	3	1	1541573
	1	3	1	1550934
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	1	1099562
	2	3	1	1254762
	2	3	1	1529879
	2	3	1	1532999
	2	3	1	1544078
	2	3	1	1555440
	2	3	1	1560797
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	656014
	3	3	1	792891
	3	3	1	801433
	3	3	1	940229
	3	3	1	958089
	3	3	1	1154047
	3	3	1	1521725
	3	3	1	1537284
	3	3	1	1553104
	3	3	1	1562003
	3	3	1	1642322
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	1536651
	4	3	1	1547591
	4	3	1	1563811
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	1083921
	5	3	1	1095341
	5	3	1	1522375
	5	3	1	1541874
	5	3	1	1549877
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	4	1	-1
	1	4	1	172076
	1	4	1	1174845
	1	4	1	1546320
	1	4	1	1570823
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	1527368
	2	4	1	1534108
	2	4	1	1553227
	2	4	1	1578547
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	606443
	3	4	1	644240
	3	4	1	711080
	3	4	1	758539
	3	4	1	1371616
	3	4	1	1384355
	3	4	1	1522432
	3	4	1	1532992
	3	4	1	1541673
	3	4	1	1573432
	3	4	1	1699931
	3	4	1	1720370
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	176074
	4	4	1	1164602
	4	4	1	1492340
	4	4	1	1516019
	4	4	1	1527038
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	1	574696
	5	4	1	977691
	5	4	1	1552044
	5	4	1	1558264
	5	4	1	1578723
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	1	5	1	-1
	1	5	1	586318
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	1045921
	2	5	1	1531977
	2	5	1	1548496
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	741751
	3	5	1	761488
	3	5	1	822390
	3	5	1	917628
	3	5	1	926406
	3	5	1	1085947
	3	5	1	1093407
	3	5	1	1160146
	3	5	1	1211746
	3	5	1	1458424
	3	5	1	1526363
	3	5	1	1531041
	3	5	1	1545682
	3	5	1	1558302
	3	5	1	1574460
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	1	1078931
	4	5	1	1290348
	4	5	1	1466346
	4	5	1	1512047
	4	5	1	1553507
	4	5	1	1560547
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	574744
	5	5	1	583741
	5	5	1	595400
	5	5	1	1181757
	5	5	1	1546751
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE