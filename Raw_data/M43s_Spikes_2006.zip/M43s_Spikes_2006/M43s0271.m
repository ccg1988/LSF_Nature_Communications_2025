function x = M43s0271()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '14-Jan-2006 10:41:55';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 6;
x.starting_depth = 7000;
x.first_spike = 7447;
x.unit_depth = 7507;
x.unit_number = 13;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	1.0000	1.0000	0.0000	512.0000	1.0000	20.0000
	2.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	512.0000	1.0000	20.0000
	3.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	3.0000	1.0000	0.0000	512.0000	1.0000	20.0000
	4.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	4.0000	1.0000	0.0000	512.0000	1.0000	20.0000
	5.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	5.0000	1.0000	0.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	3	1	1	-1
	3	1	1	592905
	3	1	1	599785
	3	1	1	608065
	3	1	1	624565
	3	1	1	634547
	3	1	1	650787
	3	1	1	697086
	3	1	1	713764
	3	1	1	824065
	3	1	1	872403
	3	1	1	916363
	3	1	1	1048482
	3	1	1	1143040
	3	1	1	1371239
	3	1	1	1418918
	3	1	1	1505577
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	489014
	4	1	1	571151
	4	1	1	598772
	4	1	1	603693
	4	1	1	820329
	4	1	1	832110
	4	1	1	842669
	4	1	1	851449
	4	1	1	862830
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	593458
	5	1	1	608079
	5	1	1	621738
	5	1	1	627458
	5	1	1	643517
	5	1	1	688415
	5	1	1	693858
	5	1	1	758135
	5	1	1	831736
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	668043
	2	1	1	678162
	2	1	1	778120
	2	1	1	784559
	2	1	1	794621
	2	1	1	804801
	2	1	1	816241
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	2	1	-1
	3	2	1	991311
	3	2	1	1454205
	3	2	1	1510924
	3	2	1	1521244
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	118445
	1	2	1	601320
	1	2	1	625179
	1	2	1	632060
	1	2	1	794019
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	2	1	-1
	4	2	1	728485
	4	2	1	766185
	4	2	1	831305
	4	2	1	879604
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	2	2	1	-1
	2	2	1	1051848
	2	2	1	1064648
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	4	3	1	-1
	4	3	1	253933
	4	3	1	1308744
	4	3	1	1372801
	4	3	1	1408043
	4	3	1	1412864
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	3	3	1	-1
	3	3	1	711976
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	1	3	1	-1
	1	3	1	883817
	1	3	1	1138297
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	5	3	1	-1
	5	3	1	574388
	5	3	1	583568
	5	3	1	587928
	5	3	1	602267
	5	3	1	610726
	5	3	1	622689
	5	3	1	630648
	5	3	1	647028
	5	3	1	667808
	5	3	1	809085
	5	3	1	829826
	5	3	1	945985
	5	3	1	1098084
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	4	1	-1
	1	4	1	599174
	1	4	1	684893
	1	4	1	708951
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	572239
	4	4	1	576982
	4	4	1	585481
	4	4	1	592200
	4	4	1	598979
	4	4	1	607600
	4	4	1	614601
	4	4	1	624000
	4	4	1	644580
	4	4	1	651740
	4	4	1	666638
	4	4	1	676379
	4	4	1	684639
	4	4	1	697137
	4	4	1	853257
	4	4	1	880455
	4	4	1	902478
	4	4	1	939015
	4	4	1	1088434
	4	4	1	1144177
	4	4	1	1417292
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	1	591205
	2	4	1	604445
	2	4	1	612983
	2	4	1	633324
	2	4	1	654065
	2	4	1	803923
	2	4	1	821081
	2	4	1	885300
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	1	601469
	5	4	1	616389
	5	4	1	633869
	5	4	1	651509
	5	4	1	696068
	5	4	1	703309
	5	4	1	711069
	5	4	1	863048
	5	4	1	1461983
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	3	4	1	-1
	3	4	1	600557
	3	4	1	619476
	3	4	1	660076
	3	4	1	673555
	3	4	1	678914
	3	4	1	842453
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	3	5	1	-1
	3	5	1	589782
	3	5	1	610401
	3	5	1	624482
	3	5	1	650420
	3	5	1	656362
	3	5	1	758539
	3	5	1	774102
	3	5	1	782801
	3	5	1	832098
	3	5	1	838659
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	1	5	1	-1
	1	5	1	579786
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	4	5	1	-1
	4	5	1	557272
	4	5	1	569092
	4	5	1	578513
	4	5	1	585234
	4	5	1	598573
	4	5	1	606773
	4	5	1	634473
	4	5	1	647011
	4	5	1	658033
	4	5	1	744972
	4	5	1	754070
	4	5	1	925089
	4	5	1	1096786
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	574577
	5	5	1	589438
	5	5	1	602919
	5	5	1	609138
	5	5	1	615559
	5	5	1	632557
	5	5	1	731476
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	1	584205
	2	5	1	600105
	2	5	1	617504
	2	5	1	624024
	2	5	1	662245
	2	5	1	667745
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE