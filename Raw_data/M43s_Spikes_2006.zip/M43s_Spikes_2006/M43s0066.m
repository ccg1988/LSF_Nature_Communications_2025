function x = M43s0066()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 10:12:41';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6257;
x.unit_number = 3;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	1.0000	1.0000	0.0000	0.0000	20.0000
	2.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	2.0000	1.0000	0.0000	0.0000	20.0000
	3.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	0.0000	20.0000
	4.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	4.0000	1.0000	0.0000	0.0000	20.0000
	5.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	5.0000	1.0000	0.0000	0.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	70.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	817672
	1	1	1	994952
	1	1	1	1207389
	1	1	1	1367406
	1	1	1	1422947
	1	1	1	1436206
	1	1	1	1524964
	1	1	1	1531024
	1	1	1	1546924
	1	1	1	1558045
	1	1	1	1570304
	1	1	1	1598963
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	659160
	2	1	1	1194475
	2	1	1	1518551
	2	1	1	1524631
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	72892
	3	1	1	659485
	3	1	1	729706
	3	1	1	913162
	3	1	1	951902
	3	1	1	996283
	3	1	1	1149881
	3	1	1	1164741
	3	1	1	1173880
	3	1	1	1243659
	3	1	1	1251598
	3	1	1	1352479
	3	1	1	1403897
	3	1	1	1436539
	3	1	1	1504818
	3	1	1	1525536
	3	1	1	1570995
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	822391
	4	1	1	977829
	4	1	1	1011108
	4	1	1	1031846
	4	1	1	1530682
	4	1	1	1543921
	4	1	1	1551623
	4	1	1	1568403
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	1540589
	5	1	1	1563527
	5	1	1	1573727
	5	1	1	1646788
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	2	1	-1
	1	2	1	700403
	1	2	1	707704
	1	2	1	719642
	1	2	1	864001
	1	2	1	940402
	1	2	1	952462
	1	2	1	1010681
	1	2	1	1016741
	1	2	1	1032561
	1	2	1	1202717
	1	2	1	1283377
	1	2	1	1439216
	1	2	1	1521935
	1	2	1	1531194
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	878026
	2	2	1	1518939
	2	2	1	1526460
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	688196
	3	2	1	776314
	3	2	1	795034
	3	2	1	856215
	3	2	1	877694
	3	2	1	914855
	3	2	1	1512486
	3	2	1	1538687
	3	2	1	1543626
	3	2	1	1591848
	3	2	1	1983763
	3	2	1	1990782
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	1	814100
	4	2	1	831202
	4	2	1	942379
	4	2	1	949980
	4	2	1	1114717
	4	2	1	1553853
	4	2	1	1591294
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	1514319
	5	2	1	1531240
	5	2	1	1538617
	5	2	1	1559059
	5	2	1	1567397
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	3	1	-1
	1	3	1	848054
	1	3	1	1019909
	1	3	1	1044951
	1	3	1	1548144
	1	3	1	1556726
	1	3	1	1593425
	1	3	1	1971161
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	1	216824
	2	3	1	232824
	2	3	1	243884
	2	3	1	1528792
	2	3	1	1537532
	2	3	1	1541510
	2	3	1	1549531
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	138870
	3	3	1	177710
	3	3	1	942162
	3	3	1	970942
	3	3	1	985304
	3	3	1	1094663
	3	3	1	1163260
	3	3	1	1247601
	3	3	1	1466179
	3	3	1	1509057
	3	3	1	1516338
	3	3	1	1526877
	3	3	1	1538518
	3	3	1	1548836
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	1437204
	4	3	1	1540881
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	1568491
	5	3	1	1584108
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	4	1	-1
	1	4	1	570705
	1	4	1	587686
	1	4	1	687824
	1	4	1	1220899
	1	4	1	1549318
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	938094
	3	4	1	1182613
	3	4	1	1269489
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	1	5	1	-1
	1	5	1	581697
	1	5	1	612555
	1	5	1	682374
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	1538714
	2	5	1	1544374
	2	5	1	1570093
	2	5	1	1581633
	2	5	1	1642992
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	19857
	3	5	1	659430
	3	5	1	785729
	3	5	1	825769
	3	5	1	1199803
	3	5	1	1375980
	3	5	1	1534618
	3	5	1	1543841
	3	5	1	1557300
	3	5	1	1564158
	3	5	1	1668998
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	1	937373
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	1548572
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE