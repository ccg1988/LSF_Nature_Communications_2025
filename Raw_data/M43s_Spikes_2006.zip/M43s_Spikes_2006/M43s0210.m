function x = M43s0210()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_VD_BSig';
x.analysis_code = 1580;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 11:06:11';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 7;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 7'
' Configuration File = Call_Types'
' File List Name = Call_Types_list.txt'
' File Path = d:\data_acq\xblaster2\stimulus_files\Call_Types\'
' Subset List = 39'
' Call File Name = d:\data_acq\xblaster2\stimulus_files\Call_Types\peepstrg_m87_t450aa10_034.txt'
' Number of Frequency Bands = 8'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Energy Normalization = 0'
' Display Calls = 0'
'8bands(6 bands really decomposed into):1819.83351      2844.01318      4398.03878      6756.01915      10333.8697      15762.6744           24000Hz'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 0'
' Noise Carrier = 0'
' Cosine Carrier = 0'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor = 0         0.5'
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Band Used' ' Band Used' ' Band Used' ' Band Used' ' Band Used' ' Band Used' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	2.0000	10.0000	20.0000	5.0000	899.0000	1.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	3.0000	10.0000	20.0000	5.0000	899.0000	0.0000	1.0000	0.0000	0.0000	0.0000	0.0000
	4.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	1.0000	0.0000	0.0000	0.0000
	5.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	0.0000	1.0000	0.0000	0.0000
	6.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	0.0000	0.0000	1.0000	0.0000
	7.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	0.0000	0.0000	0.0000	1.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Band Used =0  0  0  0  0  0'
	'Stimulus 2 : Band Used =1  0  0  0  0  0'
	'Stimulus 3 : Band Used =0  1  0  0  0  0'
	'Stimulus 4 : Band Used =0  0  1  0  0  0'
	'Stimulus 5 : Band Used =0  0  0  1  0  0'
	'Stimulus 6 : Band Used =0  0  0  0  1  0'
	'Stimulus 7 : Band Used =0  0  0  0  0  1'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	6	1	1	-1
	6	1	1	1067102
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	4	1	1	-1
	4	1	1	1460368
	4	1	1	1465847
	4	1	1	1473827
	4	1	1	1480426
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	1027024
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	630918
	1	1	1	704337
	1	1	1	708636
	1	1	1	733758
	1	1	1	1014694
	1	1	1	1176752
	1	1	1	1216053
	1	1	1	1350871
	1	1	1	1367952
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	7	1	1	-1
	7	1	1	1350861
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	1	2	1	-1
	1	2	1	868557
	1	2	1	892016
	1	2	1	1012533
	1	2	1	1021993
	1	2	1	1068774
	1	2	1	1071554
	1	2	1	1176234
	1	2	1	1202953
	1	2	1	1276570
	1	2	1	1371629
	1	2	1	1380852
	1	2	1	1578127
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	6	2	1	-1
	6	2	1	1269760
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	7	2	1	-1
	7	2	1	516110
	7	2	1	1498780
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	5	2	1	-1
	5	2	1	8005
	5	2	1	16946
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	4	2	1	-1
	4	2	1	260475
	4	2	1	1456301
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	1	762379
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	3	1	-1
	1	3	1	716671
	1	3	1	720270
	1	3	1	876087
	1	3	1	1032845
	1	3	1	1082087
	1	3	1	1216765
	1	3	1	1378923
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	7	3	1	-1
	7	3	1	549711
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	643451
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	281787
	5	3	1	358544
	5	3	1	1568454
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	4	1	-1
	3	4	1	456705
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	2	4	1	-1
	2	4	1	1694444
	2	4	1	1698584
	2	4	1	1827382
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	1	4	1	-1
	1	4	1	703975
	1	4	1	710735
	1	4	1	857912
	1	4	1	1021049
	1	4	1	1069290
	1	4	1	1171531
	1	4	1	1302669
	1	4	1	1311488
	1	4	1	1726505
	1	4	1	1741484
	1	4	1	1808883
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	7	4	1	-1
	7	4	1	145970
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	5	4	1	-1
	5	4	1	75260
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	1	5	1	-1
	1	5	1	150979
	1	5	1	613216
	1	5	1	618937
	1	5	1	623076
	1	5	1	702793
	1	5	1	705436
	1	5	1	848712
	1	5	1	870192
	1	5	1	946992
	1	5	1	1037512
	1	5	1	1050712
	1	5	1	1100411
	1	5	1	1274208
	1	5	1	1379009
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	5	5	1	-1
	5	5	1	150090
	5	5	1	187770
	5	5	1	229309
	5	5	1	232309
	5	5	1	387827
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	1	988931
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	7	5	1	-1
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	6	5	1	-1
	6	5	1	375440
	6	5	1	897374
	6	5	1	1022192
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	4	5	1	-1
	4	5	1	111973
	4	5	1	1201880
	4	5	1	1450619
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	3	5	1	-1
	3	5	1	131781
	3	5	1	138501
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE