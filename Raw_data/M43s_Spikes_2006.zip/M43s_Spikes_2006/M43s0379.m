function x = M43s0379()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '19-Jan-2006 11:40:35';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 3;
x.starting_depth = 8000;
x.first_spike = 8473;
x.unit_depth = 8900;
x.unit_number = 18;
x.cf = 7.5000;
x.threshold = 60.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
' End Frequency (Hz) = 24000'
' Energy Normalization = 0'
' Display Calls = 0'
'16bands(12 bands really decomposed into):1819.83351      2278.73602      2844.01318      3540.32289      4398.03878      5454.57518      6756.01915       8359.1408      10333.8697      12766.3454      15762.6744      19453.5594           24000Hz'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 0'
' Noise Carrier = 0'
' Cosine Carrier = 0'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor = 0         0.5'
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	5.0000	200.0000	4.3000	0.2500	4286422971.0000	1896752847.0000
	2.0000	2.0000	30.0000	5.0000	200.0000	4.3000	0.5000	3893768905.0000	1259344613.0000
	3.0000	2.0000	30.0000	5.0000	200.0000	4.3000	0.7500	392482619.0000	714586909.0000
	4.0000	2.0000	30.0000	5.0000	200.0000	4.3000	1.0000	727045647.0000	897103577.0000
	5.0000	2.0000	30.0000	5.0000	200.0000	4.3000	1.2500	3973666410.0000	1733879138.0000
	6.0000	2.0000	30.0000	5.0000	200.0000	4.3000	1.5000	2194011557.0000	1097814759.0000
	7.0000	2.0000	30.0000	5.0000	200.0000	4.3000	1.7500	4171998180.0000	3040683331.0000
	8.0000	2.0000	30.0000	5.0000	200.0000	4.3000	2.0000	4089602004.0000	1705615013.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  4.3       Bandwidth  0.25, randn_seed 4286422971 1896752847'
	'Stimulus 2 : NOISE: Center Frequency  4.3       Bandwidth  0.5, randn_seed 3893768905 1259344613'
	'Stimulus 3 : NOISE: Center Frequency  4.3       Bandwidth  0.75, randn_seed 392482619 714586909'
	'Stimulus 4 : NOISE: Center Frequency  4.3       Bandwidth  1, randn_seed 727045647 897103577'
	'Stimulus 5 : NOISE: Center Frequency  4.3       Bandwidth  1.25, randn_seed 3973666410 1733879138'
	'Stimulus 6 : NOISE: Center Frequency  4.3       Bandwidth  1.5, randn_seed 2194011557 1097814759'
	'Stimulus 7 : NOISE: Center Frequency  4.3       Bandwidth  1.75, randn_seed 4171998180 3040683331'
	'Stimulus 8 : NOISE: Center Frequency  4.3       Bandwidth  2, randn_seed 4089602004 1705615013'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	393321
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	5	1	1	-1
	5	1	1	282580
	5	1	1	333519
	5	1	1	360518
	5	1	1	388098
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	1	1	-1
	1	1	1	220776
	1	1	1	247617
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	7	1	1	-1
	7	1	1	226875
	7	1	1	243233
	7	1	1	337975
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	2	1	1	-1
	2	1	1	252050
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	336227
	3	1	1	365409
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	6	2	1	-1
	6	2	1	216848
	6	2	1	219428
	6	2	1	233788
	6	2	1	247507
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	5	2	1	-1
	5	2	1	219667
	5	2	1	230305
	5	2	1	244924
	5	2	1	271604
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	3	2	1	-1
	3	2	1	242503
	3	2	1	244443
	3	2	1	245943
	3	2	1	248122
	3	2	1	353802
	3	2	1	355242
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	2	1	-1
	2	2	1	250040
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	237240
	1	2	1	244459
	1	2	1	245839
	1	2	1	254758
	1	2	1	256099
	1	2	1	257678
	1	2	1	349838
	1	2	1	381036
	1	2	1	398035
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	7	2	1	-1
	7	2	1	223554
	7	2	1	229596
	7	2	1	243236
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	4	2	1	-1
	4	2	1	216655
	4	2	1	222293
	4	2	1	257034
	4	2	1	387532
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	1	3	1	-1
	1	3	1	202569
	1	3	1	239170
	1	3	1	242811
	1	3	1	246290
	1	3	1	247630
	1	3	1	257350
	1	3	1	258770
	1	3	1	360429
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	1	216569
	6	3	1	226248
	6	3	1	233248
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	7	3	1	-1
	7	3	1	227865
	7	3	1	240186
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	4	3	1	-1
	4	3	1	217724
	4	3	1	229802
	4	3	1	249004
	4	3	1	384402
	4	3	1	405961
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	2	3	1	-1
	2	3	1	217261
	2	3	1	242900
	2	3	1	244380
	2	3	1	279260
	2	3	1	322141
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	235678
	3	3	1	251899
	3	3	1	353379
	3	3	1	387757
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	5	3	1	-1
	5	3	1	251916
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	5	4	1	-1
	5	4	1	217095
	5	4	1	243375
	5	4	1	272252
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	3	4	1	-1
	3	4	1	242453
	3	4	1	282452
	3	4	1	364712
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	2	4	1	-1
	2	4	1	233230
	2	4	1	235931
	2	4	1	359147
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	4	1	-1
	1	4	1	238065
	1	4	1	259026
	1	4	1	281425
	1	4	1	282886
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	221084
	4	4	1	228623
	4	4	1	246963
	4	4	1	248562
	4	4	1	360363
	4	4	1	361941
	4	4	1	383543
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	6	4	1	-1
	6	4	1	215622
	6	4	1	257880
	6	4	1	365660
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	2	5	1	-1
	2	5	1	215838
	2	5	1	252736
	2	5	1	268698
	2	5	1	332677
	2	5	1	335556
	2	5	1	346136
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	6	5	1	-1
	6	5	1	216338
	6	5	1	218835
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	3	5	1	-1
	3	5	1	273813
	3	5	1	352631
	3	5	1	413092
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	7	5	1	-1
	7	5	1	219993
	7	5	1	233750
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	1	5	1	-1
	1	5	1	287248
	1	5	1	291570
	1	5	1	293049
	1	5	1	294868
	1	5	1	385246
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	5	5	1	-1
	5	5	1	224986
	5	5	1	231787
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	4	5	1	-1
	4	5	1	3966
	4	5	1	216765
	4	5	1	227404
	4	5	1	228927
	4	5	1	230405
	4	5	1	233163
	4	5	1	326004
	4	5	1	381404
	4	5	1	383343
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE