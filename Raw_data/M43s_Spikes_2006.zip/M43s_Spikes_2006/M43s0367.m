function x = M43s0367()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M43s';
x.datetime = '19-Jan-2006 11:14:43';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 3;
x.starting_depth = 8000;
x.first_spike = 8473;
x.unit_depth = 8900;
x.unit_number = 18;
x.cf = 7.5000;
x.threshold = 60.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Energy Normalization = 0'
' Display Calls = 0'
'16bands(12 bands really decomposed into):1819.83351      2278.73602      2844.01318      3540.32289      4398.03878      5454.57518      6756.01915       8359.1408      10333.8697      12766.3454      15762.6744      19453.5594           24000Hz'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 0'
' Noise Carrier = 0'
' Cosine Carrier = 0'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor = 0         0.5'
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	2.0000	3.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	3.0000	4.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	4.0000	5.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	5.0000	6.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	6.0000	7.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	7.0000	8.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	8.0000	9.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	9.0000	10.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	10.0000	11.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	11.0000	12.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	12.0000	13.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	13.0000	14.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	14.0000	15.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
	15.0000	16.0000	30.0000	5.0000	200.0000	8.2800	0.2500	3627863775.0000	493551298.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 2 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 3 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 4 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 5 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 6 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 7 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 8 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 9 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 10 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 11 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 12 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 13 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 14 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
	'Stimulus 15 : NOISE: Center Frequency  8.28       Bandwidth  0.25, randn_seed 3627863775 493551298'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	6.00	7.00	8.00	9.00	10.00	11.00	12.00	13.00	14.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	14	1	1	-1
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	4	1	1	-1
	4	1	1	412456
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	96576
	3	1	1	98294
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	12	1	1	-1
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	9	1	1	-1
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	10	1	1	-1
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	11	1	1	-1
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	15	1	1	-1
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	8	1	1	-1
	8	1	1	687485
	8	1	1	689187
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	9	2	1	-1
	9	2	1	400165
	9	2	1	665763
	9	2	1	668822
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	11	2	1	-1
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	15	2	1	-1
	15	2	2	-1
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	10	2	1	-1
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	6	2	1	-1
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	14	2	1	-1
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	13	2	1	-1
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	15	3	1	-1
	15	3	2	-1
	15	3	3	-1
	15	3	4	-1
	15	3	5	-1
	15	3	6	-1
	15	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	9	3	1	-1
	9	3	1	343755
	9	3	1	345495
	9	3	1	518675
	9	3	1	624312
	9	3	2	-1
	9	3	3	-1
	9	3	4	-1
	9	3	5	-1
	9	3	6	-1
	9	3	7	-1
	7	3	1	-1
	7	3	1	651611
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	5	3	1	-1
	5	3	1	109514
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	8	3	1	-1
	8	3	1	49973
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	13	3	1	-1
	13	3	2	-1
	13	3	3	-1
	13	3	4	-1
	13	3	5	-1
	13	3	6	-1
	13	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	11	3	1	-1
	11	3	1	263495
	11	3	2	-1
	11	3	3	-1
	11	3	4	-1
	11	3	5	-1
	11	3	6	-1
	11	3	7	-1
	12	3	1	-1
	12	3	2	-1
	12	3	3	-1
	12	3	4	-1
	12	3	5	-1
	12	3	6	-1
	12	3	7	-1
	4	3	1	-1
	4	3	1	529447
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	14	3	1	-1
	14	3	2	-1
	14	3	3	-1
	14	3	4	-1
	14	3	5	-1
	14	3	6	-1
	14	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	10	3	1	-1
	10	3	1	401920
	10	3	2	-1
	10	3	3	-1
	10	3	4	-1
	10	3	5	-1
	10	3	6	-1
	10	3	7	-1
	9	4	1	-1
	9	4	2	-1
	9	4	3	-1
	9	4	4	-1
	9	4	5	-1
	9	4	6	-1
	9	4	7	-1
	14	4	1	-1
	14	4	2	-1
	14	4	3	-1
	14	4	4	-1
	14	4	5	-1
	14	4	6	-1
	14	4	7	-1
	6	4	1	-1
	6	4	1	494453
	6	4	1	528534
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	13	4	1	-1
	13	4	2	-1
	13	4	3	-1
	13	4	4	-1
	13	4	5	-1
	13	4	6	-1
	13	4	7	-1
	10	4	1	-1
	10	4	2	-1
	10	4	3	-1
	10	4	4	-1
	10	4	5	-1
	10	4	6	-1
	10	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	15	4	1	-1
	15	4	2	-1
	15	4	3	-1
	15	4	4	-1
	15	4	5	-1
	15	4	6	-1
	15	4	7	-1
	12	4	1	-1
	12	4	2	-1
	12	4	3	-1
	12	4	4	-1
	12	4	5	-1
	12	4	6	-1
	12	4	7	-1
	3	4	1	-1
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	11	4	1	-1
	11	4	1	252140
	11	4	2	-1
	11	4	3	-1
	11	4	4	-1
	11	4	5	-1
	11	4	6	-1
	11	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	4	1	-1
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE