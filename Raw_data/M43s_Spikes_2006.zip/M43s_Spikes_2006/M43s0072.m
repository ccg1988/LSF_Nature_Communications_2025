function x = M43s0072()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Tone Based';
x.analysis_code = 1850;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 10:22:11';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6257;
x.unit_number = 3;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' Tones Per Octave' ' AM Frequency Hz' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	1.0000	1.0000	0.0000	20.0000	0.0000	20.0000
	2.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	0.0000	20.0000
	3.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	20.0000	0.0000	20.0000
	4.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	4.0000	1.0000	0.0000	20.0000	0.0000	20.0000
	5.0000	2.0000	70.0000	5.0000	1000.0000	0.0000	8900.0000	1.0000	5.0000	1.0000	0.0000	20.0000	0.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	70.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	760695
	1	1	1	773275
	1	1	1	1035952
	1	1	1	1054612
	1	1	1	1340129
	1	1	1	1505449
	1	1	1	1521928
	1	1	1	1736323
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	1527154
	2	1	1	1534811
	2	1	1	1551331
	2	1	1	1564992
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	620068
	3	1	1	742127
	3	1	1	1525078
	3	1	1	1537738
	3	1	1	1564616
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	1542785
	4	1	1	1547463
	4	1	1	1557804
	4	1	1	1573805
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	1533450
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	2	1	-1
	1	2	1	568944
	1	2	1	587665
	1	2	1	672642
	1	2	1	753342
	1	2	1	805442
	1	2	1	848342
	1	2	1	950120
	1	2	1	957000
	1	2	1	1247717
	1	2	1	1508114
	1	2	1	1536716
	1	2	1	1569153
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	1570880
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	688934
	3	2	1	766334
	3	2	1	908775
	3	2	1	1525627
	3	2	1	1538026
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	1	1528333
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	3	1	-1
	1	3	1	662672
	1	3	1	763752
	1	3	1	923349
	1	3	1	932710
	1	3	1	1084488
	1	3	1	1524844
	1	3	1	1539423
	1	3	1	1570884
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	1	1523851
	2	3	1	1529951
	2	3	1	1539991
	2	3	1	1555288
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	601224
	3	3	1	752704
	3	3	1	832582
	3	3	1	1540254
	3	3	1	1553255
	3	3	1	1618253
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	1531508
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	4	1	-1
	1	4	1	662741
	1	4	1	772121
	1	4	1	1260736
	1	4	1	1530793
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	1535039
	2	4	1	1598397
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	1173207
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	751479
	4	4	1	955937
	4	4	1	963935
	4	4	1	1244512
	4	4	1	1255175
	4	4	1	1532729
	4	4	1	1540490
	4	4	1	1552552
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	1	1542614
	5	4	1	1555976
	5	4	1	1575014
	5	4	1	1682293
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	1	5	1	-1
	1	5	1	600372
	1	5	1	690450
	1	5	1	786370
	1	5	1	903949
	1	5	1	1030646
	1	5	1	1042007
	1	5	1	1528101
	1	5	1	1543480
	1	5	1	1571401
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	753434
	2	5	1	1043033
	2	5	1	1528066
	2	5	1	1540707
	2	5	1	1595946
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	706263
	3	5	1	837100
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	896990
	5	5	1	1539624
	5	5	1	1559424
	5	5	1	1633023
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE