function x = M43s0117()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 12:08:29';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6581;
x.unit_number = 5;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	8.0000	60.0000	5.0000	1000.0000	1.0000	12000.0000	1.0000	1.0000	1.0000	0.0000	0.0000	20.0000
	2.0000	8.0000	60.0000	5.0000	1000.0000	1.0000	12000.0000	1.0000	2.0000	1.0000	0.0000	0.0000	20.0000
	3.0000	8.0000	60.0000	5.0000	1000.0000	1.0000	12000.0000	1.0000	3.0000	1.0000	0.0000	0.0000	20.0000
	4.0000	8.0000	60.0000	5.0000	1000.0000	1.0000	12000.0000	1.0000	4.0000	1.0000	0.0000	0.0000	20.0000
	5.0000	8.0000	60.0000	5.0000	1000.0000	1.0000	12000.0000	1.0000	5.0000	1.0000	0.0000	0.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12000 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12000 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12000 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12000 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12000 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	618123
	1	1	1	630043
	1	1	1	669581
	1	1	1	679221
	1	1	1	695001
	1	1	1	729360
	1	1	1	741841
	1	1	1	790681
	1	1	1	804303
	1	1	1	883420
	1	1	1	897080
	1	1	1	903359
	1	1	1	1004119
	1	1	1	1013859
	1	1	1	1131498
	1	1	1	1164558
	1	1	1	1285414
	1	1	1	1290996
	1	1	1	1413753
	1	1	1	1600791
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	1	1	-1
	4	1	1	610007
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	566692
	5	1	1	594274
	5	1	1	602411
	5	1	1	618452
	5	1	1	625532
	5	1	1	639632
	5	1	1	835089
	5	1	1	1363204
	5	1	1	1472884
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	3	1	1	-1
	3	1	1	553456
	3	1	1	570118
	3	1	1	578436
	3	1	1	592317
	3	1	1	599877
	3	1	1	611798
	3	1	1	619737
	3	1	1	1726506
	3	1	1	1787025
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	4	1785995
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	1	1	-1
	2	1	1	729040
	2	1	1	912178
	2	1	1	944679
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	2	1	-1
	4	2	1	560727
	4	2	1	588949
	4	2	1	609528
	4	2	1	622846
	4	2	1	632187
	4	2	1	905325
	4	2	1	987383
	4	2	1	1012344
	4	2	1	1017922
	4	2	1	1530879
	4	2	1	1952334
	4	2	1	1994532
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	2	1	-1
	2	2	1	491479
	2	2	1	560699
	2	2	1	667180
	2	2	1	702678
	2	2	1	884535
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	2	1	-1
	1	2	1	626690
	1	2	1	633627
	1	2	1	1439980
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	4	625639
	1	2	4	1438914
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	3	1	-1
	4	3	1	568273
	4	3	1	594654
	4	3	1	604695
	4	3	1	630374
	4	3	1	640174
	4	3	1	712193
	4	3	1	733995
	4	3	1	809951
	4	3	1	876512
	4	3	1	996231
	4	3	1	1033671
	4	3	1	1294426
	4	3	1	1643583
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	4	995130
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	326964
	5	3	1	338942
	5	3	1	746978
	5	3	1	1383671
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	2	3	1	-1
	2	3	1	1064799
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	1	3	1	-1
	1	3	1	691129
	1	3	1	716630
	1	3	1	974786
	1	3	1	1810998
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	3	3	1	-1
	3	3	1	717196
	3	3	1	784352
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	3	4	1	-1
	3	4	1	599943
	3	4	1	617900
	3	4	1	754801
	3	4	1	777939
	3	4	1	819120
	3	4	1	828857
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	4	1	-1
	5	4	1	551848
	5	4	1	597788
	5	4	1	854924
	5	4	1	1134460
	5	4	1	1177501
	5	4	1	1186141
	5	4	1	1197020
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	4	1	-1
	2	4	1	617791
	2	4	1	634170
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	4	616721
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	1	4	1	-1
	1	4	1	605757
	1	4	1	682196
	1	4	1	906553
	1	4	1	927114
	1	4	1	1167572
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	580063
	4	4	1	585804
	4	4	1	594502
	4	4	1	602621
	4	4	1	612865
	4	4	1	618863
	4	4	1	629503
	4	4	1	640821
	4	4	1	662803
	4	4	1	763622
	4	4	1	796321
	4	4	1	841759
	4	4	1	1464173
	4	4	1	1484234
	4	4	1	1502353
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	5	1	-1
	5	5	1	989023
	5	5	1	1084642
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	4	5	1	-1
	4	5	1	634731
	4	5	1	768570
	4	5	1	1014108
	4	5	1	1079827
	4	5	1	1252725
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	3	5	1	-1
	3	5	1	785736
	3	5	1	1028892
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	1	5	1	-1
	1	5	1	825182
	1	5	1	1022359
	1	5	1	1042818
	1	5	1	1324836
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	1450801
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE