function x = M43s0209()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_VD_BSig';
x.analysis_code = 1580;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 11:04:45';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 4;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 4'
' Configuration File = Call_Types'
' File List Name = Call_Types_list.txt'
' File Path = d:\data_acq\xblaster2\stimulus_files\Call_Types\'
' Subset List = 39'
' Call File Name = d:\data_acq\xblaster2\stimulus_files\Call_Types\peepstrg_m87_t450aa10_034.txt'
' Number of Frequency Bands = 4'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Energy Normalization = 0'
' Display Calls = 0'
'4bands(3 bands really decomposed into):1819.83351      4398.03878      10333.8697           24000Hz'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 0'
' Noise Carrier = 0'
' Cosine Carrier = 0'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor = 0         0.5'
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Band Used' ' Band Used' ' Band Used' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	0.0000
	2.0000	10.0000	20.0000	5.0000	899.0000	1.0000	0.0000	0.0000
	3.0000	10.0000	20.0000	5.0000	899.0000	0.0000	1.0000	0.0000
	4.0000	10.0000	20.0000	5.0000	899.0000	0.0000	0.0000	1.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Band Used =0  0  0'
	'Stimulus 2 : Band Used =1  0  0'
	'Stimulus 3 : Band Used =0  1  0'
	'Stimulus 4 : Band Used =0  0  1'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	636402
	1	1	1	708583
	1	1	1	855341
	1	1	1	902700
	1	1	1	1071978
	1	1	1	1108819
	1	1	1	1173998
	1	1	1	1188617
	1	1	1	1260738
	1	1	1	1351157
	1	1	1	1368837
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	1437105
	2	1	1	1446246
	2	1	1	1734463
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	1	1	-1
	4	1	1	1763172
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	46681
	1	2	1	72321
	1	2	1	131380
	1	2	1	715155
	1	2	1	719077
	1	2	1	765853
	1	2	1	862075
	1	2	1	865952
	1	2	1	876233
	1	2	1	935673
	1	2	1	1023572
	1	2	1	1063010
	1	2	1	1086111
	1	2	1	1169609
	1	2	1	1178510
	1	2	1	1195169
	1	2	1	1200548
	1	2	1	1260849
	1	2	1	1365787
	1	2	1	1380889
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	765804
	2	2	1	794685
	2	2	1	942083
	2	2	1	945923
	2	2	1	1021923
	2	2	1	1179259
	2	2	1	1472896
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	4	2	1	-1
	4	2	1	236781
	4	2	1	748534
	4	2	1	1029693
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	4	3	1	-1
	4	3	1	1248898
	4	3	1	1346218
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	2	3	1	-1
	2	3	1	103222
	2	3	1	216221
	2	3	1	223721
	2	3	1	231421
	2	3	1	360059
	2	3	1	365081
	2	3	1	380819
	2	3	1	385538
	2	3	1	1664905
	2	3	1	1680566
	2	3	1	1683265
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	268849
	3	3	1	274270
	3	3	1	290748
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	1	3	1	-1
	1	3	1	718854
	1	3	1	732877
	1	3	1	853775
	1	3	1	1172550
	1	3	1	1190050
	1	3	1	1255030
	1	3	1	1280691
	1	3	1	1369029
	1	3	1	1387769
	1	3	1	1807125
	1	3	1	1812824
	1	3	1	1869624
	1	3	1	1896644
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	1	4	1	-1
	1	4	1	856523
	1	4	1	877042
	1	4	1	893383
	1	4	1	931263
	1	4	1	1024583
	1	4	1	1053381
	1	4	1	1089122
	1	4	1	1092161
	1	4	1	1116140
	1	4	1	1184222
	1	4	1	1206681
	1	4	1	1262020
	1	4	1	1266159
	1	4	1	1350979
	1	4	1	1358397
	1	4	1	1363998
	1	4	1	1375397
	1	4	1	1382239
	1	4	1	1625337
	1	4	1	1628537
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	3	4	1	-1
	3	4	1	7021
	3	4	1	109181
	3	4	1	1674164
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	451828
	4	4	1	1368658
	4	4	1	1592755
	4	4	1	1759133
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	1	238160
	2	4	1	386958
	2	4	1	390598
	2	4	1	532436
	2	4	1	538717
	2	4	1	542856
	2	4	1	710395
	2	4	1	1771285
	2	4	1	1777783
	2	4	1	1866482
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	2	5	1	-1
	2	5	1	1346420
	2	5	1	1761832
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	1	5	1	-1
	1	5	1	167540
	1	5	1	174740
	1	5	1	183240
	1	5	1	187020
	1	5	1	304279
	1	5	1	720414
	1	5	1	1170411
	1	5	1	1191891
	1	5	1	1227570
	1	5	1	1235108
	1	5	1	1241890
	1	5	1	1273268
	1	5	1	1345769
	1	5	1	1349669
	1	5	1	1367027
	1	5	1	1370809
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	4	5	1	-1
	4	5	1	1177541
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE