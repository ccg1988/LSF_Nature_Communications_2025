function x = M43s0041()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '10-Jan-2006 13:22:49';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 1;
x.starting_depth = 6000;
x.first_spike = 6167;
x.unit_depth = 6485;
x.unit_number = 2;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	5.0000	20.0000	5.0000	200.0000	6.0000	0.2500	1964018561.0000	2705347576.0000
	2.0000	5.0000	20.0000	5.0000	200.0000	6.0000	0.5000	1165122068.0000	163300807.0000
	3.0000	5.0000	20.0000	5.0000	200.0000	6.0000	1.0000	4286422971.0000	1896752847.0000
	4.0000	5.0000	20.0000	5.0000	200.0000	6.0000	2.0000	3893768905.0000	1259344613.0000
	5.0000	5.0000	20.0000	5.0000	200.0000	6.0000	4.0000	392482619.0000	714586909.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  6       Bandwidth  0.25, randn_seed 1964018561 2705347576'
	'Stimulus 2 : NOISE: Center Frequency  6       Bandwidth  0.5, randn_seed 1165122068 163300807'
	'Stimulus 3 : NOISE: Center Frequency  6       Bandwidth  1, randn_seed 4286422971 1896752847'
	'Stimulus 4 : NOISE: Center Frequency  6       Bandwidth  2, randn_seed 3893768905 1259344613'
	'Stimulus 5 : NOISE: Center Frequency  6       Bandwidth  4, randn_seed 392482619 714586909'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	5.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	143507
	1	1	1	290343
	1	1	1	296824
	1	1	1	341344
	1	1	1	380083
	1	1	1	410003
	1	1	1	414363
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	23183
	3	1	1	41262
	3	1	1	301761
	3	1	1	355898
	3	1	1	369378
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	1	1	-1
	2	1	1	4282
	2	1	1	321797
	2	1	1	330218
	2	1	1	384917
	2	1	1	392538
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	3	2	1	-1
	3	2	1	26360
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	2	1	-1
	2	2	1	5897
	2	2	1	47237
	2	2	1	100274
	2	2	1	267014
	2	2	1	323811
	2	2	1	380293
	2	2	1	478972
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	361711
	1	2	1	390510
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	4	2	1	-1
	4	2	1	669882
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	1	3	1	-1
	1	3	1	86568
	1	3	1	117767
	1	3	1	143025
	1	3	1	299726
	1	3	1	360345
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	1	277304
	2	3	1	325103
	2	3	1	332200
	2	3	1	365100
	2	3	1	385300
	2	3	1	393321
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	367858
	3	3	1	374300
	3	3	1	479937
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	5	3	1	-1
	5	3	1	60301
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	2	4	1	-1
	2	4	1	221517
	2	4	1	285237
	2	4	1	314074
	2	4	1	320496
	2	4	1	335454
	2	4	1	368055
	2	4	1	371715
	2	4	1	374515
	2	4	1	378574
	2	4	1	399073
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	1	4	1	-1
	1	4	1	110732
	1	4	1	313229
	1	4	1	349491
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	5	4	1	-1
	5	4	1	7430
	5	4	1	191549
	5	4	1	212671
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	1	5190
	4	4	1	9950
	4	4	1	23288
	4	4	1	33371
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	3	5	1	-1
	3	5	1	153205
	3	5	1	358425
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	5	5	1	-1
	5	5	1	63566
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	1	325280
	2	5	1	381142
	2	5	1	383780
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	1	5	1	-1
	1	5	1	378598
	1	5	1	410457
	1	5	1	684094
	1	5	1	689996
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE