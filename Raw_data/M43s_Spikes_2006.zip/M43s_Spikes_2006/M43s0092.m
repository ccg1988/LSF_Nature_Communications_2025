function x = M43s0092()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 11:13:27';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6380;
x.unit_number = 4;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	2.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	8.0000	1.0000	20.0000
	3.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	4.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	32.0000	1.0000	20.0000
	5.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	64.0000	1.0000	20.0000
	6.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	128.0000	1.0000	20.0000
	7.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	256.0000	1.0000	20.0000
	8.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	0.0000	1.0000	0.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 8 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 32 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 64 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 6 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 128 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 7 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 256 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 8 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 0 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	648740
	1	1	1	663599
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	426848
	2	1	1	435126
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	1463904
	3	1	1	1761160
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	7	1	1	-1
	7	1	1	303435
	7	1	1	1525503
	7	1	1	1542284
	7	1	1	1554161
	7	1	1	1641883
	7	1	1	1655902
	7	1	1	1668603
	7	1	1	1725400
	7	1	1	1803822
	7	1	1	1808582
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	1	574120
	8	1	1	649057
	8	1	1	1521088
	8	1	1	1534850
	8	1	1	1542989
	8	1	1	1584147
	8	1	1	1671787
	8	1	1	1685028
	8	1	1	1722286
	8	1	1	1731307
	8	1	1	1748367
	8	1	1	1939185
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	1	2	1	-1
	1	2	1	1626512
	1	2	1	1854671
	1	2	1	1864431
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	136854
	2	2	1	1085903
	2	2	1	1395560
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	1054809
	3	2	1	1876402
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	1	1704669
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	486486
	5	2	1	524006
	5	2	1	541885
	5	2	1	553407
	5	2	1	563686
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	6	2	1	-1
	6	2	1	227054
	6	2	1	1920656
	6	2	1	1930378
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	7	2	1	-1
	7	2	1	37883
	7	2	1	49340
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	8	2	1	-1
	8	2	1	225946
	8	2	1	236406
	8	2	1	308906
	8	2	1	325084
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	7	3	1	-1
	7	3	1	910795
	7	3	1	921995
	7	3	1	936474
	7	3	1	1121714
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	1	4	1	-1
	1	4	1	606888
	1	4	1	615949
	1	4	1	909045
	1	4	1	923185
	1	4	1	932385
	1	4	1	1188802
	1	4	1	1203304
	1	4	1	1715978
	1	4	1	1827797
	1	4	1	1854236
	1	4	1	1864436
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	312818
	2	4	1	380576
	2	4	1	1553046
	2	4	1	1642545
	2	4	1	1759122
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	8344
	3	4	1	87846
	3	4	1	103184
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	660604
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	6	4	1	-1
	6	4	1	1799724
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	99390
	3	5	1	420865
	3	5	1	499725
	3	5	1	649442
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	518476
	5	5	1	1953360
	5	5	1	1969521
	5	5	1	1976320
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	7	5	1	-1
	7	5	1	1541295
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	8	5	1	-1
	8	5	1	1617182
	8	5	1	1918300
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE