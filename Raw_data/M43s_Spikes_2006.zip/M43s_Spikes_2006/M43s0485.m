function x = M43s0485()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'Voc_Decom: Original Envelope';
x.analysis_code = 1401;
x.animal = 'M43s';
x.datetime = '22-Jan-2006 15:44:34';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 6;
x.starting_depth = 10000;
x.first_spike = 10698;
x.unit_depth = 11291;
x.unit_number = 22;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 13;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 13'
' Configuration File = Call_Types'
' File List Name = Call_Types_list.txt'
' File Path = d:\data_acq\xblaster2\stimulus_files\Call_Types\'
' Subset List = 15'
' Call File Name = d:\data_acq\xblaster2\stimulus_files\Call_Types\peeptril_m87_t450da10_182.txt'
' Number of Frequency Bands = 4   8  16  32'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Processing Method = Envelope/Fine Structure Processing'
' Original Envelope = 1'
' Flat Envelope = 0'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 1'
' Noise Carrier = 1'
' Cosine Carrier = 1'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor ='
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	13.0000	40.0000	5.0000	569.0000	1.0000	13.0000	40.0000	5.0000	569.0000	1.0000	13.0000	40.0000	5.0000	569.0000	7500182.0000	1.0000	13.0000	40.0000	5.0000	569.0000
	2.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	3.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	4.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	5.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	6.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	7.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	8.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	9.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	10.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	11.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	12.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
	13.0000	13.0000	40.0000	5.0000	569.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 :  ; Original Call ; d:\data_acq\xblaster2\stimulus_files\Call_Types\ ; peeptril_m87_t450da10_182.txt ; Undecomposed'
	'Stimulus 2 :  ; Number of bands =4 ,Original Envelope ,Original Fine Structure ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_4\Call_Types\number_15\P_method1 ; OE_OF.mat ; All bands Used'
	'Stimulus 3 :  ; Number of bands =4 ,Original Envelope ,Noise Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_4\Call_Types\number_15\P_method1 ; OE_NC.mat ; All bands Used'
	'Stimulus 4 :  ; Number of bands =4 ,Original Envelope ,Cosine Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_4\Call_Types\number_15\P_method1 ; OE_CC.mat ; All bands Used'
	'Stimulus 5 :  ; Number of bands =8 ,Original Envelope ,Original Fine Structure ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_8\Call_Types\number_15\P_method1 ; OE_OF.mat ; All bands Used'
	'Stimulus 6 :  ; Number of bands =8 ,Original Envelope ,Noise Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_8\Call_Types\number_15\P_method1 ; OE_NC.mat ; All bands Used'
	'Stimulus 7 :  ; Number of bands =8 ,Original Envelope ,Cosine Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_8\Call_Types\number_15\P_method1 ; OE_CC.mat ; All bands Used'
	'Stimulus 8 :  ; Number of bands =16 ,Original Envelope ,Original Fine Structure ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_16\Call_Types\number_15\P_method1 ; OE_OF.mat ; All bands Used'
	'Stimulus 9 :  ; Number of bands =16 ,Original Envelope ,Noise Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_16\Call_Types\number_15\P_method1 ; OE_NC.mat ; All bands Used'
	'Stimulus 10 :  ; Number of bands =16 ,Original Envelope ,Cosine Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_16\Call_Types\number_15\P_method1 ; OE_CC.mat ; All bands Used'
	'Stimulus 11 :  ; Number of bands =32 ,Original Envelope ,Original Fine Structure ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_32\Call_Types\number_15\P_method1 ; OE_OF.mat ; All bands Used'
	'Stimulus 12 :  ; Number of bands =32 ,Original Envelope ,Noise Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_32\Call_Types\number_15\P_method1 ; OE_NC.mat ; All bands Used'
	'Stimulus 13 :  ; Number of bands =32 ,Original Envelope ,Cosine Carrier ; D:\XB_VD_Gen_Stimuli\f1_700_24000\f2_2000_24000\nb_32\Call_Types\number_15\P_method1 ; OE_CC.mat ; All bands Used'
 };
x.user_parms_formatted_ch1 = 'false';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	13.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	10	1	1	-1
	10	1	1	424387
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	12	1	1	-1
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	4	1	1	-1
	4	1	1	545643
	4	1	1	553142
	4	1	1	559081
	4	1	1	1181774
	4	1	1	1223335
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	9	1	1	-1
	9	1	1	325801
	9	1	1	464219
	9	1	1	487797
	9	1	1	614517
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	11	1	1	-1
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	1	1082106
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	5	1	1	-1
	5	1	1	1076243
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	2	1	-1
	4	2	1	559507
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	6	2	1	-1
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	8	2	1	-1
	8	2	1	1188078
	8	2	1	1265377
	8	2	1	1459955
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	5	2	1	-1
	5	2	1	1140156
	5	2	1	1165757
	5	2	1	1170598
	5	2	1	1267016
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	3	2	1	-1
	3	2	1	79825
	3	2	1	571139
	3	2	1	585101
	3	2	1	626240
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	802438
	1	2	1	890015
	1	2	1	1003955
	1	2	1	1058953
	1	2	1	1463310
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	9	2	1	-1
	9	2	1	616198
	9	2	1	625056
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	11	2	1	-1
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	2	2	1	-1
	2	2	1	220916
	2	2	1	835429
	2	2	1	847228
	2	2	1	1063589
	2	2	1	1081609
	2	2	1	1106068
	2	2	1	1358025
	2	2	1	1372064
	2	2	1	1480643
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	10	2	1	-1
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	13	2	1	-1
	13	2	1	1039486
	13	2	1	1066505
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	13	3	1	-1
	13	3	1	76953
	13	3	1	91454
	13	3	2	-1
	13	3	3	-1
	13	3	4	-1
	13	3	5	-1
	13	3	6	-1
	13	3	7	-1
	1	3	1	-1
	1	3	1	783944
	1	3	1	1441698
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	5	3	1	-1
	5	3	1	829021
	5	3	1	869841
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	11	3	1	-1
	11	3	1	1072519
	11	3	1	1091057
	11	3	2	-1
	11	3	3	-1
	11	3	4	-1
	11	3	5	-1
	11	3	6	-1
	11	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	12	3	1	-1
	12	3	2	-1
	12	3	3	-1
	12	3	4	-1
	12	3	5	-1
	12	3	6	-1
	12	3	7	-1
	7	3	1	-1
	7	3	1	408038
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	9	3	1	-1
	9	3	1	584415
	9	3	2	-1
	9	3	3	-1
	9	3	4	-1
	9	3	5	-1
	9	3	6	-1
	9	3	7	-1
	8	3	1	-1
	8	3	1	578036
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	10	3	1	-1
	10	3	2	-1
	10	3	3	-1
	10	3	4	-1
	10	3	5	-1
	10	3	6	-1
	10	3	7	-1
	4	3	1	-1
	4	3	1	555652
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	6	4	1	-1
	6	4	1	565411
	6	4	1	585831
	6	4	1	613511
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	13	4	1	-1
	13	4	1	1052183
	13	4	1	1090065
	13	4	2	-1
	13	4	3	-1
	13	4	4	-1
	13	4	5	-1
	13	4	6	-1
	13	4	7	-1
	10	4	1	-1
	10	4	2	-1
	10	4	3	-1
	10	4	4	-1
	10	4	5	-1
	10	4	6	-1
	10	4	7	-1
	1	4	1	-1
	1	4	1	806825
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	11	4	1	-1
	11	4	1	1058539
	11	4	2	-1
	11	4	3	-1
	11	4	4	-1
	11	4	5	-1
	11	4	6	-1
	11	4	7	-1
	2	4	1	-1
	2	4	1	1092017
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	4	4	1	-1
	4	4	1	562281
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	12	4	1	-1
	12	4	1	311681
	12	4	2	-1
	12	4	3	-1
	12	4	4	-1
	12	4	5	-1
	12	4	6	-1
	12	4	7	-1
	9	4	1	-1
	9	4	2	-1
	9	4	3	-1
	9	4	4	-1
	9	4	5	-1
	9	4	6	-1
	9	4	7	-1
	3	4	1	-1
	3	4	1	389639
	3	4	1	424198
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	7	4	1	-1
	7	4	1	751632
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	7	5	1	-1
	7	5	1	66758
	7	5	1	841410
	7	5	1	848831
	7	5	1	855030
	7	5	1	905388
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	10	5	1	-1
	10	5	2	-1
	10	5	3	-1
	10	5	4	-1
	10	5	5	-1
	10	5	6	-1
	10	5	7	-1
	9	5	1	-1
	9	5	2	-1
	9	5	3	-1
	9	5	4	-1
	9	5	5	-1
	9	5	6	-1
	9	5	7	-1
	11	5	1	-1
	11	5	2	-1
	11	5	3	-1
	11	5	4	-1
	11	5	5	-1
	11	5	6	-1
	11	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	2	5	1	-1
	2	5	1	1060522
	2	5	1	1137560
	2	5	1	1168280
	2	5	1	1471755
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	4	1416374
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	13	5	1	-1
	13	5	2	-1
	13	5	3	-1
	13	5	4	-1
	13	5	5	-1
	13	5	6	-1
	13	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	1006095
	1	5	1	1090876
	1	5	1	1112775
	1	5	1	1156296
	1	5	1	1377472
	1	5	1	1557212
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	12	5	1	-1
	12	5	2	-1
	12	5	3	-1
	12	5	4	-1
	12	5	5	-1
	12	5	6	-1
	12	5	7	-1
	3	5	1	-1
	3	5	1	574177
	3	5	1	770315
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	6	5	1	-1
	6	5	1	640535
	6	5	1	1042792
	6	5	1	1280428
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	5	5	1	-1
	5	5	1	1061469
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE