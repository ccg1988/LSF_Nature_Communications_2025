function x = M43s0042()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '10-Jan-2006 13:23:42';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 1;
x.starting_depth = 6000;
x.first_spike = 6167;
x.unit_depth = 6485;
x.unit_number = 2;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	7.0000	20.0000	5.0000	200.0000	6.0000	0.2500	727045647.0000	897103577.0000
	2.0000	7.0000	20.0000	5.0000	200.0000	6.0000	0.5000	3973666410.0000	1733879138.0000
	3.0000	7.0000	20.0000	5.0000	200.0000	6.0000	1.0000	2194011557.0000	1097814759.0000
	4.0000	7.0000	20.0000	5.0000	200.0000	6.0000	2.0000	4171998180.0000	3040683331.0000
	5.0000	7.0000	20.0000	5.0000	200.0000	6.0000	4.0000	4089602004.0000	1705615013.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  6       Bandwidth  0.25, randn_seed 727045647 897103577'
	'Stimulus 2 : NOISE: Center Frequency  6       Bandwidth  0.5, randn_seed 3973666410 1733879138'
	'Stimulus 3 : NOISE: Center Frequency  6       Bandwidth  1, randn_seed 2194011557 1097814759'
	'Stimulus 4 : NOISE: Center Frequency  6       Bandwidth  2, randn_seed 4171998180 3040683331'
	'Stimulus 5 : NOISE: Center Frequency  6       Bandwidth  4, randn_seed 4089602004 1705615013'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	7.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	2	1	1	-1
	2	1	1	300768
	2	1	1	304948
	2	1	1	317128
	2	1	1	325687
	2	1	1	365867
	2	1	1	408706
	2	1	1	416527
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	50391
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	1	1	-1
	4	1	1	15964
	4	1	1	120521
	4	1	1	485638
	4	1	1	510759
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	43499
	1	2	1	268756
	1	2	1	401056
	1	2	1	472654
	1	2	1	495575
	1	2	1	543473
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	5	2	1	-1
	5	2	1	526450
	5	2	1	529911
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	4	2	1	-1
	4	2	1	44094
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	3	1	-1
	2	3	1	274747
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	3	1	-1
	1	3	1	281765
	1	3	1	301063
	1	3	1	309103
	1	3	1	327463
	1	3	1	407824
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	4	3	1	-1
	4	3	1	11885
	4	3	1	17646
	4	3	1	503022
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	3	3	1	-1
	3	3	1	11822
	3	3	1	148203
	3	3	1	426699
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	1	4	1	-1
	1	4	1	276797
	1	4	1	345059
	1	4	1	684154
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	326076
	2	4	1	360176
	2	4	1	372214
	2	4	1	408394
	2	4	1	483275
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	3	4	1	-1
	3	4	1	16554
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	4	1	-1
	5	4	1	37952
	5	4	1	182392
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	5	1	-1
	2	5	1	273150
	2	5	1	338468
	2	5	1	400368
	2	5	1	404647
	2	5	1	418887
	2	5	1	557427
	2	5	1	587684
	2	5	1	669825
	2	5	1	678283
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	5	5	1	-1
	5	5	1	84350
	5	5	1	499085
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	1	197263
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	380860
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE