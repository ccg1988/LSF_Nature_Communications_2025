function x = M43s0056()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 09:44:59';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6257;
x.unit_number = 3;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 20;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 20'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Frequency is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	70.0000	2.0000	200.0000	4.0000	1.0000	3109587568.0000	460227404.0000
	2.0000	2.0000	70.0000	2.0000	200.0000	4.3028	1.0000	1942630536.0000	4258991644.0000
	3.0000	2.0000	70.0000	2.0000	200.0000	4.6284	1.0000	573055344.0000	3121002908.0000
	4.0000	2.0000	70.0000	2.0000	200.0000	4.9788	1.0000	650686292.0000	2252755977.0000
	5.0000	2.0000	70.0000	2.0000	200.0000	5.3556	1.0000	4173039852.0000	2836290711.0000
	6.0000	2.0000	70.0000	2.0000	200.0000	5.7610	1.0000	2372603780.0000	1142211679.0000
	7.0000	2.0000	70.0000	2.0000	200.0000	6.1970	1.0000	1283547641.0000	2571585935.0000
	8.0000	2.0000	70.0000	2.0000	200.0000	6.6661	1.0000	2763471983.0000	2953082733.0000
	9.0000	2.0000	70.0000	2.0000	200.0000	7.1707	1.0000	3509492467.0000	4243959610.0000
	10.0000	2.0000	70.0000	2.0000	200.0000	7.7134	1.0000	1883664321.0000	518907364.0000
	11.0000	2.0000	70.0000	2.0000	200.0000	8.2972	1.0000	2060916003.0000	2427925306.0000
	12.0000	2.0000	70.0000	2.0000	200.0000	8.9253	1.0000	2231908497.0000	2695282583.0000
	13.0000	2.0000	70.0000	2.0000	200.0000	9.6008	1.0000	4040855158.0000	47146336.0000
	14.0000	2.0000	70.0000	2.0000	200.0000	10.3275	1.0000	3359693817.0000	367494064.0000
	15.0000	2.0000	70.0000	2.0000	200.0000	11.1092	1.0000	2428439331.0000	521099756.0000
	16.0000	2.0000	70.0000	2.0000	200.0000	11.9501	1.0000	2744963796.0000	2157962148.0000
	17.0000	2.0000	70.0000	2.0000	200.0000	12.8546	1.0000	3205785437.0000	2433215769.0000
	18.0000	2.0000	70.0000	2.0000	200.0000	13.8276	1.0000	1964018561.0000	2705347576.0000
	19.0000	2.0000	70.0000	2.0000	200.0000	14.8742	1.0000	1165122068.0000	163300807.0000
	20.0000	2.0000	70.0000	2.0000	200.0000	16.0000	1.0000	4286422971.0000	1896752847.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  4       Bandwidth  1, randn_seed 3109587568 460227404'
	'Stimulus 2 : NOISE: Center Frequency  4.3028       Bandwidth  1, randn_seed 1942630536 4258991644'
	'Stimulus 3 : NOISE: Center Frequency  4.6284       Bandwidth  1, randn_seed 573055344 3121002908'
	'Stimulus 4 : NOISE: Center Frequency  4.9788       Bandwidth  1, randn_seed 650686292 2252755977'
	'Stimulus 5 : NOISE: Center Frequency  5.3556       Bandwidth  1, randn_seed 4173039852 2836290711'
	'Stimulus 6 : NOISE: Center Frequency  5.761       Bandwidth  1, randn_seed 2372603780 1142211679'
	'Stimulus 7 : NOISE: Center Frequency  6.197       Bandwidth  1, randn_seed 1283547641 2571585935'
	'Stimulus 8 : NOISE: Center Frequency  6.6661       Bandwidth  1, randn_seed 2763471983 2953082733'
	'Stimulus 9 : NOISE: Center Frequency  7.1707       Bandwidth  1, randn_seed 3509492467 4243959610'
	'Stimulus 10 : NOISE: Center Frequency  7.7134       Bandwidth  1, randn_seed 1883664321 518907364'
	'Stimulus 11 : NOISE: Center Frequency  8.2972       Bandwidth  1, randn_seed 2060916003 2427925306'
	'Stimulus 12 : NOISE: Center Frequency  8.9253       Bandwidth  1, randn_seed 2231908497 2695282583'
	'Stimulus 13 : NOISE: Center Frequency  9.6008       Bandwidth  1, randn_seed 4040855158 47146336'
	'Stimulus 14 : NOISE: Center Frequency  10.3275       Bandwidth  1, randn_seed 3359693817 367494064'
	'Stimulus 15 : NOISE: Center Frequency  11.1092       Bandwidth  1, randn_seed 2428439331 521099756'
	'Stimulus 16 : NOISE: Center Frequency  11.9501       Bandwidth  1, randn_seed 2744963796 2157962148'
	'Stimulus 17 : NOISE: Center Frequency  12.8546       Bandwidth  1, randn_seed 3205785437 2433215769'
	'Stimulus 18 : NOISE: Center Frequency  13.8276       Bandwidth  1, randn_seed 1964018561 2705347576'
	'Stimulus 19 : NOISE: Center Frequency  14.8742       Bandwidth  1, randn_seed 1165122068 163300807'
	'Stimulus 20 : NOISE: Center Frequency  16       Bandwidth  1, randn_seed 4286422971 1896752847'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	70.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	7	1	1	-1
	7	1	1	463410
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	16	1	1	-1
	16	1	1	252069
	16	1	1	270890
	16	1	1	279929
	16	1	1	298509
	16	1	1	464428
	16	1	2	-1
	16	1	3	-1
	16	1	4	-1
	16	1	5	-1
	16	1	6	-1
	16	1	7	-1
	12	1	1	-1
	12	1	1	245467
	12	1	1	260026
	12	1	1	274247
	12	1	1	283528
	12	1	1	328085
	12	1	1	366248
	12	1	1	420566
	12	1	1	443506
	12	1	1	455784
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	15	1	1	-1
	15	1	1	291183
	15	1	1	453443
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	10	1	1	-1
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	17	1	1	-1
	17	1	1	434253
	17	1	2	-1
	17	1	3	-1
	17	1	4	-1
	17	1	5	-1
	17	1	6	-1
	17	1	7	-1
	18	1	1	-1
	18	1	2	-1
	18	1	3	-1
	18	1	4	-1
	18	1	5	-1
	18	1	6	-1
	18	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	19	1	1	-1
	19	1	2	-1
	19	1	3	-1
	19	1	4	-1
	19	1	5	-1
	19	1	6	-1
	19	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	9	1	1	-1
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	14	1	1	-1
	14	1	1	252014
	14	1	1	281232
	14	1	1	334193
	14	1	1	420851
	14	1	1	444211
	14	1	1	460652
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	20	1	1	-1
	20	1	2	-1
	20	1	3	-1
	20	1	4	-1
	20	1	5	-1
	20	1	6	-1
	20	1	7	-1
	11	1	1	-1
	11	1	1	240247
	11	1	1	249847
	11	1	1	418644
	11	1	1	459265
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	2	1	1	-1
	2	1	1	60946
	2	1	1	503023
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	11	2	1	-1
	11	2	1	245594
	11	2	1	448233
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	18	2	1	-1
	18	2	2	-1
	18	2	3	-1
	18	2	4	-1
	18	2	5	-1
	18	2	6	-1
	18	2	7	-1
	16	2	1	-1
	16	2	2	-1
	16	2	3	-1
	16	2	4	-1
	16	2	5	-1
	16	2	6	-1
	16	2	7	-1
	10	2	1	-1
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	9	2	1	-1
	9	2	1	205680
	9	2	1	263460
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	13	2	1	-1
	13	2	1	250658
	13	2	1	297497
	13	2	1	431297
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	12	2	1	-1
	12	2	1	368154
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	15	2	1	-1
	15	2	1	264232
	15	2	1	281372
	15	2	1	366650
	15	2	1	450391
	15	2	1	455910
	15	2	2	-1
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	17	2	1	-1
	17	2	1	332483
	17	2	1	439281
	17	2	1	457063
	17	2	2	-1
	17	2	3	-1
	17	2	4	-1
	17	2	5	-1
	17	2	6	-1
	17	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	19	2	1	-1
	19	2	1	501716
	19	2	2	-1
	19	2	3	-1
	19	2	4	-1
	19	2	5	-1
	19	2	6	-1
	19	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	6	2	1	-1
	6	2	1	270372
	6	2	1	452749
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	14	2	1	-1
	14	2	1	259350
	14	2	1	283108
	14	2	1	316507
	14	2	1	361407
	14	2	1	473568
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	20	2	1	-1
	20	2	1	125606
	20	2	1	198986
	20	2	2	-1
	20	2	3	-1
	20	2	4	-1
	20	2	5	-1
	20	2	6	-1
	20	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE