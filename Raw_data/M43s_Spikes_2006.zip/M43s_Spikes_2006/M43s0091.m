function x = M43s0091()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 11:12:03';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6380;
x.unit_number = 4;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	1.0000	1.0000	0.0000	0.0000	20.0000
	2.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	2.0000	1.0000	0.0000	0.0000	20.0000
	3.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	3.0000	1.0000	0.0000	0.0000	20.0000
	4.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	4.0000	1.0000	0.0000	0.0000	20.0000
	5.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	7800.0000	1.0000	5.0000	1.0000	0.0000	0.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 7800 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	269375
	1	1	1	1533081
	1	1	1	1560960
	1	1	1	1702421
	1	1	1	1881797
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	590737
	2	1	1	627577
	2	1	1	650817
	2	1	1	1518469
	2	1	1	1569227
	2	1	1	1582628
	2	1	1	1595387
	2	1	1	1607508
	2	1	1	1706685
	2	1	1	1715886
	2	1	1	1723745
	2	1	1	1843683
	2	1	1	1848823
	2	1	1	1913064
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	284466
	3	1	1	1592093
	3	1	1	1612131
	3	1	1	1628951
	3	1	1	1635931
	3	1	1	1690291
	3	1	1	1741731
	3	1	1	1774510
	3	1	1	1975588
	3	1	1	1985567
	3	1	1	1992068
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	337789
	4	1	1	354449
	4	1	1	360828
	4	1	1	500027
	4	1	1	582487
	4	1	1	742987
	4	1	1	1603357
	4	1	1	1763435
	4	1	1	1816774
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	595992
	5	1	1	1548604
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	1	239558
	4	2	1	1534063
	4	2	1	1538444
	4	2	1	1587784
	4	2	1	1616124
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	597158
	5	2	1	1623049
	5	2	1	1745788
	5	2	1	1790506
	5	2	1	1838466
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	3	1	-1
	1	3	1	1912991
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	1	1031053
	3	3	1	1461069
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	1552450
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	398010
	5	3	1	409870
	5	3	1	415269
	5	3	1	425428
	5	3	1	433129
	5	3	1	1610697
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	4	1	-1
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	607118
	2	4	1	718457
	2	4	1	1280453
	2	4	1	1524310
	2	4	1	1544628
	2	4	1	1558309
	2	4	1	1569889
	2	4	1	1582507
	2	4	1	1594169
	2	4	1	1932484
	2	4	1	1942445
	2	4	1	1947605
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	1977147
	3	4	1	1986147
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	383111
	4	4	1	1531759
	4	4	1	1659258
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	695885
	2	5	1	1539816
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	580821
	5	5	1	1237533
	5	5	1	1524172
	5	5	1	1536690
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE