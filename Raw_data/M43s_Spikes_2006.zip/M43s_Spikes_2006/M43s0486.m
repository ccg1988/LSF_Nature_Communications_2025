function x = M43s0486()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-AM';
x.analysis_code = 55;
x.animal = 'M43s';
x.datetime = '22-Jan-2006 15:46:52';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 6;
x.starting_depth = 10000;
x.first_spike = 10698;
x.unit_depth = 11291;
x.unit_number = 22;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'WB Noise AM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
' Call File Name = d:\data_acq\xblaster2\stimulus_files\Call_Types\peeptril_m87_t450da10_182.txt'
' Number of Frequency Bands = 4   8  16  32'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Processing Method = Envelope/Fine Structure Processing'
' Original Envelope = 1'
' Flat Envelope = 0'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 1'
' Noise Carrier = 1'
' Cosine Carrier = 1'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor ='
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' WB Noise AM Depth' ' Modulation' ' Hz randn_seed' ' Hz randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	4.0000	863596762.0000	3569230196.0000
	2.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	8.0000	1275108353.0000	766839846.0000
	3.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	16.0000	127044981.0000	2320825480.0000
	4.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	32.0000	2553764014.0000	3227839052.0000
	5.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	64.0000	2860611876.0000	2678177397.0000
	6.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	128.0000	1115413138.0000	905678839.0000
	7.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	256.0000	1284281267.0000	2997117868.0000
	8.0000	2.0000	40.0000	5.0000	1000.0000	1.0000	512.0000	3284392048.0000	744541566.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : WB Noise AM: Depth = 1, Modulation = 4 (Hz), randn_seed = 863596762 3569230196'
	'Stimulus 2 : WB Noise AM: Depth = 1, Modulation = 8 (Hz), randn_seed = 1275108353 766839846'
	'Stimulus 3 : WB Noise AM: Depth = 1, Modulation = 16 (Hz), randn_seed = 127044981 2320825480'
	'Stimulus 4 : WB Noise AM: Depth = 1, Modulation = 32 (Hz), randn_seed = 2553764014 3227839052'
	'Stimulus 5 : WB Noise AM: Depth = 1, Modulation = 64 (Hz), randn_seed = 2860611876 2678177397'
	'Stimulus 6 : WB Noise AM: Depth = 1, Modulation = 128 (Hz), randn_seed = 1115413138 905678839'
	'Stimulus 7 : WB Noise AM: Depth = 1, Modulation = 256 (Hz), randn_seed = 1284281267 2997117868'
	'Stimulus 8 : WB Noise AM: Depth = 1, Modulation = 512 (Hz), randn_seed = 3284392048 744541566'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	8	1	1	-1
	8	1	1	74175
	8	1	1	1935037
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	265104
	1	1	1	295764
	1	1	1	1189834
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	1779032
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	8	2	1	-1
	8	2	1	1432545
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	6	2	1	-1
	6	2	1	284145
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	1	3	1	-1
	1	3	1	114283
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	1859635
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	2	3	1	-1
	2	3	1	486175
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	6	3	1	-1
	6	3	1	1798439
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	8	3	1	-1
	8	3	1	1790125
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	4	1	-1
	1	4	1	1162028
	1	4	1	1827402
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	1	505845
	4	4	1	521605
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE