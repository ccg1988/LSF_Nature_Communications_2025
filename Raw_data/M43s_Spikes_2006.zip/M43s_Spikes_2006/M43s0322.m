function x = M43s0322()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M43s';
x.datetime = '18-Jan-2006 11:33:22';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 1;
x.starting_depth = 8000;
x.first_spike = 8415;
x.unit_depth = 8890;
x.unit_number = 16;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	2.0000	3.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	3.0000	4.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	4.0000	5.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	5.0000	6.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	6.0000	7.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	7.0000	8.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	8.0000	9.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	9.0000	10.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	10.0000	11.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	11.0000	12.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	12.0000	13.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	13.0000	14.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	14.0000	15.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
	15.0000	16.0000	10.0000	5.0000	200.0000	32.0000	1.0000	3756480479.0000	3734465448.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 2 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 3 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 4 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 5 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 6 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 7 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 8 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 9 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 10 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 11 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 12 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 13 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 14 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
	'Stimulus 15 : NOISE: Center Frequency  32       Bandwidth  1, randn_seed 3756480479 3734465448'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	10.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	6.00	7.00	8.00	9.00	10.00	11.00	12.00	13.00	14.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	12	1	1	-1
	12	1	1	398902
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	9	1	1	-1
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	10	1	1	-1
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	11	1	1	-1
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	15	1	1	-1
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	14	1	1	-1
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	1	2	1	-1
	1	2	1	74695
	1	2	1	87875
	1	2	1	158775
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	13	2	1	-1
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	9	2	1	-1
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	6	2	1	-1
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	15	2	1	-1
	15	2	2	-1
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	11	2	1	-1
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	10	2	1	-1
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	14	2	1	-1
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	13	3	1	-1
	13	3	2	-1
	13	3	3	-1
	13	3	4	-1
	13	3	5	-1
	13	3	6	-1
	13	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	15	3	1	-1
	15	3	2	-1
	15	3	3	-1
	15	3	4	-1
	15	3	5	-1
	15	3	6	-1
	15	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	14	3	1	-1
	14	3	2	-1
	14	3	3	-1
	14	3	4	-1
	14	3	5	-1
	14	3	6	-1
	14	3	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	10	3	1	-1
	10	3	2	-1
	10	3	3	-1
	10	3	4	-1
	10	3	5	-1
	10	3	6	-1
	10	3	7	-1
	9	3	1	-1
	9	3	2	-1
	9	3	3	-1
	9	3	4	-1
	9	3	5	-1
	9	3	6	-1
	9	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	12	3	1	-1
	12	3	2	-1
	12	3	3	-1
	12	3	4	-1
	12	3	5	-1
	12	3	6	-1
	12	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	11	3	1	-1
	11	3	2	-1
	11	3	3	-1
	11	3	4	-1
	11	3	5	-1
	11	3	6	-1
	11	3	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE