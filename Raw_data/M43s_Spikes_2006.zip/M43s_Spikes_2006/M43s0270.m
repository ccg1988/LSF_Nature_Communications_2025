function x = M43s0270()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '14-Jan-2006 10:40:46';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 6;
x.starting_depth = 7000;
x.first_spike = 7447;
x.unit_depth = 7507;
x.unit_number = 13;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	1.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	2.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	3.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	3.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	4.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	4.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	5.0000	8.0000	40.0000	5.0000	1000.0000	1.0000	12900.0000	1.0000	5.0000	1.0000	0.0000	4.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	601825
	5	1	1	701982
	5	1	1	904201
	5	1	1	1168417
	5	1	1	1401976
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	4	700851
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	1	1	-1
	1	1	1	619270
	1	1	1	913907
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	561675
	2	1	1	568236
	2	1	1	584977
	2	1	1	591777
	2	1	1	598576
	2	1	1	616675
	2	1	1	626277
	2	1	1	635216
	2	1	1	648776
	2	1	1	829055
	2	1	1	867032
	2	1	1	968353
	2	1	1	1161509
	2	1	1	1235070
	2	1	1	1360949
	2	1	1	1398688
	2	1	1	1408606
	2	1	1	1432749
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	1	1	-1
	4	1	1	584722
	4	1	1	631339
	4	1	1	740778
	4	1	1	889859
	4	1	1	1143374
	4	1	1	1367714
	4	1	1	1388194
	4	1	1	1433913
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	928943
	3	1	1	951121
	3	1	1	967762
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	2	1	-1
	2	2	1	568973
	2	2	1	663333
	2	2	1	967608
	2	2	1	1167766
	2	2	1	1174707
	2	2	1	1194428
	2	2	1	1202508
	2	2	1	1212165
	2	2	1	1398345
	2	2	1	1406806
	2	2	1	1418063
	2	2	1	1433685
	2	2	1	1441764
	2	2	1	1450325
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	619856
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	2	1	-1
	4	2	1	595425
	4	2	1	618044
	4	2	1	1192057
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	1	667928
	3	2	1	674409
	3	2	1	690209
	3	2	1	728769
	3	2	1	896448
	3	2	1	1195583
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	1	681036
	5	2	1	717275
	5	2	1	902173
	5	2	1	1126089
	5	2	1	1360046
	5	2	1	1404328
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	3	3	1	-1
	3	3	1	612842
	3	3	1	897217
	3	3	1	1141517
	3	3	1	1156117
	3	3	1	1399253
	3	3	1	1443794
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	1	567386
	2	3	1	588385
	2	3	1	598385
	2	3	1	608865
	2	3	1	619366
	2	3	1	642304
	2	3	1	697524
	2	3	1	702445
	2	3	1	835664
	2	3	1	860542
	2	3	1	881484
	2	3	1	964601
	2	3	1	1086720
	2	3	1	1124160
	2	3	1	1392878
	2	3	1	1425379
	2	3	1	1433797
	2	3	1	1440936
	2	3	1	1456536
	2	3	1	1465818
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	4	3	1	-1
	4	3	1	692697
	4	3	1	1448409
	4	3	1	1481568
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	1	3	1	-1
	1	3	1	1804852
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	5	4	1	-1
	5	4	1	603348
	5	4	1	614109
	5	4	1	640809
	5	4	1	891806
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	4	1	-1
	2	4	1	30542
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	4	4	1	-1
	4	4	1	608382
	4	4	1	632660
	4	4	1	646221
	4	4	1	1166715
	4	4	1	1175776
	4	4	1	1198735
	4	4	1	1208136
	4	4	1	1459553
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	3	4	1	-1
	3	4	1	906543
	3	4	1	915442
	3	4	1	925803
	3	4	1	932642
	3	4	1	938622
	3	4	1	957323
	3	4	1	1155342
	3	4	1	1371838
	3	4	1	1418357
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	4	1154228
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	1	4	1	-1
	1	4	1	667832
	1	4	1	678890
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	4	666705
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	5	1	-1
	4	5	1	184742
	4	5	1	601877
	4	5	1	607518
	4	5	1	616900
	4	5	1	627397
	4	5	1	633678
	4	5	1	1119153
	4	5	1	1200392
	4	5	1	1361491
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	2	5	1	-1
	2	5	1	591464
	2	5	1	599804
	2	5	1	618923
	2	5	1	626744
	2	5	1	642545
	2	5	1	668601
	2	5	1	676082
	2	5	1	847101
	2	5	1	887160
	2	5	1	919579
	2	5	1	958519
	2	5	1	1106439
	2	5	1	1123058
	2	5	1	1142219
	2	5	1	1154879
	2	5	1	1185720
	2	5	1	1203796
	2	5	1	1360655
	2	5	1	1383315
	2	5	1	1391716
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	1205462
	3	5	1	1442099
	3	5	1	1448501
	3	5	1	1466478
	3	5	1	1507980
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	5	5	1	-1
	5	5	1	1204468
	5	5	1	1480686
	5	5	1	1838203
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE