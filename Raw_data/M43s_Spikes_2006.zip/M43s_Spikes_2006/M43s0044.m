function x = M43s0044()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '10-Jan-2006 13:24:52';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 1;
x.starting_depth = 6000;
x.first_spike = 6167;
x.unit_depth = 6485;
x.unit_number = 2;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	13.0000	20.0000	5.0000	200.0000	6.0000	0.2500	1393223755.0000	246385019.0000
	2.0000	13.0000	20.0000	5.0000	200.0000	6.0000	0.5000	336084368.0000	128958438.0000
	3.0000	13.0000	20.0000	5.0000	200.0000	6.0000	1.0000	2435881108.0000	3775963986.0000
	4.0000	13.0000	20.0000	5.0000	200.0000	6.0000	2.0000	2832933062.0000	957618256.0000
	5.0000	13.0000	20.0000	5.0000	200.0000	6.0000	4.0000	252674646.0000	1633391469.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  6       Bandwidth  0.25, randn_seed 1393223755 246385019'
	'Stimulus 2 : NOISE: Center Frequency  6       Bandwidth  0.5, randn_seed 336084368 128958438'
	'Stimulus 3 : NOISE: Center Frequency  6       Bandwidth  1, randn_seed 2435881108 3775963986'
	'Stimulus 4 : NOISE: Center Frequency  6       Bandwidth  2, randn_seed 2832933062 957618256'
	'Stimulus 5 : NOISE: Center Frequency  6       Bandwidth  4, randn_seed 252674646 1633391469'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	13.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	39065
	4	1	1	43445
	4	1	1	506379
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	110400
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	1	1	-1
	2	1	1	157899
	2	1	1	168838
	2	1	1	186377
	2	1	1	270538
	2	1	1	321217
	2	1	1	429757
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	5	1	1	-1
	5	1	1	62478
	5	1	1	70159
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	1	1	-1
	1	1	1	367874
	1	1	1	393232
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	2	2	1	-1
	2	2	1	292287
	2	2	1	351168
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	399343
	1	2	1	577422
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	3	1	-1
	4	3	1	57125
	4	3	1	560460
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	2	3	1	-1
	2	3	1	113403
	2	3	1	390100
	2	3	1	415300
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	5	3	1	-1
	5	3	1	44020
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	1	37816
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	1	19113
	5	4	1	37813
	5	4	1	72134
	5	4	1	84474
	5	4	1	166192
	5	4	1	192690
	5	4	1	200391
	5	4	1	205371
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	1	4	1	-1
	1	4	1	297765
	1	4	1	335044
	1	4	1	347364
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	3	4	1	-1
	3	4	1	70425
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	5	1	-1
	5	5	1	496161
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	3	5	1	-1
	3	5	1	458179
	3	5	1	576737
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	2	5	1	-1
	2	5	1	43682
	2	5	1	387876
	2	5	1	407657
	2	5	1	617356
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	1	5	1	-1
	1	5	1	319415
	1	5	1	600813
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	4	5	1	-1
	4	5	1	118935
	4	5	1	698190
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE