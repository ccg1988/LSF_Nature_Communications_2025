function x = M43s0226()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 12:18:48';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	2.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	8.0000	1.0000	20.0000
	3.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	4.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	32.0000	1.0000	20.0000
	5.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	64.0000	1.0000	20.0000
	6.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	128.0000	1.0000	20.0000
	7.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	256.0000	1.0000	20.0000
	8.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 8 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 32 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 64 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 6 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 128 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 7 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 256 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 8 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	870368
	1	1	1	1081168
	1	1	1	1410062
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	8	1	1	-1
	8	1	1	38044
	8	1	1	49964
	8	1	1	58823
	8	1	1	263340
	8	1	1	970174
	8	1	1	1119430
	8	1	1	1474987
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	4	1	1	-1
	4	1	1	85569
	4	1	1	390385
	4	1	1	622323
	4	1	1	629441
	4	1	1	821740
	4	1	1	866639
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	1113302
	5	1	1	1128201
	5	1	1	1374580
	5	1	1	1377980
	5	1	1	1385260
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	3	1	1	-1
	3	1	1	625432
	3	1	1	634711
	3	1	1	685470
	3	1	1	690851
	3	1	1	703592
	3	1	1	788231
	3	1	1	822130
	3	1	1	858649
	3	1	1	1034909
	3	1	1	1051767
	3	1	1	1360944
	3	1	1	1372005
	3	1	1	1397585
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	7	1	1	-1
	7	1	1	1489669
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	2	1	1	-1
	2	1	1	715083
	2	1	1	867139
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	1	1	-1
	6	1	1	295410
	6	1	1	683386
	6	1	1	817546
	6	1	1	827705
	6	1	1	923326
	6	1	1	1178901
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	2	2	1	-1
	2	2	1	958229
	2	2	1	1247386
	2	2	1	1347087
	2	2	1	1365687
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	1399311
	1	2	1	1402470
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	8	2	1	-1
	8	2	1	725122
	8	2	1	1418735
	8	2	1	1502014
	8	2	1	1664215
	8	2	1	1672174
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	6	2	1	-1
	6	2	1	53617
	6	2	1	56137
	6	2	1	106937
	6	2	1	174234
	6	2	1	1058625
	6	2	1	1421363
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	4	2	1	-1
	4	2	1	548080
	4	2	1	798177
	4	2	1	944677
	4	2	1	947417
	4	2	1	952398
	4	2	1	1203115
	4	2	1	1761347
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	1	338507
	3	2	1	716766
	3	2	1	740105
	3	2	1	813823
	3	2	1	820922
	3	2	1	848646
	3	2	1	934843
	3	2	1	957342
	3	2	1	980603
	3	2	1	984301
	3	2	1	1382460
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	1	1345084
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	3	1	-1
	7	3	1	32360
	7	3	1	639674
	7	3	1	760455
	7	3	1	948432
	7	3	1	1005172
	7	3	1	1132151
	7	3	1	1477986
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	4	3	1	-1
	4	3	1	734260
	4	3	1	1071897
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	8	3	1	-1
	8	3	1	919283
	8	3	1	1256680
	8	3	1	1260181
	8	3	1	1411657
	8	3	1	1430077
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	1	3	1	-1
	1	3	1	472452
	1	3	1	501134
	1	3	1	518132
	1	3	1	522333
	1	3	1	528074
	1	3	1	1131789
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	1	401340
	6	3	1	488998
	6	3	1	704056
	6	3	1	1343311
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	2	3	1	-1
	2	3	1	862381
	2	3	1	1222996
	2	3	1	1232016
	2	3	1	1243675
	2	3	1	1485153
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	1	259492
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	1	656912
	3	3	1	1144068
	3	3	1	1203427
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	1	4	1	-1
	1	4	1	587121
	1	4	1	876855
	1	4	1	932556
	1	4	1	1405550
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	1012881
	4	4	1	1416915
	4	4	1	1499937
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	6	4	1	-1
	6	4	1	443192
	6	4	1	841888
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	1	223100
	7	4	1	1601103
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	3	4	1	-1
	3	4	1	687318
	3	4	1	839957
	3	4	1	953998
	3	4	1	1646189
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	8	4	1	-1
	8	4	1	925602
	8	4	1	1031002
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	2	4	1	-1
	2	4	1	603930
	2	4	1	1101685
	2	4	1	1117326
	2	4	1	1459902
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	5	1	-1
	2	5	1	599923
	2	5	1	717322
	2	5	1	869419
	2	5	1	1041559
	2	5	1	1225476
	2	5	1	1457714
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	7	5	1	-1
	7	5	1	905765
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	8	5	1	-1
	8	5	1	34980
	8	5	1	1052088
	8	5	1	1061269
	8	5	1	1124149
	8	5	1	1340085
	8	5	1	1420223
	8	5	1	1430725
	8	5	1	1489704
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	4	5	1	-1
	4	5	1	1433110
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	494623
	1	5	1	524023
	1	5	1	538283
	1	5	1	698661
	1	5	1	886199
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	5	5	1	-1
	5	5	1	301871
	5	5	1	883007
	5	5	1	1321681
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	6	5	1	-1
	6	5	1	727212
	6	5	1	1257928
	6	5	1	1265008
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	3	5	1	-1
	3	5	1	695920
	3	5	1	1960866
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE