function x = M43s0067()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '11-Jan-2006 10:14:31';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 2;
x.starting_depth = 6000;
x.first_spike = 6213;
x.unit_depth = 6257;
x.unit_number = 3;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	4.0000	1.0000	20.0000
	2.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	8.0000	1.0000	20.0000
	3.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	4.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	32.0000	1.0000	20.0000
	5.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	64.0000	1.0000	20.0000
	6.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	128.0000	1.0000	20.0000
	7.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	256.0000	1.0000	20.0000
	8.0000	2.0000	70.0000	5.0000	1000.0000	1.0000	8900.0000	1.0000	3.0000	1.0000	0.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 8 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 32 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 64 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 6 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 128 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 7 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 256 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 8 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 8900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Sequential';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	70.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	950759
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	629471
	2	1	1	638851
	2	1	1	666470
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	616377
	3	1	1	842213
	3	1	1	1213611
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	1529833
	4	1	1	1557973
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	657107
	5	1	1	664507
	5	1	1	674349
	5	1	1	1547220
	5	1	1	1565240
	5	1	1	1573639
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	6	1	1	-1
	6	1	1	694134
	6	1	1	1012669
	6	1	1	1536266
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	7	1	1	-1
	7	1	1	1030158
	7	1	1	1346853
	7	1	1	1393054
	7	1	1	1473432
	7	1	1	1482791
	7	1	1	1489772
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	1	615008
	8	1	1	635846
	8	1	1	676686
	8	1	1	814604
	8	1	1	827383
	8	1	1	833965
	8	1	1	853883
	8	1	1	921103
	8	1	1	1004582
	8	1	1	1033424
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	1	2	1	-1
	1	2	1	618992
	1	2	1	700172
	1	2	1	714831
	1	2	1	862689
	1	2	1	872310
	1	2	1	973488
	1	2	1	1023508
	1	2	1	1033587
	1	2	1	1234208
	1	2	1	1241086
	1	2	1	1254705
	1	2	1	1275325
	1	2	1	1434786
	1	2	1	1463563
	1	2	1	1504303
	1	2	1	1519722
	1	2	1	1530344
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	42366
	2	2	1	430060
	2	2	1	568858
	2	2	1	632799
	2	2	1	756577
	2	2	1	816758
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	583564
	3	2	1	790382
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	1044934
	5	2	1	1060872
	5	2	1	1089173
	5	2	1	1539166
	5	2	1	1584849
	5	2	1	1607267
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	6	2	1	-1
	6	2	1	982600
	6	2	1	1101280
	6	2	1	1523375
	6	2	1	1538732
	6	2	1	1544575
	6	2	1	1570694
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	7	2	1	-1
	7	2	1	581331
	7	2	1	609109
	7	2	1	1484061
	7	2	1	1510180
	7	2	1	1544940
	7	2	1	1562221
	7	2	1	1601640
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	8	2	1	-1
	8	2	1	626795
	8	2	1	880832
	8	2	1	927651
	8	2	1	934772
	8	2	1	985450
	8	2	1	1019629
	8	2	1	1123610
	8	2	1	1147470
	8	2	1	1171249
	8	2	1	1346587
	8	2	1	1469666
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	1	3	1	-1
	1	3	1	693839
	1	3	1	707441
	1	3	1	995936
	1	3	1	1234954
	1	3	1	1454912
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	873359
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	6	3	1	-1
	6	3	1	789951
	6	3	1	1535462
	6	3	1	1553702
	6	3	1	1574661
	6	3	1	1592880
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	7	3	1	-1
	7	3	1	601218
	7	3	1	608277
	7	3	1	622057
	7	3	1	722098
	7	3	1	760176
	7	3	1	798876
	7	3	1	903134
	7	3	1	1045555
	7	3	1	1091494
	7	3	1	1108053
	7	3	1	1140911
	7	3	1	1535229
	7	3	1	1548829
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	8	3	1	-1
	8	3	1	610345
	8	3	1	649304
	8	3	1	758021
	8	3	1	768983
	8	3	1	781221
	8	3	1	798421
	8	3	1	893362
	8	3	1	903661
	8	3	1	929761
	8	3	1	937059
	8	3	1	951221
	8	3	1	1005260
	8	3	1	1010199
	8	3	1	1324155
	8	3	1	1401736
	8	3	1	1548274
	8	3	1	1556355
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	1	4	1	-1
	1	4	1	972407
	1	4	1	1467741
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	783592
	2	4	1	1385089
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	6	4	1	-1
	6	4	1	580280
	6	4	1	717160
	6	4	1	754959
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	4	1	-1
	7	4	1	610847
	7	4	1	653885
	7	4	1	739767
	7	4	1	760503
	7	4	1	1482438
	7	4	1	1520557
	7	4	1	1536598
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	8	4	1	-1
	8	4	1	919070
	8	4	1	953310
	8	4	1	1182168
	8	4	1	1225046
	8	4	1	1507382
	8	4	1	1523622
	8	4	1	1535705
	8	4	1	1582222
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	1	5	1	-1
	1	5	1	710558
	1	5	1	1491750
	1	5	1	1499349
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	3	5	1	-1
	3	5	1	1334182
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	769601
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	6	5	1	-1
	6	5	1	614308
	6	5	1	628249
	6	5	1	655910
	6	5	1	727890
	6	5	1	774047
	6	5	1	780587
	6	5	1	791507
	6	5	1	1058243
	6	5	1	1580100
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	7	5	1	-1
	7	5	1	615895
	7	5	1	665554
	7	5	1	878752
	7	5	1	896532
	7	5	1	1170910
	7	5	1	1912961
	7	5	1	1928663
	7	5	1	1951823
	7	5	1	1968421
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	8	5	1	-1
	8	5	1	1320175
	8	5	1	1484971
	8	5	1	1509874
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE