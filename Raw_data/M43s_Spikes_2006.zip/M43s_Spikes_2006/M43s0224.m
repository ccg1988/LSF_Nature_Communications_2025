function x = M43s0224()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 12:15:42';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	1.0000	1.0000	0.0000	0.0000	20.0000
	2.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	2.0000	1.0000	0.0000	0.0000	20.0000
	3.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	0.0000	20.0000
	4.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	4.0000	1.0000	0.0000	0.0000	20.0000
	5.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	5.0000	1.0000	0.0000	0.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 0 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	3	1	1	-1
	3	1	1	81187
	3	1	1	717841
	3	1	1	889899
	3	1	1	973156
	3	1	1	1197254
	3	1	1	1363152
	3	1	1	1507891
	3	1	1	1800369
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	1	60333
	5	1	1	749226
	5	1	1	1664855
	5	1	1	1691795
	5	1	1	1697656
	5	1	1	1734836
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	51938
	2	1	1	1078826
	2	1	1	1359724
	2	1	1	1431882
	2	1	1	1506241
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	1	1	-1
	4	1	1	1015733
	4	1	1	1160571
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	1	1	1	-1
	1	1	1	978240
	1	1	1	1078397
	1	1	1	1579390
	1	1	1	1645071
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	1159367
	2	2	1	1196906
	2	2	1	1288145
	2	2	1	1331584
	2	2	1	1368404
	2	2	1	1392824
	2	2	1	1395504
	2	2	1	1705140
	2	2	1	1713100
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	4	2	1	-1
	4	2	1	472360
	4	2	1	514618
	4	2	1	634798
	4	2	1	835216
	4	2	1	1096512
	4	2	1	1221130
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	1	165846
	5	2	1	859278
	5	2	1	1046179
	5	2	1	1097897
	5	2	1	1383053
	5	2	1	1404593
	5	2	1	1923910
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	3	2	1	-1
	3	2	1	900765
	3	2	1	1140381
	3	2	1	1166963
	3	2	1	1172282
	3	2	1	1206581
	3	2	1	1351561
	3	2	1	1431339
	3	2	1	1680678
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	3	1	-1
	1	3	1	52538
	1	3	1	493452
	1	3	1	1769740
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	5	3	1	-1
	5	3	1	280442
	5	3	1	1240310
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	1	699162
	3	3	1	729141
	3	3	1	734221
	3	3	1	939781
	3	3	1	1013378
	3	3	1	1180676
	3	3	1	1437975
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	1	1026924
	2	3	1	1957734
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	4	3	1	-1
	4	3	1	948028
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	1	4	1	-1
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	201627
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	5	4	1	-1
	5	4	1	1359983
	5	4	1	1413882
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	3	4	1	-1
	3	4	1	1229829
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	2	4	1	-1
	2	4	1	402403
	2	4	1	984757
	2	4	1	1234335
	2	4	1	1503592
	2	4	1	1701089
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	4	5	1	-1
	4	5	1	1216918
	4	5	1	1419978
	4	5	1	1823172
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	5	5	1	-1
	5	5	1	361554
	5	5	1	369954
	5	5	1	1126066
	5	5	1	1358104
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	3	5	1	-1
	3	5	1	737676
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	1	5	1	-1
	1	5	1	331685
	1	5	1	1165814
	1	5	1	1789708
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	2	5	1	-1
	2	5	1	484549
	2	5	1	493088
	2	5	1	520448
	2	5	1	541088
	2	5	1	1436278
	2	5	1	1439919
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE