function x = M43s0426()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M43s';
x.datetime = '21-Jan-2006 10:10:27';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 5;
x.starting_depth = 9000;
x.first_spike = 9298;
x.unit_depth = 9420;
x.unit_number = 20;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	2.0000	3.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	3.0000	4.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	4.0000	5.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	5.0000	6.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	6.0000	7.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	7.0000	8.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	8.0000	9.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	9.0000	10.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	10.0000	11.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	11.0000	12.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	12.0000	13.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	13.0000	14.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	14.0000	15.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
	15.0000	16.0000	10.0000	2.0000	200.0000	10.0000	2.0000	2795501832.0000	3292110666.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 2 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 3 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 4 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 5 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 6 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 7 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 8 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 9 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 10 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 11 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 12 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 13 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 14 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
	'Stimulus 15 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 2795501832 3292110666'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	10.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	6.00	7.00	8.00	9.00	10.00	11.00	12.00	13.00	14.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	14	1	1	-1
	14	1	1	379438
	14	1	1	390499
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	10	1	1	-1
	10	1	1	349695
	10	1	1	370053
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	13	1	1	-1
	13	1	1	114433
	13	1	1	374112
	13	1	1	384692
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	2	1	1	-1
	2	1	1	253527
	2	1	1	306248
	2	1	1	388268
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	1	1	-1
	4	1	1	282345
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	7	1	1	-1
	7	1	1	403538
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	1	1	1	-1
	1	1	1	345495
	1	1	1	435673
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	15	1	1	-1
	15	1	1	249711
	15	1	1	296950
	15	1	1	306331
	15	1	1	353271
	15	1	1	407269
	15	1	1	420710
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	6	1	1	-1
	6	1	1	341365
	6	1	1	368845
	6	1	1	373987
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	12	1	1	-1
	12	1	1	282022
	12	1	1	369062
	12	1	1	378262
	12	1	1	420362
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	3	1	1	-1
	3	1	1	356938
	3	1	1	368799
	3	1	1	377938
	3	1	1	395178
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	9	1	1	-1
	9	1	1	261795
	9	1	1	344775
	9	1	1	355193
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	11	1	1	-1
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	5	1	1	-1
	5	1	1	397149
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	11	2	1	-1
	11	2	1	376959
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	6	2	1	-1
	6	2	1	348418
	6	2	1	355437
	6	2	1	374876
	6	2	1	387477
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	13	2	1	-1
	13	2	1	354614
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	14	2	1	-1
	14	2	1	340546
	14	2	1	376585
	14	2	1	383527
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	5	2	1	-1
	5	2	1	347362
	5	2	1	381843
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	3	2	1	-1
	3	2	1	265080
	3	2	1	279961
	3	2	1	300819
	3	2	1	308800
	3	2	1	316518
	3	2	1	363257
	3	2	1	378580
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	10	2	1	-1
	10	2	1	265212
	10	2	1	287711
	10	2	1	301693
	10	2	1	311692
	10	2	1	345773
	10	2	1	371371
	10	2	1	380172
	10	2	1	421890
	10	2	1	450011
	10	2	1	469993
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	2	2	1	-1
	2	2	1	284530
	2	2	1	299349
	2	2	1	404829
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	8	2	1	-1
	8	2	1	396045
	8	2	1	408844
	8	2	1	416842
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	9	2	1	-1
	9	2	1	262041
	9	2	1	345539
	9	2	1	376439
	9	2	1	387800
	9	2	1	405841
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	15	2	1	-1
	15	2	1	306798
	15	2	1	315137
	15	2	1	388196
	15	2	2	-1
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	7	2	1	-1
	7	2	1	392491
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE