function x = M43s0228()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Noise Based';
x.analysis_code = 1801;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 12:21:50';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	1.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	2.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	2.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	3.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	4.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	4.0000	1.0000	0.0000	16.0000	1.0000	20.0000
	5.0000	10.0000	60.0000	5.0000	1000.0000	1.0000	13300.0000	1.5000	5.0000	1.0000	0.0000	16.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 1 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	262328
	4	1	1	409848
	4	1	1	416666
	4	1	1	420906
	4	1	1	443165
	4	1	1	448846
	4	1	1	740304
	4	1	1	753023
	4	1	1	941700
	4	1	1	945902
	4	1	1	1446575
	4	1	1	1571973
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	693948
	3	1	1	750548
	3	1	1	832649
	3	1	1	844548
	3	1	1	865028
	3	1	1	918827
	3	1	1	987166
	3	1	1	994466
	3	1	1	1010485
	3	1	1	1017167
	3	1	1	1020006
	3	1	1	1066326
	3	1	1	1123504
	3	1	1	1251124
	3	1	1	1316042
	3	1	1	1322602
	3	1	1	1433260
	3	1	1	1438140
	3	1	1	1486859
	3	1	1	1498540
	3	1	1	1612019
	3	1	1	1786276
	3	1	1	1826518
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	1	182560
	5	1	1	187079
	5	1	1	515674
	5	1	1	1011350
	5	1	1	1016169
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	862076
	2	1	1	988795
	2	1	1	1451330
	2	1	1	1810906
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	1659695
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	2	1	-1
	3	2	1	87475
	3	2	1	103136
	3	2	1	293174
	3	2	1	692931
	3	2	1	821027
	3	2	1	1200124
	3	2	1	1322563
	3	2	1	1328422
	3	2	1	1390101
	3	2	1	1438901
	3	2	1	1941136
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	1	631235
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	4	2	1	-1
	4	2	1	140366
	4	2	1	427742
	4	2	1	939616
	4	2	1	1056016
	4	2	1	1327694
	4	2	1	1399153
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	2	2	1	-1
	2	2	1	676285
	2	2	1	822224
	2	2	1	1048261
	2	2	1	1202899
	2	2	1	1593035
	2	2	1	1674315
	2	2	1	1692135
	2	2	1	1730273
	2	2	1	1738515
	2	2	1	1795892
	2	2	1	1836415
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	1	1289624
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	5	3	1	-1
	5	3	1	364678
	5	3	1	699555
	5	3	1	708035
	5	3	1	758915
	5	3	1	800435
	5	3	1	859133
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	3	3	1	-1
	3	3	1	528786
	3	3	1	537507
	3	3	1	693966
	3	3	1	737166
	3	3	1	812265
	3	3	1	903305
	3	3	1	1123061
	3	3	1	1222580
	3	3	1	1385239
	3	3	1	1436818
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	1	127957
	2	3	1	349055
	2	3	1	1075808
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	4	3	1	-1
	4	3	1	68623
	4	3	1	343961
	4	3	1	473101
	4	3	1	1008094
	4	3	1	1115653
	4	3	1	1245950
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	4	4	1	-1
	4	4	1	1443894
	4	4	1	1461355
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	1	4	1	-1
	1	4	1	28715
	1	4	1	134033
	1	4	1	145312
	1	4	1	1660919
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	5	4	1	-1
	5	4	1	22200
	5	4	1	26419
	5	4	1	143979
	5	4	1	332316
	5	4	1	336097
	5	4	1	341138
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	2	4	1	-1
	2	4	1	395440
	2	4	1	1755569
	2	4	1	1769408
	2	4	1	1773788
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	1210
	3	4	1	608503
	3	4	1	758263
	3	4	1	778242
	3	4	1	861581
	3	4	1	875661
	3	4	1	939322
	3	4	1	1077639
	3	4	1	1085599
	3	4	1	1088721
	3	4	1	1114619
	3	4	1	1119759
	3	4	1	1205258
	3	4	1	1436794
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	5	1	-1
	5	5	1	1140923
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	1	5	1	-1
	1	5	1	798671
	1	5	1	848692
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	3	5	1	-1
	3	5	1	709100
	3	5	1	1030594
	3	5	1	1065496
	3	5	1	1071196
	3	5	1	1189453
	3	5	1	1194392
	3	5	1	1269192
	3	5	1	1323631
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	2	5	1	-1
	2	5	1	1241999
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE