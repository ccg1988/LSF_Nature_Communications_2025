function x = M43s0272()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Tone Based';
x.analysis_code = 1850;
x.animal = 'M43s';
x.datetime = '14-Jan-2006 10:43:01';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 6;
x.starting_depth = 7000;
x.first_spike = 7447;
x.unit_depth = 7507;
x.unit_number = 13;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' Tones Per Octave' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	4.0000	1.0000	20.0000
	2.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	8.0000	1.0000	20.0000
	3.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
	4.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	32.0000	1.0000	20.0000
	5.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	64.0000	1.0000	20.0000
	6.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	128.0000	1.0000	20.0000
	7.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	256.0000	1.0000	20.0000
	8.0000	8.0000	40.0000	5.0000	1000.0000	0.0000	12900.0000	1.0000	2.0000	1.0000	0.0000	20.0000	512.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 4 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 8 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 32 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 64 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 6 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 128 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 7 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 256 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 8 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 12900 Bandwidth(Oct.) = 1 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 512 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	40.00	];
x.spkr_number = [	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	7	1	1	-1
	7	1	1	599659
	7	1	1	605919
	7	1	1	626856
	7	1	1	757118
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	4	1	1	-1
	4	1	1	602485
	4	1	1	917200
	4	1	1	974579
	4	1	1	1314337
	4	1	1	1357675
	4	1	1	1392855
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	697427
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	853293
	2	1	1	876133
	2	1	1	1101370
	2	1	1	1211109
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	1	670359
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	838046
	1	1	1	911964
	1	1	1	1095882
	1	1	1	1109701
	1	1	1	1118161
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	4	1094791
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	8	1	1	-1
	8	1	1	612079
	8	1	1	618799
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	1	2	1	-1
	1	2	1	570465
	1	2	1	610724
	1	2	1	629665
	1	2	1	637604
	1	2	1	644984
	1	2	1	848241
	1	2	1	870983
	1	2	1	1067061
	1	2	1	1350018
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	4	1348907
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	6	2	1	-1
	6	2	1	708669
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	1	616463
	5	2	1	628863
	5	2	1	646423
	5	2	1	653922
	5	2	1	767240
	5	2	1	890200
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	8	2	1	-1
	8	2	1	619328
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	4	2	1	-1
	4	2	1	632616
	4	2	1	645994
	4	2	1	653793
	4	2	1	778633
	4	2	1	786552
	4	2	1	1046949
	4	2	1	1273048
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	1	1016416
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	7	2	1	-1
	7	2	1	587187
	7	2	1	599387
	7	2	1	606644
	7	2	1	633246
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	1	3	1	-1
	1	3	1	1087505
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	6	3	1	-1
	6	3	1	588589
	6	3	1	624648
	6	3	1	678088
	6	3	1	694309
	6	3	1	712929
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	4	3	1	-1
	4	3	1	1102678
	4	3	1	1135895
	4	3	1	1325293
	4	3	1	1413434
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	8	3	1	-1
	8	3	1	323231
	8	3	1	600049
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	2	3	1	-1
	2	3	1	686255
	2	3	1	1360127
	2	3	1	1472364
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	1	4	1	-1
	1	4	1	622180
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	4	4	1	-1
	4	4	1	629137
	4	4	1	641237
	4	4	1	646637
	4	4	1	756596
	4	4	1	825416
	4	4	1	840094
	4	4	1	849115
	4	4	1	1068653
	4	4	1	1130093
	4	4	1	1191333
	4	4	1	1257570
	4	4	1	1394188
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	3	4	1	-1
	3	4	1	1192025
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	7	4	1	-1
	7	4	1	868298
	7	4	1	873799
	7	4	1	1269936
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	3	5	1	-1
	3	5	1	757527
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	2	5	1	-1
	2	5	1	1111508
	2	5	1	1367666
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	1	658939
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	8	5	1	-1
	8	5	1	1927792
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	5	5	1	-1
	5	5	1	1097148
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	7	5	1	-1
	7	5	1	584125
	7	5	1	604305
	7	5	1	616822
	7	5	1	819201
	7	5	1	930940
	7	5	1	1500815
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	1	5	1	-1
	1	5	1	560950
	1	5	1	570369
	1	5	1	575849
	1	5	1	585470
	1	5	1	594888
	1	5	1	617088
	1	5	1	844127
	1	5	1	1080105
	1	5	1	1086622
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE