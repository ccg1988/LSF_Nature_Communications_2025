function x = M43s0389()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'gclick';
x.analysis_code = 37;
x.animal = 'M43s';
x.datetime = '19-Jan-2006 12:02:42';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 3;
x.starting_depth = 8000;
x.first_spike = 8473;
x.unit_depth = 8900;
x.unit_number = 18;
x.cf = 7.5000;
x.threshold = 60.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 19;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 19'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Gaussian click sigma' ' in train with ICI of' ' msec. Fc' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	5.0000	496.0000	0.2000	2.0000	0.0000
	2.0000	2.0000	30.0000	5.0000	496.0000	0.2000	2.5000	0.0000
	3.0000	2.0000	30.0000	5.0000	496.0000	0.2000	3.0000	0.0000
	4.0000	2.0000	30.0000	5.0000	496.0000	0.2000	5.0000	0.0000
	5.0000	2.0000	30.0000	5.0000	496.0000	0.2000	7.5000	0.0000
	6.0000	2.0000	30.0000	5.0000	496.0000	0.2000	10.0000	0.0000
	7.0000	2.0000	30.0000	5.0000	496.0000	0.2000	15.0000	0.0000
	8.0000	2.0000	30.0000	5.0000	496.0000	0.2000	20.0000	0.0000
	9.0000	2.0000	30.0000	5.0000	496.0000	0.2000	25.0000	0.0000
	10.0000	2.0000	30.0000	5.0000	496.0000	0.2000	30.0000	0.0000
	11.0000	2.0000	30.0000	5.0000	496.0000	0.2000	35.0000	0.0000
	12.0000	2.0000	30.0000	5.0000	496.0000	0.2000	40.0000	0.0000
	13.0000	2.0000	30.0000	5.0000	496.0000	0.2000	45.0000	0.0000
	14.0000	2.0000	30.0000	5.0000	496.0000	0.2000	50.0000	0.0000
	15.0000	2.0000	30.0000	5.0000	496.0000	0.2000	55.0000	0.0000
	16.0000	2.0000	30.0000	5.0000	496.0000	0.2000	60.0000	0.0000
	17.0000	2.0000	30.0000	5.0000	496.0000	0.2000	65.0000	0.0000
	18.0000	2.0000	30.0000	5.0000	496.0000	0.2000	70.0000	0.0000
	19.0000	2.0000	30.0000	5.0000	496.0000	0.2000	75.0000	0.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Gaussian click (sigma 0.2) in train with ICI of 2 msec. Fc = 0 Hz'
	'Stimulus 2 : Gaussian click (sigma 0.2) in train with ICI of 2.5 msec. Fc = 0 Hz'
	'Stimulus 3 : Gaussian click (sigma 0.2) in train with ICI of 3 msec. Fc = 0 Hz'
	'Stimulus 4 : Gaussian click (sigma 0.2) in train with ICI of 5 msec. Fc = 0 Hz'
	'Stimulus 5 : Gaussian click (sigma 0.2) in train with ICI of 7.5 msec. Fc = 0 Hz'
	'Stimulus 6 : Gaussian click (sigma 0.2) in train with ICI of 10 msec. Fc = 0 Hz'
	'Stimulus 7 : Gaussian click (sigma 0.2) in train with ICI of 15 msec. Fc = 0 Hz'
	'Stimulus 8 : Gaussian click (sigma 0.2) in train with ICI of 20 msec. Fc = 0 Hz'
	'Stimulus 9 : Gaussian click (sigma 0.2) in train with ICI of 25 msec. Fc = 0 Hz'
	'Stimulus 10 : Gaussian click (sigma 0.2) in train with ICI of 30 msec. Fc = 0 Hz'
	'Stimulus 11 : Gaussian click (sigma 0.2) in train with ICI of 35 msec. Fc = 0 Hz'
	'Stimulus 12 : Gaussian click (sigma 0.2) in train with ICI of 40 msec. Fc = 0 Hz'
	'Stimulus 13 : Gaussian click (sigma 0.2) in train with ICI of 45 msec. Fc = 0 Hz'
	'Stimulus 14 : Gaussian click (sigma 0.2) in train with ICI of 50 msec. Fc = 0 Hz'
	'Stimulus 15 : Gaussian click (sigma 0.2) in train with ICI of 55 msec. Fc = 0 Hz'
	'Stimulus 16 : Gaussian click (sigma 0.2) in train with ICI of 60 msec. Fc = 0 Hz'
	'Stimulus 17 : Gaussian click (sigma 0.2) in train with ICI of 65 msec. Fc = 0 Hz'
	'Stimulus 18 : Gaussian click (sigma 0.2) in train with ICI of 70 msec. Fc = 0 Hz'
	'Stimulus 19 : Gaussian click (sigma 0.2) in train with ICI of 75 msec. Fc = 0 Hz'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	18	1	1	-1
	18	1	2	-1
	18	1	3	-1
	18	1	4	-1
	18	1	5	-1
	18	1	6	-1
	18	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	7	1	1	-1
	7	1	1	169430
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	17	1	1	-1
	17	1	1	523445
	17	1	1	1358856
	17	1	2	-1
	17	1	3	-1
	17	1	4	-1
	17	1	5	-1
	17	1	6	-1
	17	1	7	-1
	10	1	1	-1
	10	1	2	-1
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	16	1	1	-1
	16	1	2	-1
	16	1	3	-1
	16	1	4	-1
	16	1	5	-1
	16	1	6	-1
	16	1	7	-1
	9	1	1	-1
	9	1	2	-1
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	5	1	1	-1
	5	1	1	609200
	5	1	1	708899
	5	1	1	713621
	5	1	1	784018
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	12	1	1	-1
	12	1	2	-1
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	1	1	1	-1
	1	1	1	1388912
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	15	1	1	-1
	15	1	1	639279
	15	1	1	778395
	15	1	1	780077
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	19	1	1	-1
	19	1	1	22781
	19	1	2	-1
	19	1	3	-1
	19	1	4	-1
	19	1	5	-1
	19	1	6	-1
	19	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	11	1	1	-1
	11	1	1	976810
	11	1	1	1239367
	11	1	1	1240768
	11	1	2	-1
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	14	1	1	-1
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	2	1	1	-1
	2	1	1	130897
	2	1	1	1382062
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	17	2	1	-1
	17	2	1	309695
	17	2	2	-1
	17	2	3	-1
	17	2	4	-1
	17	2	5	-1
	17	2	6	-1
	17	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	18	2	1	-1
	18	2	1	694088
	18	2	2	-1
	18	2	3	-1
	18	2	4	-1
	18	2	5	-1
	18	2	6	-1
	18	2	7	-1
	6	2	1	-1
	6	2	1	1069781
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	10	2	1	-1
	10	2	1	1451378
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	16	2	1	-1
	16	2	1	801923
	16	2	2	-1
	16	2	3	-1
	16	2	4	-1
	16	2	5	-1
	16	2	6	-1
	16	2	7	-1
	19	2	1	-1
	19	2	2	-1
	19	2	3	-1
	19	2	4	-1
	19	2	5	-1
	19	2	6	-1
	19	2	7	-1
	13	2	1	-1
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	15	2	1	-1
	15	2	2	-1
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	11	2	1	-1
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	14	2	1	-1
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	9	2	1	-1
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	2	2	1	-1
	2	2	1	448801
	2	2	1	450141
	2	2	1	451481
	2	2	1	455980
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	8	3	1	-1
	8	3	1	916154
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	10	3	1	-1
	10	3	1	108741
	10	3	2	-1
	10	3	3	-1
	10	3	4	-1
	10	3	5	-1
	10	3	6	-1
	10	3	7	-1
	1	3	1	-1
	1	3	1	736793
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	17	3	1	-1
	17	3	1	1174208
	17	3	2	-1
	17	3	3	-1
	17	3	4	-1
	17	3	5	-1
	17	3	6	-1
	17	3	7	-1
	9	3	1	-1
	9	3	1	1427685
	9	3	1	1429185
	9	3	1	1487365
	9	3	2	-1
	9	3	3	-1
	9	3	4	-1
	9	3	5	-1
	9	3	6	-1
	9	3	7	-1
	18	3	1	-1
	18	3	2	-1
	18	3	3	-1
	18	3	4	-1
	18	3	5	-1
	18	3	6	-1
	18	3	7	-1
	4	3	1	-1
	4	3	1	345013
	4	3	1	1421302
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	13	3	1	-1
	13	3	2	-1
	13	3	3	-1
	13	3	4	-1
	13	3	5	-1
	13	3	6	-1
	13	3	7	-1
	19	3	1	-1
	19	3	1	185476
	19	3	1	187115
	19	3	2	-1
	19	3	3	-1
	19	3	4	-1
	19	3	5	-1
	19	3	6	-1
	19	3	7	-1
	14	3	1	-1
	14	3	1	381792
	14	3	2	-1
	14	3	3	-1
	14	3	4	-1
	14	3	5	-1
	14	3	6	-1
	14	3	7	-1
	16	3	1	-1
	16	3	2	-1
	16	3	3	-1
	16	3	4	-1
	16	3	5	-1
	16	3	6	-1
	16	3	7	-1
	2	3	1	-1
	2	3	1	1249080
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	11	3	1	-1
	11	3	1	840524
	11	3	1	888322
	11	3	2	-1
	11	3	3	-1
	11	3	4	-1
	11	3	5	-1
	11	3	6	-1
	11	3	7	-1
	12	3	1	-1
	12	3	1	627003
	12	3	1	1308997
	12	3	2	-1
	12	3	3	-1
	12	3	4	-1
	12	3	5	-1
	12	3	6	-1
	12	3	7	-1
	5	3	1	-1
	5	3	1	482204
	5	3	1	635981
	5	3	1	1063557
	5	3	1	1067396
	5	3	1	1244115
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	15	3	1	-1
	15	3	2	-1
	15	3	3	-1
	15	3	4	-1
	15	3	5	-1
	15	3	6	-1
	15	3	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE