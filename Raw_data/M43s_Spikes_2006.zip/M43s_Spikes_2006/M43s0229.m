function x = M43s0229()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'XB_SM: Tone Based';
x.analysis_code = 1850;
x.animal = 'M43s';
x.datetime = '13-Jan-2006 12:23:05';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 5;
x.starting_depth = 7000;
x.first_spike = 7706;
x.unit_depth = 7931;
x.unit_number = 12;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' XB_SM Noise_Tag' ' Center Frequency Hz' ' Bandwidth Oct.' ' SM rate Cycles Oct.' ' SMDepth' ' SMPhase Degrees' ' Tones Per Octave' ' AM Frequency Hz' ' AM Depth' ' Rise Fall time msec' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	60.0000	5.0000	1000.0000	0.0000	13300.0000	1.5000	1.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
	2.0000	10.0000	60.0000	5.0000	1000.0000	0.0000	13300.0000	1.5000	2.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
	3.0000	10.0000	60.0000	5.0000	1000.0000	0.0000	13300.0000	1.5000	3.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
	4.0000	10.0000	60.0000	5.0000	1000.0000	0.0000	13300.0000	1.5000	4.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
	5.0000	10.0000	60.0000	5.0000	1000.0000	0.0000	13300.0000	1.5000	5.0000	1.0000	0.0000	20.0000	16.0000	1.0000	20.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 1 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 2 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 2 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 3 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 3 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 4 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 4 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
	'Stimulus 5 : XB_SM: Noise_Tag = 0 Center Frequency(Hz) = 13300 Bandwidth(Oct.) = 1.5 SM rate(Cycles/Oct.) = 5 SMDepth = 1 SMPhase(Degrees) = 0 Tones Per Octave = 20 AM Frequency(Hz) = 16 AM Depth = 1 Rise/Fall time (msec) = 20'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	60.00	];
x.spkr_number = [	10.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	359889
	5	1	1	435526
	5	1	1	451526
	5	1	1	457667
	5	1	1	644905
	5	1	1	1218959
	5	1	1	1225478
	5	1	1	1326438
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	3	1	1	-1
	3	1	1	40478
	3	1	1	67497
	3	1	1	586309
	3	1	1	674989
	3	1	1	1430659
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	646477
	4	1	1	690714
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	1	1	1	-1
	1	1	1	1594869
	1	1	1	1732329
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	632104
	2	1	1	1443917
	2	1	1	1738894
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	2	1	-1
	4	2	1	1188987
	4	2	1	1208966
	4	2	1	1318182
	4	2	1	1509320
	4	2	1	1615461
	4	2	1	1627261
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	1	2	1	-1
	1	2	1	1726246
	1	2	1	1728904
	1	2	1	1845743
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	631884
	2	2	1	810101
	2	2	1	1060538
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	47554
	3	2	1	600109
	3	2	1	664568
	3	2	1	716426
	3	2	1	740567
	3	2	1	892925
	3	2	1	1182282
	3	2	1	1274501
	3	2	1	1366161
	3	2	1	1428601
	3	2	1	1487458
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	1	1479844
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	3	1	-1
	1	3	1	71261
	1	3	1	121124
	1	3	1	305102
	1	3	1	1662245
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	2	3	1	-1
	2	3	1	1328496
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	1	1193886
	3	3	1	1256166
	3	3	1	1260005
	3	3	1	1342725
	3	3	1	1348105
	3	3	1	1417205
	3	3	1	1429084
	3	3	1	1526024
	3	3	1	1877761
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	4	3	1	-1
	4	3	1	200402
	4	3	1	398002
	4	3	1	735096
	4	3	1	740477
	4	3	1	869636
	4	3	1	931153
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	3	4	1	-1
	3	4	1	237049
	3	4	1	301306
	3	4	1	386984
	3	4	1	411286
	3	4	1	692962
	3	4	1	903022
	3	4	1	959922
	3	4	1	976941
	3	4	1	1134277
	3	4	1	1255297
	3	4	1	1423716
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	4	4	1	-1
	4	4	1	631508
	4	4	1	1683277
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	1	4	1	-1
	1	4	1	474957
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	1	658838
	2	4	1	747618
	2	4	1	792497
	2	4	1	833217
	2	4	1	1129915
	2	4	1	1426532
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	1	227769
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	5	5	1	-1
	5	5	1	114014
	5	5	1	162196
	5	5	1	170433
	5	5	1	1183724
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	1	1069870
	2	5	1	1088351
	2	5	1	1374327
	2	5	1	1448587
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	1	1229656
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	370069
	1	5	1	890962
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	3	5	1	-1
	3	5	1	444336
	3	5	1	559393
	3	5	1	574193
	3	5	1	577971
	3	5	1	624834
	3	5	1	629733
	3	5	1	641933
	3	5	1	673311
	3	5	1	686973
	3	5	1	757749
	3	5	1	760671
	3	5	1	872190
	3	5	1	952969
	3	5	1	971908
	3	5	1	1011567
	3	5	1	1067868
	3	5	1	1111668
	3	5	1	1126747
	3	5	1	1136846
	3	5	1	1188185
	3	5	1	1207204
	3	5	1	1335904
	3	5	1	1437504
	3	5	1	1460543
	3	5	1	1463924
	3	5	1	1921638
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE