function x = M43s0487()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'sAM';
x.analysis_code = 51;
x.animal = 'M43s';
x.datetime = '22-Jan-2006 15:48:11';
x.hemisphere = 'Left';
x.hole_number = 2;
x.track_number = 6;
x.starting_depth = 10000;
x.first_spike = 10698;
x.unit_depth = 11291;
x.unit_number = 22;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'Sinusoidal AM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
' Call File Name = d:\data_acq\xblaster2\stimulus_files\Call_Types\peeptril_m87_t450da10_182.txt'
' Number of Frequency Bands = 4   8  16  32'
' Starting Frequency (Hz) = 2000'
' End Frequency (Hz) = 24000'
' Processing Method = Envelope/Fine Structure Processing'
' Original Envelope = 1'
' Flat Envelope = 0'
' Flag EnvLP = 0'
' Envelope Low Pass Filters = -1'
' Flag EnvHP = 0'
' Envelope High Pass Filters = -1'
' Original Fine Structure = 1'
' Noise Carrier = 1'
' Cosine Carrier = 1'
' Random Phase = 0'
' Flag FineDecre = 0'
' Fine Decre = -1'
' Flag FineSD = 0'
' Fine SD = -1'
' Band Pass Signal Spectrum Decrease Factor ='
' Energy Normalization = 0'
' Display Calls = 0'
' Bands Mode = Use All Processed Bands'
'4bands(3 bands really decomposed into):1.81983      4.39804      10.3339           24KHz'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Sinusoidal AM CF' ' KHz Depth' ' Modulation' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	4.0000
	2.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	8.0000
	3.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	16.0000
	4.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	32.0000
	5.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	64.0000
	6.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	128.0000
	7.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	256.0000
	8.0000	2.0000	50.0000	5.0000	1000.0000	7.0000	1.0000	512.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 4 (Hz)'
	'Stimulus 2 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 8 (Hz)'
	'Stimulus 3 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 16 (Hz)'
	'Stimulus 4 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 32 (Hz)'
	'Stimulus 5 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 64 (Hz)'
	'Stimulus 6 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 128 (Hz)'
	'Stimulus 7 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 256 (Hz)'
	'Stimulus 8 : Sinusoidal AM: CF = 7 (KHz), Depth = 1, Modulation = 512 (Hz)'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	50.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	35238
	5	1	1	695391
	5	1	1	729573
	5	1	1	794290
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	1	1	-1
	4	1	1	622359
	4	1	1	915176
	4	1	1	1118052
	4	1	1	1472009
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	1	1	-1
	6	1	1	440382
	6	1	1	478141
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	6	2	1	-1
	6	2	1	1671532
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	4	2	1	-1
	4	2	1	542289
	4	2	1	557869
	4	2	1	610008
	4	2	1	742328
	4	2	1	765728
	4	2	1	858506
	4	2	1	1051044
	4	2	1	1078584
	4	2	1	1114963
	4	2	1	1121323
	4	2	1	1178885
	4	2	1	1291982
	4	2	1	1310363
	4	2	1	1484279
	4	2	1	1544581
	4	2	1	1698018
	4	2	1	1722597
	4	2	1	1733578
	4	2	1	1771857
	4	2	1	1814057
	4	2	1	1827495
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	1	564514
	3	2	1	1064050
	3	2	1	1351025
	3	2	1	1844340
	3	2	1	1907320
	3	2	1	1928960
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	3	1	-1
	7	3	1	202764
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	1	3	1	-1
	1	3	1	500188
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	1	1675943
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	4	3	1	-1
	4	3	1	554525
	4	3	1	578025
	4	3	1	640382
	4	3	1	676183
	4	3	1	753422
	4	3	1	858260
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	1	4	1	-1
	1	4	1	1747626
	1	4	1	1766045
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	102506
	4	4	1	114606
	4	4	1	1570710
	4	4	1	1580153
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	5	4	1	-1
	5	4	1	635092
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	3	4	1	-1
	3	4	1	568557
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	2	4	1	-1
	2	4	1	1838511
	2	4	1	1843169
	2	4	1	1851871
	2	4	1	1899531
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	6	5	1	-1
	6	5	1	292530
	6	5	1	315450
	6	5	1	347391
	6	5	1	1711158
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	4	5	1	-1
	4	5	1	562454
	4	5	1	1065951
	4	5	1	1657504
	4	5	1	1669423
	4	5	1	1734022
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	2	5	1	-1
	2	5	1	626083
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	5	5	1	-1
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	7	5	1	-1
	7	5	1	1797922
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE