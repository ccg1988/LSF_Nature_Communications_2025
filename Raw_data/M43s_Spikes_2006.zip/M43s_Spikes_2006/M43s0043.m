function x = M43s0043()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M43s';
x.datetime = '10-Jan-2006 13:24:21';
x.hemisphere = 'Left';
x.hole_number = 1;
x.track_number = 1;
x.starting_depth = 6000;
x.first_spike = 6167;
x.unit_depth = 6485;
x.unit_number = 2;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 5;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 5'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	12.0000	20.0000	5.0000	200.0000	6.0000	0.2500	2945151776.0000	2770577231.0000
	2.0000	12.0000	20.0000	5.0000	200.0000	6.0000	0.5000	3210145775.0000	695726334.0000
	3.0000	12.0000	20.0000	5.0000	200.0000	6.0000	1.0000	2234433309.0000	475134814.0000
	4.0000	12.0000	20.0000	5.0000	200.0000	6.0000	2.0000	1207945178.0000	1892609636.0000
	5.0000	12.0000	20.0000	5.0000	200.0000	6.0000	4.0000	3616648944.0000	4133083491.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  6       Bandwidth  0.25, randn_seed 2945151776 2770577231'
	'Stimulus 2 : NOISE: Center Frequency  6       Bandwidth  0.5, randn_seed 3210145775 695726334'
	'Stimulus 3 : NOISE: Center Frequency  6       Bandwidth  1, randn_seed 2234433309 475134814'
	'Stimulus 4 : NOISE: Center Frequency  6       Bandwidth  2, randn_seed 1207945178 1892609636'
	'Stimulus 5 : NOISE: Center Frequency  6       Bandwidth  4, randn_seed 3616648944 4133083491'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	20.00	];
x.spkr_number = [	12.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	75297
	5	1	1	109739
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	3	1	1	-1
	3	1	1	88698
	3	1	1	130575
	3	1	1	140196
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	1	1	1	-1
	1	1	1	215731
	1	1	1	220251
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	2	1	1	-1
	2	1	1	393206
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	4	2	1	-1
	4	2	1	124267
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	2	2	1	-1
	2	2	1	174824
	2	2	1	423222
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	1	31983
	5	2	1	65842
	5	2	1	68942
	5	2	1	74224
	5	2	1	79401
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	2	1	-1
	1	2	1	605434
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	3	1	-1
	2	3	1	6420
	2	3	1	50717
	2	3	1	60858
	2	3	1	64779
	2	3	1	70999
	2	3	1	193738
	2	3	1	387895
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	3	1	-1
	1	3	1	669469
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	4	3	1	-1
	4	3	1	208051
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	3	3	1	-1
	3	3	1	647663
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	5	4	1	-1
	5	4	1	114148
	5	4	1	121769
	5	4	1	134369
	5	4	1	138429
	5	4	1	202488
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	3	4	1	-1
	3	4	1	23388
	3	4	1	46786
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	1	4	1	-1
	1	4	1	497699
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	4	4	1	-1
	4	4	1	656218
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	1	64484
	2	4	1	73304
	2	4	1	481677
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	2	5	1	-1
	2	5	1	416278
	2	5	1	474035
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	1	630072
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	596529
	1	5	1	603389
	1	5	1	687389
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	3	5	1	-1
	3	5	1	164132
	3	5	1	218333
	3	5	1	658389
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	5	5	1	-1
	5	5	1	618806
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE