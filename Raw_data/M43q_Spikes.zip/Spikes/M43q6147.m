function x = M43q6147()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-AM';
x.analysis_code = 55;
x.animal = 'M43q';
x.datetime = '08-Jun-2007 16:53:13';
x.hemisphere = 'Right';
x.hole_number = 12;
x.track_number = 2;
x.starting_depth = 10000;
x.first_spike = 10520;
x.unit_depth = 11789;
x.unit_number = 751;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'WB Noise AM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' WB Noise AM Depth' ' Modulation' ' Hz randn_seed' ' Hz randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	4.0000	148854849.0000	3265898748.0000
	2.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	8.0000	1072053030.0000	218280358.0000
	3.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	16.0000	2068832030.0000	1901902997.0000
	4.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	32.0000	2849389160.0000	2562711587.0000
	5.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	64.0000	961165192.0000	672034832.0000
	6.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	128.0000	2298475760.0000	2406678153.0000
	7.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	256.0000	3732698791.0000	2529022145.0000
	8.0000	2.0000	10.0000	5.0000	1000.0000	1.0000	512.0000	1704989702.0000	212640576.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : WB Noise AM: Depth = 1, Modulation = 4 (Hz), randn_seed = 148854849 3265898748'
	'Stimulus 2 : WB Noise AM: Depth = 1, Modulation = 8 (Hz), randn_seed = 1072053030 218280358'
	'Stimulus 3 : WB Noise AM: Depth = 1, Modulation = 16 (Hz), randn_seed = 2068832030 1901902997'
	'Stimulus 4 : WB Noise AM: Depth = 1, Modulation = 32 (Hz), randn_seed = 2849389160 2562711587'
	'Stimulus 5 : WB Noise AM: Depth = 1, Modulation = 64 (Hz), randn_seed = 961165192 672034832'
	'Stimulus 6 : WB Noise AM: Depth = 1, Modulation = 128 (Hz), randn_seed = 2298475760 2406678153'
	'Stimulus 7 : WB Noise AM: Depth = 1, Modulation = 256 (Hz), randn_seed = 3732698791 2529022145'
	'Stimulus 8 : WB Noise AM: Depth = 1, Modulation = 512 (Hz), randn_seed = 1704989702 212640576'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	10.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	6	1	1	-1
	6	1	1	1834780
	6	1	1	1918459
	6	1	1	1925721
	6	1	1	1938120
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	2	1	1	-1
	2	1	1	968558
	2	1	1	1888967
	2	1	1	1896088
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	7	1	1	-1
	7	1	1	1220759
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	1	1	1	-1
	1	1	1	938070
	1	1	1	1413602
	1	1	1	1452482
	1	1	1	1467101
	1	1	1	1530563
	1	1	1	1736179
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	8	1	1	-1
	8	1	1	113164
	8	1	1	122004
	8	1	1	183721
	8	1	1	489941
	8	1	1	1493707
	8	1	1	1613808
	8	1	1	1697047
	8	1	1	1708327
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	4	1	1	-1
	4	1	1	71390
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	1	734412
	5	1	1	880611
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	5	2	1	-1
	5	2	1	948815
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	3	2	1	-1
	3	2	1	458448
	3	2	1	1028502
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	6	2	1	-1
	6	2	1	105874
	6	2	1	1157764
	6	2	1	1221124
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	4	2	1	-1
	4	2	1	98419
	4	2	1	423155
	4	2	1	766192
	4	2	1	1823143
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	3	3	1	-1
	3	3	1	347885
	3	3	1	742720
	3	3	1	793099
	3	3	1	1408891
	3	3	1	1425953
	3	3	1	1435911
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	8	3	1	-1
	8	3	1	174596
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	4	3	1	-1
	4	3	1	10741
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	6	3	1	-1
	6	3	1	1899526
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	7	3	1	-1
	7	3	1	1293092
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	2	3	1	-1
	2	3	1	666180
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	1	965020
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	7	4	1	-1
	7	4	1	181451
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	3	4	1	-1
	3	4	1	1599940
	3	4	1	1632199
	3	4	1	1675498
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	1	4	1	-1
	1	4	1	262939
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	7	5	1	-1
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	3	5	1	-1
	3	5	1	1546174
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	2	5	1	-1
	2	5	1	956645
	2	5	1	964065
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	1	1441803
	4	5	1	1916418
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	1	5	1	-1
	1	5	1	635376
	1	5	1	646175
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	5	5	1	-1
	5	5	1	132204
	5	5	1	1536708
	5	5	1	1550770
	5	5	1	1557110
	5	5	1	1607628
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE