function x = M50p4491()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '16-Jun-2005 11:12:59';
x.hemisphere = 'Left';
x.hole_number = 27;
x.track_number = 11;
x.starting_depth = 4000;
x.first_spike = 4257;
x.unit_depth = 4445;
x.unit_number = 681;
x.cf = 1.8000;
x.threshold = 30.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	6.0000	30.0000	2.0000	200.0000	10.0000	2.0000	3949085815.0000	4036550578.0000
	2.0000	7.0000	30.0000	2.0000	200.0000	10.0000	2.0000	3949085815.0000	4036550578.0000
	3.0000	10.0000	30.0000	2.0000	200.0000	10.0000	2.0000	3949085815.0000	4036550578.0000
	4.0000	13.0000	30.0000	2.0000	200.0000	10.0000	2.0000	3949085815.0000	4036550578.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3949085815 4036550578'
	'Stimulus 2 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3949085815 4036550578'
	'Stimulus 3 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3949085815 4036550578'
	'Stimulus 4 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3949085815 4036550578'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	231	192	87	295
	32	206	50	298
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	6.00	7.00	10.00	13.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	1	1	1	-1
	1	1	1	71244
	1	1	1	119182
	1	1	1	231061
	1	1	1	247781
	1	1	1	286002
	1	1	1	323560
	1	1	1	328181
	1	1	1	329903
	1	1	1	373542
	1	1	1	404642
	1	1	1	432619
	1	1	1	443880
	1	1	1	475078
	1	1	1	549338
	1	1	1	555739
	1	1	1	594758
	1	1	1	600978
	1	1	1	679039
	1	1	2	-1
	1	1	2	269241
	1	1	2	360524
	1	1	2	387462
	1	1	2	437300
	1	1	2	447561
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	1	1	-1
	4	1	1	165914
	4	1	1	175135
	4	1	1	237955
	4	1	1	244255
	4	1	1	254016
	4	1	1	376194
	4	1	1	453652
	4	1	1	639170
	4	1	2	-1
	4	1	2	247753
	4	1	2	334894
	4	1	2	387773
	4	1	2	422474
	4	1	2	435674
	4	1	2	444853
	4	1	2	458733
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	2	1	1	-1
	2	1	1	654181
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	2	349799
	3	1	2	445659
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	2	1	-1
	2	2	1	40640
	2	2	1	105258
	2	2	1	109339
	2	2	1	675594
	2	2	1	676652
	2	2	1	680193
	2	2	2	-1
	2	2	2	14742
	2	2	2	41800
	2	2	2	86000
	2	2	2	98520
	2	2	2	124901
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	4	2	1	-1
	4	2	1	239891
	4	2	1	245593
	4	2	1	266592
	4	2	2	-1
	4	2	2	237651
	4	2	2	254673
	4	2	2	302411
	4	2	2	335450
	4	2	2	351549
	4	2	2	426171
	4	2	2	523988
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	2	306402
	3	2	2	356125
	3	2	2	425803
	3	2	2	448543
	3	2	2	690881
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	1	69383
	1	2	1	204201
	1	2	1	262960
	1	2	1	343398
	1	2	1	358159
	1	2	1	383799
	1	2	1	420538
	1	2	1	442437
	1	2	2	-1
	1	2	2	31684
	1	2	2	376221
	1	2	2	425840
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE