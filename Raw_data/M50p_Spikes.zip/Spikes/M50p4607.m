function x = M50p4607()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'BP-noise';
x.analysis_code = 62;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 12:30:02';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6230;
x.unit_number = 687;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = '';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 20;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 20'
'Signal = White Noise Band Pass Filtered'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Frequency is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	10.0000	5.0000	200.0000	1.0000	1.0000	1529677795.0000	1389442949.0000
	2.0000	2.0000	10.0000	5.0000	200.0000	2.0000	1.0000	2164094538.0000	402638545.0000
	3.0000	2.0000	10.0000	5.0000	200.0000	3.0000	1.0000	1528479936.0000	3488311176.0000
	4.0000	2.0000	10.0000	5.0000	200.0000	4.0000	1.0000	141489342.0000	3396827575.0000
	5.0000	2.0000	10.0000	5.0000	200.0000	5.0000	1.0000	4040743477.0000	1288019444.0000
	6.0000	2.0000	10.0000	5.0000	200.0000	6.0000	1.0000	3858220417.0000	868869506.0000
	7.0000	2.0000	10.0000	5.0000	200.0000	7.0000	1.0000	2456893955.0000	315974003.0000
	8.0000	2.0000	10.0000	5.0000	200.0000	8.0000	1.0000	3654391515.0000	4074158787.0000
	9.0000	2.0000	10.0000	5.0000	200.0000	9.0000	1.0000	878093746.0000	3067335230.0000
	10.0000	2.0000	10.0000	5.0000	200.0000	10.0000	1.0000	1735677734.0000	3005141536.0000
	11.0000	2.0000	10.0000	5.0000	200.0000	11.0000	1.0000	3067502740.0000	588652186.0000
	12.0000	2.0000	10.0000	5.0000	200.0000	12.0000	1.0000	670778577.0000	83408382.0000
	13.0000	2.0000	10.0000	5.0000	200.0000	13.0000	1.0000	2323611660.0000	3982654219.0000
	14.0000	2.0000	10.0000	5.0000	200.0000	14.0000	1.0000	380062911.0000	2298035492.0000
	15.0000	2.0000	10.0000	5.0000	200.0000	15.0000	1.0000	688303625.0000	3652602166.0000
	16.0000	2.0000	10.0000	5.0000	200.0000	16.0000	1.0000	3246175492.0000	69346021.0000
	17.0000	2.0000	10.0000	5.0000	200.0000	17.0000	1.0000	3302094399.0000	1926786522.0000
	18.0000	2.0000	10.0000	5.0000	200.0000	18.0000	1.0000	4265149273.0000	2940804685.0000
	19.0000	2.0000	10.0000	5.0000	200.0000	19.0000	1.0000	2498306591.0000	3023244880.0000
	20.0000	2.0000	10.0000	5.0000	200.0000	20.0000	1.0000	53869537.0000	1392279849.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  1       Bandwidth  1, randn_seed 1529677795 1389442949'
	'Stimulus 2 : NOISE: Center Frequency  2       Bandwidth  1, randn_seed 2164094538 402638545'
	'Stimulus 3 : NOISE: Center Frequency  3       Bandwidth  1, randn_seed 1528479936 3488311176'
	'Stimulus 4 : NOISE: Center Frequency  4       Bandwidth  1, randn_seed 141489342 3396827575'
	'Stimulus 5 : NOISE: Center Frequency  5       Bandwidth  1, randn_seed 4040743477 1288019444'
	'Stimulus 6 : NOISE: Center Frequency  6       Bandwidth  1, randn_seed 3858220417 868869506'
	'Stimulus 7 : NOISE: Center Frequency  7       Bandwidth  1, randn_seed 2456893955 315974003'
	'Stimulus 8 : NOISE: Center Frequency  8       Bandwidth  1, randn_seed 3654391515 4074158787'
	'Stimulus 9 : NOISE: Center Frequency  9       Bandwidth  1, randn_seed 878093746 3067335230'
	'Stimulus 10 : NOISE: Center Frequency  10       Bandwidth  1, randn_seed 1735677734 3005141536'
	'Stimulus 11 : NOISE: Center Frequency  11       Bandwidth  1, randn_seed 3067502740 588652186'
	'Stimulus 12 : NOISE: Center Frequency  12       Bandwidth  1, randn_seed 670778577 83408382'
	'Stimulus 13 : NOISE: Center Frequency  13       Bandwidth  1, randn_seed 2323611660 3982654219'
	'Stimulus 14 : NOISE: Center Frequency  14       Bandwidth  1, randn_seed 380062911 2298035492'
	'Stimulus 15 : NOISE: Center Frequency  15       Bandwidth  1, randn_seed 688303625 3652602166'
	'Stimulus 16 : NOISE: Center Frequency  16       Bandwidth  1, randn_seed 3246175492 69346021'
	'Stimulus 17 : NOISE: Center Frequency  17       Bandwidth  1, randn_seed 3302094399 1926786522'
	'Stimulus 18 : NOISE: Center Frequency  18       Bandwidth  1, randn_seed 4265149273 2940804685'
	'Stimulus 19 : NOISE: Center Frequency  19       Bandwidth  1, randn_seed 2498306591 3023244880'
	'Stimulus 20 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 53869537 1392279849'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	111	286	150	289	118	259	187	85	102	257	157	12	5	223	241	248	139	28	197	47
	41	59	162	4	157	119	138	259	10	137	68	49	208	157	25	221	148	193	293	240
 ];
x.attenuation = [	10.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	11	1	1	-1
	11	1	2	-1
	11	1	2	615948
	11	1	3	-1
	11	1	4	-1
	11	1	5	-1
	11	1	6	-1
	11	1	7	-1
	1	1	1	-1
	1	1	2	-1
	1	1	2	189167
	1	1	2	478884
	1	1	2	501604
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	19	1	1	-1
	19	1	2	-1
	19	1	2	311304
	19	1	2	347381
	19	1	2	422361
	19	1	2	678601
	19	1	3	-1
	19	1	4	-1
	19	1	5	-1
	19	1	6	-1
	19	1	7	-1
	12	1	1	-1
	12	1	2	-1
	12	1	2	416197
	12	1	2	510734
	12	1	2	580954
	12	1	2	663493
	12	1	3	-1
	12	1	4	-1
	12	1	5	-1
	12	1	6	-1
	12	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	2	229196
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	2	407627
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	20	1	1	-1
	20	1	2	-1
	20	1	2	428061
	20	1	2	634679
	20	1	2	693939
	20	1	3	-1
	20	1	4	-1
	20	1	5	-1
	20	1	6	-1
	20	1	7	-1
	17	1	1	-1
	17	1	2	-1
	17	1	2	33202
	17	1	3	-1
	17	1	4	-1
	17	1	5	-1
	17	1	6	-1
	17	1	7	-1
	16	1	1	-1
	16	1	2	-1
	16	1	2	401932
	16	1	3	-1
	16	1	4	-1
	16	1	5	-1
	16	1	6	-1
	16	1	7	-1
	14	1	1	-1
	14	1	2	-1
	14	1	3	-1
	14	1	4	-1
	14	1	5	-1
	14	1	6	-1
	14	1	7	-1
	8	1	1	-1
	8	1	2	-1
	8	1	2	224761
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	13	1	1	-1
	13	1	2	-1
	13	1	3	-1
	13	1	4	-1
	13	1	5	-1
	13	1	6	-1
	13	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	18	1	1	-1
	18	1	2	-1
	18	1	3	-1
	18	1	4	-1
	18	1	5	-1
	18	1	6	-1
	18	1	7	-1
	2	1	1	-1
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	15	1	1	-1
	15	1	2	-1
	15	1	3	-1
	15	1	4	-1
	15	1	5	-1
	15	1	6	-1
	15	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	9	1	1	-1
	9	1	2	-1
	9	1	2	218344
	9	1	3	-1
	9	1	4	-1
	9	1	5	-1
	9	1	6	-1
	9	1	7	-1
	10	1	1	-1
	10	1	2	-1
	10	1	2	604236
	10	1	3	-1
	10	1	4	-1
	10	1	5	-1
	10	1	6	-1
	10	1	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	15	2	1	-1
	15	2	2	-1
	15	2	2	418229
	15	2	3	-1
	15	2	4	-1
	15	2	5	-1
	15	2	6	-1
	15	2	7	-1
	19	2	1	-1
	19	2	2	-1
	19	2	3	-1
	19	2	4	-1
	19	2	5	-1
	19	2	6	-1
	19	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	10	2	1	-1
	10	2	2	-1
	10	2	3	-1
	10	2	4	-1
	10	2	5	-1
	10	2	6	-1
	10	2	7	-1
	9	2	1	-1
	9	2	2	-1
	9	2	3	-1
	9	2	4	-1
	9	2	5	-1
	9	2	6	-1
	9	2	7	-1
	12	2	1	-1
	12	2	2	-1
	12	2	3	-1
	12	2	4	-1
	12	2	5	-1
	12	2	6	-1
	12	2	7	-1
	14	2	1	-1
	14	2	2	-1
	14	2	3	-1
	14	2	4	-1
	14	2	5	-1
	14	2	6	-1
	14	2	7	-1
	11	2	1	-1
	11	2	2	-1
	11	2	3	-1
	11	2	4	-1
	11	2	5	-1
	11	2	6	-1
	11	2	7	-1
	16	2	1	-1
	16	2	2	-1
	16	2	2	572364
	16	2	3	-1
	16	2	4	-1
	16	2	5	-1
	16	2	6	-1
	16	2	7	-1
	18	2	1	-1
	18	2	2	-1
	18	2	3	-1
	18	2	4	-1
	18	2	5	-1
	18	2	6	-1
	18	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	6	2	1	-1
	6	2	2	-1
	6	2	2	426288
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	13	2	1	-1
	13	2	2	-1
	13	2	3	-1
	13	2	4	-1
	13	2	5	-1
	13	2	6	-1
	13	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	17	2	1	-1
	17	2	2	-1
	17	2	2	419229
	17	2	3	-1
	17	2	4	-1
	17	2	5	-1
	17	2	6	-1
	17	2	7	-1
	20	2	1	-1
	20	2	2	-1
	20	2	3	-1
	20	2	4	-1
	20	2	5	-1
	20	2	6	-1
	20	2	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE