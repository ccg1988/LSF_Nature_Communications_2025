function x = M50p4495()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '16-Jun-2005 11:17:15';
x.hemisphere = 'Left';
x.hole_number = 27;
x.track_number = 11;
x.starting_depth = 4000;
x.first_spike = 4257;
x.unit_depth = 4445;
x.unit_number = 681;
x.cf = 1.8000;
x.threshold = 30.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	4.0000	30.0000	2.0000	200.0000	10.0000	2.0000	943348594.0000	4069089466.0000
	2.0000	9.0000	30.0000	2.0000	200.0000	10.0000	2.0000	943348594.0000	4069089466.0000
	3.0000	11.0000	30.0000	2.0000	200.0000	10.0000	2.0000	943348594.0000	4069089466.0000
	4.0000	15.0000	30.0000	2.0000	200.0000	10.0000	2.0000	943348594.0000	4069089466.0000
	5.0000	16.0000	30.0000	2.0000	200.0000	10.0000	2.0000	943348594.0000	4069089466.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 943348594 4069089466'
	'Stimulus 2 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 943348594 4069089466'
	'Stimulus 3 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 943348594 4069089466'
	'Stimulus 4 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 943348594 4069089466'
	'Stimulus 5 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 943348594 4069089466'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	268	228	280	276	225
	133	276	298	201	21
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	4.00	9.00	11.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	440454
	5	1	1	441536
	5	1	2	-1
	5	1	2	443057
	5	1	2	447196
	5	1	2	684256
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	128915
	2	1	1	588908
	2	1	2	-1
	2	1	2	258153
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	2	123147
	3	1	2	145027
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	69579
	4	1	1	99258
	4	1	1	284577
	4	1	1	324057
	4	1	1	366215
	4	1	2	-1
	4	1	2	88339
	4	1	2	287139
	4	1	2	345615
	4	1	2	379937
	4	1	2	622774
	4	1	2	632016
	4	1	2	696394
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	1	1	1	-1
	1	1	1	85491
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	1	2	1	-1
	1	2	1	100025
	1	2	1	155265
	1	2	1	581939
	1	2	1	594140
	1	2	1	664421
	1	2	1	676140
	1	2	1	684358
	1	2	1	685379
	1	2	2	-1
	1	2	2	127466
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	2	2	1	-1
	2	2	1	43781
	2	2	1	55201
	2	2	1	137261
	2	2	1	158639
	2	2	1	567977
	2	2	2	-1
	2	2	2	683875
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	3	2	1	-1
	3	2	1	33274
	3	2	1	135313
	3	2	1	189432
	3	2	1	377529
	3	2	1	462088
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	1	25406
	5	2	1	120826
	5	2	1	220563
	5	2	1	570059
	5	2	1	585820
	5	2	1	604200
	5	2	1	613899
	5	2	1	649560
	5	2	1	657202
	5	2	2	-1
	5	2	2	85066
	5	2	2	427061
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	4	2	1	-1
	4	2	1	37323
	4	2	1	63962
	4	2	1	380360
	4	2	1	382160
	4	2	1	396939
	4	2	1	436480
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE