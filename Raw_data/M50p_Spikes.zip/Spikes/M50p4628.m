function x = M50p4628()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 13:29:08';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	1.0000	200.0000	20.0000	1.0000	2749694785.0000	2626533196.0000
	2.0000	3.0000	30.0000	1.0000	200.0000	20.0000	1.0000	2749694785.0000	2626533196.0000
	3.0000	4.0000	30.0000	1.0000	200.0000	20.0000	1.0000	2749694785.0000	2626533196.0000
	4.0000	5.0000	30.0000	1.0000	200.0000	20.0000	1.0000	2749694785.0000	2626533196.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 2749694785 2626533196'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 2749694785 2626533196'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 2749694785 2626533196'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 2749694785 2626533196'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	215	152	133	44
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	2	1	1	-1
	2	1	1	18505
	2	1	1	32344
	2	1	1	40184
	2	1	1	47604
	2	1	1	50727
	2	1	1	62246
	2	1	1	76804
	2	1	1	170143
	2	1	1	326142
	2	1	1	338803
	2	1	1	353561
	2	1	1	509681
	2	1	1	608559
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	85320
	1	1	1	217037
	1	1	1	222777
	1	1	1	247697
	1	1	1	308217
	1	1	1	323676
	1	1	1	345998
	1	1	1	360337
	1	1	1	421756
	1	1	1	503874
	1	1	1	510675
	1	1	1	518035
	1	1	1	536055
	1	1	2	-1
	1	1	2	508855
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	1	1	-1
	3	1	1	86734
	3	1	1	102073
	3	1	1	114332
	3	1	1	314211
	3	1	1	325130
	3	1	1	338230
	3	1	1	361970
	3	1	1	381650
	3	1	1	422711
	3	1	1	445369
	3	1	1	452430
	3	1	1	496028
	3	1	1	519389
	3	1	1	537347
	3	1	1	545127
	3	1	2	-1
	3	1	2	602390
	3	1	2	610310
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	259087
	4	1	1	278927
	4	1	1	297767
	4	1	1	332505
	4	1	1	348486
	4	1	1	358765
	4	1	1	380726
	4	1	1	390668
	4	1	1	417364
	4	1	1	456245
	4	1	1	467985
	4	1	1	490844
	4	1	1	528123
	4	1	1	632744
	4	1	1	650882
	4	1	1	655463
	4	1	1	685023
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE