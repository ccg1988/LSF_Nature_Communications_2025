function x = M50p4705()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'sFM';
x.analysis_code = 52;
x.animal = 'M50p';
x.datetime = '27-Jun-2005 10:03:23';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 7;
x.starting_depth = 6000;
x.first_spike = 6597;
x.unit_depth = 7028;
x.unit_number = 695;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'Sinusoidal FM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
'InterStimulus Interval = 1000'
'Frequency is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Sinusoidal FM CF' ' KHz Depth' ' Hz Modulation' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	4.0000
	2.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	8.0000
	3.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	16.0000
	4.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	32.0000
	5.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	64.0000
	6.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	128.0000
	7.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	256.0000
	8.0000	2.0000	30.0000	5.0000	1000.0000	15.0000	128.0000	512.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 4 (Hz)'
	'Stimulus 2 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 8 (Hz)'
	'Stimulus 3 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 16 (Hz)'
	'Stimulus 4 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 32 (Hz)'
	'Stimulus 5 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 64 (Hz)'
	'Stimulus 6 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 128 (Hz)'
	'Stimulus 7 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 256 (Hz)'
	'Stimulus 8 : Sinusoidal FM: CF = 15 (KHz), Depth = 128 (Hz), Modulation = 512 (Hz)'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 500;
x.iti_max = 1000;
x.iti = [
	660	600	565	556	967	601	837	865
	545	873	612	821	510	719	825	950
	848	780	946	860	645	885	924	764
	940	907	637	640	878	802	868	855
	670	569	800	571	683	945	695	628
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	6	1	1	-1
	6	1	1	1556333
	6	1	1	1560153
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	5	1	1	-1
	5	1	1	540078
	5	1	1	545557
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	8	1	1	-1
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	1557593
	1	1	1	1562295
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	7	1	1	-1
	7	1	1	1962804
	7	1	1	1989023
	7	1	1	1998383
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	2	1	1	-1
	2	1	1	553308
	2	1	1	559368
	2	1	1	563908
	2	1	1	568607
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	2	1	-1
	6	2	1	1694353
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	3	2	1	-1
	3	2	1	1692041
	3	2	1	1714339
	3	2	1	1747479
	3	2	1	1762418
	3	2	1	1769018
	3	2	1	1978838
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	2	3	1	-1
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	1	3	1	-1
	1	3	1	567430
	1	3	1	571309
	1	3	1	579730
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	7	3	1	-1
	7	3	1	1564210
	7	3	1	1632208
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	8	3	1	-1
	8	3	1	1614241
	8	3	1	1628742
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	6	3	1	-1
	6	3	1	381985
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	8	4	1	-1
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	4	4	1	-1
	4	4	1	1461071
	4	4	1	1553709
	4	4	1	1563628
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	6	4	1	-1
	6	4	1	15119
	6	4	1	381276
	6	4	1	426734
	6	4	1	539613
	6	4	1	546793
	6	4	1	551554
	6	4	1	1565844
	6	4	1	1668802
	6	4	1	1840098
	6	4	1	1882159
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	1	4	1	-1
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	3	4	1	-1
	3	4	1	1546261
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	2	4	1	-1
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	2	5	1	-1
	2	5	1	554404
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	7	5	1	-1
	7	5	1	105682
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	1	5	1	-1
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	5	5	1	-1
	5	5	1	561417
	5	5	1	592617
	5	5	1	598657
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	4	5	1	-1
	4	5	1	594289
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE