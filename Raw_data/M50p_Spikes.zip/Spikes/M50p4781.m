function x = M50p4781()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-AM';
x.analysis_code = 55;
x.animal = 'M50p';
x.datetime = '28-Jun-2005 12:20:32';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 8;
x.starting_depth = 6000;
x.first_spike = 6167;
x.unit_depth = 7240;
x.unit_number = 699;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'WB Noise AM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
'InterStimulus Interval = 1000'
'Frequency is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' WB Noise AM Depth' ' Modulation' ' Hz randn_seed' ' Hz randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	4.0000	72525921.0000	1304880594.0000
	2.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	8.0000	3488504003.0000	3882442981.0000
	3.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	16.0000	992298650.0000	3256070655.0000
	4.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	32.0000	3743956551.0000	2856656784.0000
	5.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	64.0000	616822435.0000	3517892253.0000
	6.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	128.0000	1425039446.0000	3655420512.0000
	7.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	256.0000	3242668480.0000	2790856395.0000
	8.0000	2.0000	50.0000	5.0000	1000.0000	1.0000	512.0000	1276110405.0000	2566645458.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : WB Noise AM: Depth = 1, Modulation = 4 (Hz), randn_seed = 72525921 1304880594'
	'Stimulus 2 : WB Noise AM: Depth = 1, Modulation = 8 (Hz), randn_seed = 3488504003 3882442981'
	'Stimulus 3 : WB Noise AM: Depth = 1, Modulation = 16 (Hz), randn_seed = 992298650 3256070655'
	'Stimulus 4 : WB Noise AM: Depth = 1, Modulation = 32 (Hz), randn_seed = 3743956551 2856656784'
	'Stimulus 5 : WB Noise AM: Depth = 1, Modulation = 64 (Hz), randn_seed = 616822435 3517892253'
	'Stimulus 6 : WB Noise AM: Depth = 1, Modulation = 128 (Hz), randn_seed = 1425039446 3655420512'
	'Stimulus 7 : WB Noise AM: Depth = 1, Modulation = 256 (Hz), randn_seed = 3242668480 2790856395'
	'Stimulus 8 : WB Noise AM: Depth = 1, Modulation = 512 (Hz), randn_seed = 1276110405 2566645458'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 500;
x.iti_max = 1000;
x.iti = [
	833	965	739	735	591	644	507	746
	603	742	604	652	732	565	759	895
	907	755	574	598	522	860	663	889
	946	857	848	797	883	953	542	623
	822	709	879	516	613	894	587	735
 ];
x.attenuation = [	50.00	];
x.spkr_number = [	2.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	915089
	5	1	1	984867
	5	1	1	1061008
	5	1	1	1070885
	5	1	1	1080447
	5	1	1	1102347
	5	1	1	1178345
	5	1	1	1403925
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	3	1	1	-1
	3	1	1	527757
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	719464
	1	1	1	723143
	1	1	1	983862
	1	1	1	1307499
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	1	1	-1
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	8	1	1	-1
	8	1	1	350535
	8	1	1	1101267
	8	1	1	1120747
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	2	1	1	-1
	2	1	1	1906869
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	7	2	1	-1
	7	2	1	960867
	7	2	1	1223184
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	2	2	1	-1
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	8	2	1	-1
	8	2	1	669002
	8	2	1	1591212
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	4	2	1	-1
	4	2	1	231615
	4	2	1	254755
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	1	2	1	-1
	1	2	1	808844
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	6	2	1	-1
	6	2	1	1572708
	6	2	1	1579809
	6	2	1	1590228
	6	2	1	1594909
	6	2	1	1610330
	6	2	1	1613589
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	3	2	1	-1
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	3	1	-1
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	2	3	1	-1
	2	3	1	337354
	2	3	1	737149
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	6	4	1	-1
	6	4	1	36228
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	8	4	1	-1
	8	4	1	291091
	8	4	1	365771
	8	4	1	396010
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	3	4	1	-1
	3	4	1	302848
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	7	4	1	-1
	7	4	1	1624381
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	4	4	1	-1
	4	4	1	1658716
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	1	166882
	2	4	1	332819
	2	4	1	338598
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	1	4	1	-1
	1	4	1	197998
	1	4	1	201477
	1	4	1	204856
	1	4	1	211478
	1	4	1	215619
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	3	5	1	-1
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	5	5	1	-1
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	2	5	1	-1
	2	5	1	94326
	2	5	1	108608
	2	5	1	1293195
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	1	5	1	-1
	1	5	1	414657
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	7	5	1	-1
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	4	5	1	-1
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE