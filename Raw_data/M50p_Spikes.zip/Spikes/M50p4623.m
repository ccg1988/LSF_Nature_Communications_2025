function x = M50p4623()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 13:23:02';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	10.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	2.0000	11.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	3.0000	12.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	4.0000	13.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	5.0000	14.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	6.0000	15.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
	7.0000	16.0000	30.0000	1.0000	200.0000	20.0000	1.0000	1327491021.0000	2054878376.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 5 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 6 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
	'Stimulus 7 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 1327491021 2054878376'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	126	216	13	90	119	239	214
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	10.00	11.00	12.00	13.00	14.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	2	1	1	-1
	2	1	1	88571
	2	1	1	96671
	2	1	1	141251
	2	1	1	167909
	2	1	1	188671
	2	1	1	217209
	2	1	1	346567
	2	1	1	353406
	2	1	1	422948
	2	1	1	445448
	2	1	1	457628
	2	1	1	479228
	2	1	1	490347
	2	1	1	633046
	2	1	1	651783
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	1	1	-1
	6	1	1	226482
	6	1	1	234042
	6	1	1	256101
	6	1	1	280381
	6	1	1	289961
	6	1	1	310260
	6	1	1	313460
	6	1	1	352923
	6	1	1	376619
	6	1	1	383620
	6	1	1	494719
	6	1	1	533399
	6	1	1	556899
	6	1	1	652337
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	3	1	1	-1
	3	1	1	47780
	3	1	1	62478
	3	1	1	74456
	3	1	1	77797
	3	1	1	92756
	3	1	1	98116
	3	1	1	104778
	3	1	1	110536
	3	1	1	114837
	3	1	1	121757
	3	1	1	215295
	3	1	1	221695
	3	1	1	227014
	3	1	1	232975
	3	1	1	238917
	3	1	1	242756
	3	1	1	246014
	3	1	1	251714
	3	1	1	258754
	3	1	1	262635
	3	1	1	267854
	3	1	1	273396
	3	1	1	278215
	3	1	1	282015
	3	1	1	294197
	3	1	1	306496
	3	1	1	321275
	3	1	1	344615
	3	1	1	355116
	3	1	1	363033
	3	1	1	369594
	3	1	1	392493
	3	1	1	403435
	3	1	1	473512
	3	1	1	489874
	3	1	1	540651
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	1	4016
	5	1	1	17216
	5	1	1	77333
	5	1	1	85314
	5	1	1	143694
	5	1	1	168574
	5	1	1	222691
	5	1	1	232993
	5	1	1	250712
	5	1	1	259772
	5	1	1	263492
	5	1	1	270573
	5	1	1	275731
	5	1	1	298292
	5	1	1	307873
	5	1	1	317330
	5	1	1	333051
	5	1	1	344093
	5	1	1	353671
	5	1	1	400353
	5	1	1	409430
	5	1	1	423231
	5	1	1	487509
	5	1	1	565389
	5	1	1	582508
	5	1	1	591409
	5	1	1	599150
	5	1	1	617107
	5	1	1	622650
	5	1	1	662970
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	1	1	-1
	4	1	1	2989
	4	1	1	5871
	4	1	1	9749
	4	1	1	220887
	4	1	1	234066
	4	1	1	245247
	4	1	1	253049
	4	1	1	262626
	4	1	1	275907
	4	1	1	304547
	4	1	1	317347
	4	1	1	327087
	4	1	1	344187
	4	1	1	354706
	4	1	1	379084
	4	1	1	398486
	4	1	1	420985
	4	1	1	466964
	4	1	1	533583
	4	1	1	574343
	4	1	1	605583
	4	1	1	618625
	4	1	1	632762
	4	1	1	650723
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	1	1	1	-1
	1	1	1	9644
	1	1	1	63923
	1	1	1	121724
	1	1	1	199583
	1	1	1	217344
	1	1	1	227223
	1	1	1	231304
	1	1	1	250583
	1	1	1	263141
	1	1	1	278381
	1	1	1	284282
	1	1	1	311882
	1	1	1	344702
	1	1	1	353883
	1	1	1	363521
	1	1	1	478980
	1	1	1	561499
	1	1	1	584739
	1	1	1	614217
	1	1	1	623120
	1	1	1	630419
	1	1	1	642019
	1	1	1	645900
	1	1	1	688576
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	7	1	1	-1
	7	1	1	71840
	7	1	1	85339
	7	1	1	189777
	7	1	1	193397
	7	1	1	204316
	7	1	1	211336
	7	1	1	215616
	7	1	1	231717
	7	1	1	238278
	7	1	1	243656
	7	1	1	250837
	7	1	1	258276
	7	1	1	263179
	7	1	1	268097
	7	1	1	276357
	7	1	1	282797
	7	1	1	290536
	7	1	1	303815
	7	1	1	319435
	7	1	1	330337
	7	1	1	336617
	7	1	1	342997
	7	1	1	355077
	7	1	1	360636
	7	1	1	366816
	7	1	1	379135
	7	1	1	390717
	7	1	1	406875
	7	1	1	416115
	7	1	1	506115
	7	1	1	513814
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE