function x = M50p4630()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 13:30:11';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	7.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
	2.0000	8.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
	3.0000	9.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
	4.0000	10.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
	5.0000	11.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
	6.0000	12.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3732698791.0000	2529022145.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
	'Stimulus 5 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
	'Stimulus 6 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3732698791 2529022145'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	227	92	0	232	163	149
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	7.00	8.00	9.00	10.00	11.00	12.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	5	1	1	-1
	5	1	1	119761
	5	1	1	125601
	5	1	1	138601
	5	1	1	217818
	5	1	1	224299
	5	1	1	256859
	5	1	1	405318
	5	1	1	419156
	5	1	1	434756
	5	1	1	452436
	5	1	1	476456
	5	1	1	488957
	5	1	1	502317
	5	1	1	514616
	5	1	1	522636
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	39457
	2	1	1	327811
	2	1	1	391511
	2	1	1	419091
	2	1	1	436211
	2	1	1	439491
	2	1	1	445411
	2	1	1	483851
	2	1	1	491609
	2	1	1	510612
	2	1	1	617749
	2	1	1	676829
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	6	1	1	-1
	6	1	1	219849
	6	1	1	244131
	6	1	1	275749
	6	1	1	301070
	6	1	1	309490
	6	1	1	357668
	6	1	1	381950
	6	1	1	384727
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	4	1	1	-1
	4	1	1	12828
	4	1	1	17208
	4	1	1	43965
	4	1	1	102565
	4	1	1	114305
	4	1	1	131026
	4	1	1	159005
	4	1	1	167785
	4	1	1	173625
	4	1	1	195265
	4	1	1	206764
	4	1	1	223826
	4	1	1	232065
	4	1	1	249063
	4	1	1	258783
	4	1	1	274783
	4	1	1	280585
	4	1	1	318764
	4	1	1	325405
	4	1	1	341103
	4	1	1	362705
	4	1	1	420284
	4	1	1	499823
	4	1	1	603662
	4	1	1	611341
	4	1	1	618820
	4	1	1	628860
	4	1	1	685402
	4	1	1	694221
	4	1	2	-1
	4	1	2	53267
	4	1	2	122909
	4	1	2	129527
	4	1	2	157587
	4	1	2	497924
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	8620
	3	1	1	22160
	3	1	1	50738
	3	1	1	60038
	3	1	1	98499
	3	1	1	102858
	3	1	1	106959
	3	1	1	110539
	3	1	1	114338
	3	1	1	136857
	3	1	1	225378
	3	1	1	234179
	3	1	1	246396
	3	1	1	267116
	3	1	1	287656
	3	1	1	313217
	3	1	1	417675
	3	1	1	443734
	3	1	1	452594
	3	1	1	513933
	3	1	1	567374
	3	1	1	582753
	3	1	1	586633
	3	1	1	640234
	3	1	1	676293
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	1	1	1	-1
	1	1	1	61877
	1	1	1	87837
	1	1	1	99416
	1	1	1	135317
	1	1	1	197436
	1	1	1	203776
	1	1	1	207915
	1	1	1	213455
	1	1	1	222757
	1	1	1	261116
	1	1	1	365995
	1	1	1	415414
	1	1	1	433173
	1	1	1	450933
	1	1	1	518312
	1	1	1	522933
	1	1	1	606291
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE