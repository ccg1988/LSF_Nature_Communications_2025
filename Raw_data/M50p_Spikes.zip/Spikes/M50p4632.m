function x = M50p4632()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 13:31:22';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	13.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3244750429.0000	4149092153.0000
	2.0000	14.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3244750429.0000	4149092153.0000
	3.0000	15.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3244750429.0000	4149092153.0000
	4.0000	16.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3244750429.0000	4149092153.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3244750429 4149092153'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3244750429 4149092153'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3244750429 4149092153'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3244750429 4149092153'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	288	128	248	165
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	13.00	14.00	15.00	16.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	2	1	1	-1
	2	1	1	40045
	2	1	1	70745
	2	1	1	137583
	2	1	1	235781
	2	1	1	284699
	2	1	1	295621
	2	1	1	311460
	2	1	1	326140
	2	1	1	359962
	2	1	1	372781
	2	1	1	392800
	2	1	1	403059
	2	1	1	417219
	2	1	1	453638
	2	1	1	474418
	2	1	1	635436
	2	1	2	-1
	2	1	2	544641
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	96817
	1	1	1	107176
	1	1	1	221775
	1	1	1	307276
	1	1	1	316517
	1	1	1	329796
	1	1	1	485994
	1	1	1	501152
	1	1	1	557872
	1	1	1	562973
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	1	1	-1
	3	1	1	4132
	3	1	1	314346
	3	1	1	410327
	3	1	1	424946
	3	1	1	457865
	3	1	1	475607
	3	1	1	544287
	3	1	1	645904
	3	1	1	676124
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	4	1	1	-1
	4	1	1	19524
	4	1	1	76285
	4	1	1	89283
	4	1	1	132722
	4	1	1	150242
	4	1	1	166065
	4	1	1	182203
	4	1	1	188564
	4	1	1	210083
	4	1	1	216123
	4	1	1	232522
	4	1	1	298061
	4	1	1	314542
	4	1	1	328163
	4	1	1	335140
	4	1	1	365960
	4	1	1	414182
	4	1	1	466079
	4	1	1	631197
	4	1	1	644958
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE