function x = M50p4621()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 13:20:58';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	2.0000	3.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	3.0000	4.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	4.0000	5.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	5.0000	6.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	6.0000	7.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
	7.0000	8.0000	30.0000	1.0000	200.0000	20.0000	1.0000	3679028835.0000	3490952898.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 5 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 6 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
	'Stimulus 7 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 3679028835 3490952898'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	143	84	94	184	132	168	294
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	6.00	7.00	8.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	90913
	4	1	1	122492
	4	1	1	220331
	4	1	1	234770
	4	1	1	239890
	4	1	1	255051
	4	1	1	258669
	4	1	1	263111
	4	1	1	275213
	4	1	1	283271
	4	1	1	291270
	4	1	1	298569
	4	1	1	318511
	4	1	1	326611
	4	1	1	332270
	4	1	1	348189
	4	1	1	360130
	4	1	1	366888
	4	1	1	389028
	4	1	1	399970
	4	1	1	413770
	4	1	1	430750
	4	1	1	470108
	4	1	1	605388
	4	1	1	613288
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	7	1	1	-1
	7	1	1	46388
	7	1	1	56288
	7	1	1	61387
	7	1	1	72506
	7	1	1	78785
	7	1	1	83185
	7	1	1	90245
	7	1	1	116445
	7	1	1	223984
	7	1	1	269384
	7	1	1	310304
	7	1	1	366683
	7	1	1	445701
	7	1	1	473941
	7	1	1	514562
	7	1	1	530881
	7	1	1	644879
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	3	1	1	-1
	3	1	1	109997
	3	1	1	185317
	3	1	1	220757
	3	1	1	235996
	3	1	1	247796
	3	1	1	256335
	3	1	1	289056
	3	1	1	296815
	3	1	1	324234
	3	1	1	330276
	3	1	1	334694
	3	1	1	357834
	3	1	1	364114
	3	1	1	375514
	3	1	1	383756
	3	1	1	395976
	3	1	1	415413
	3	1	1	472133
	3	1	1	476494
	3	1	1	519694
	3	1	1	527813
	3	1	1	577773
	3	1	1	620491
	3	1	1	629431
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	5	1	1	-1
	5	1	1	27195
	5	1	1	39455
	5	1	1	52473
	5	1	1	63233
	5	1	1	65636
	5	1	1	102454
	5	1	1	121555
	5	1	1	142494
	5	1	1	174654
	5	1	1	186254
	5	1	1	221033
	5	1	1	247493
	5	1	1	305512
	5	1	1	358812
	5	1	1	375210
	5	1	1	454509
	5	1	1	579068
	5	1	1	622108
	5	1	1	642187
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	70368
	2	1	1	117448
	2	1	1	156508
	2	1	1	166307
	2	1	1	220767
	2	1	1	224987
	2	1	1	229029
	2	1	1	232509
	2	1	1	235628
	2	1	1	240167
	2	1	1	245367
	2	1	1	250527
	2	1	1	256646
	2	1	1	263888
	2	1	1	268787
	2	1	1	272186
	2	1	1	279328
	2	1	1	284446
	2	1	1	292465
	2	1	1	305527
	2	1	1	311328
	2	1	1	321686
	2	1	1	330706
	2	1	1	341185
	2	1	1	355225
	2	1	1	360528
	2	1	1	376865
	2	1	1	383084
	2	1	1	394126
	2	1	1	417065
	2	1	1	538663
	2	1	1	590862
	2	1	1	688941
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	96942
	1	1	1	101164
	1	1	1	107944
	1	1	1	117123
	1	1	1	227583
	1	1	1	233923
	1	1	1	240682
	1	1	1	249422
	1	1	1	258002
	1	1	1	263622
	1	1	1	280940
	1	1	1	299302
	1	1	1	336880
	1	1	1	366520
	1	1	1	384900
	1	1	1	420781
	1	1	1	506220
	1	1	1	579399
	1	1	1	637880
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	6	1	1	-1
	6	1	1	18400
	6	1	1	29860
	6	1	1	54478
	6	1	1	68898
	6	1	1	79220
	6	1	1	96439
	6	1	1	169097
	6	1	1	184698
	6	1	1	195238
	6	1	1	224177
	6	1	1	238859
	6	1	1	256936
	6	1	1	276156
	6	1	1	417815
	6	1	1	491873
	6	1	1	620832
	6	1	1	648612
	6	1	1	674472
	6	1	1	687373
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE