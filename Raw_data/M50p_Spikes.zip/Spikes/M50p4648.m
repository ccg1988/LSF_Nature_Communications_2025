function x = M50p4648()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '24-Jun-2005 14:00:36';
x.hemisphere = 'Left';
x.hole_number = 28;
x.track_number = 4;
x.starting_depth = 5000;
x.first_spike = 5844;
x.unit_depth = 6407;
x.unit_number = 688;
x.cf = 1.4000;
x.threshold = 20.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	1.0000	200.0000	20.0000	1.0000	87208113.0000	668661555.0000
	2.0000	3.0000	30.0000	1.0000	200.0000	20.0000	1.0000	87208113.0000	668661555.0000
	3.0000	4.0000	30.0000	1.0000	200.0000	20.0000	1.0000	87208113.0000	668661555.0000
	4.0000	5.0000	30.0000	1.0000	200.0000	20.0000	1.0000	87208113.0000	668661555.0000
	5.0000	6.0000	30.0000	1.0000	200.0000	20.0000	1.0000	87208113.0000	668661555.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 87208113 668661555'
	'Stimulus 2 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 87208113 668661555'
	'Stimulus 3 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 87208113 668661555'
	'Stimulus 4 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 87208113 668661555'
	'Stimulus 5 : NOISE: Center Frequency  20       Bandwidth  1, randn_seed 87208113 668661555'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	276	26	38	79	265
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	3.00	4.00	5.00	6.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	69339
	4	1	1	119360
	4	1	1	135677
	4	1	1	159337
	4	1	1	215936
	4	1	1	235935
	4	1	1	246116
	4	1	1	248735
	4	1	1	261658
	4	1	1	286236
	4	1	1	328576
	4	1	1	382955
	4	1	1	416914
	4	1	1	450835
	4	1	1	539793
	4	1	1	542734
	4	1	1	560032
	4	1	1	683613
	4	1	2	-1
	4	1	2	20800
	4	1	2	44879
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	5	1	1	-1
	5	1	1	227471
	5	1	1	272071
	5	1	1	431809
	5	1	1	514708
	5	1	1	630487
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	2	1	1	-1
	2	1	1	11487
	2	1	1	17048
	2	1	1	286385
	2	1	1	468125
	2	1	1	485003
	2	1	1	507723
	2	1	1	629822
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	16625
	1	1	1	27185
	1	1	1	215985
	1	1	1	227803
	1	1	1	240624
	1	1	1	260243
	1	1	1	270143
	1	1	1	282904
	1	1	1	291703
	1	1	1	304302
	1	1	1	324861
	1	1	1	358901
	1	1	1	418341
	1	1	1	500182
	1	1	1	566980
	1	1	1	575820
	1	1	1	596759
	1	1	1	600639
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	3	1	1	-1
	3	1	1	21558
	3	1	1	38658
	3	1	1	87517
	3	1	1	218917
	3	1	1	269214
	3	1	1	289256
	3	1	1	342154
	3	1	1	358973
	3	1	1	373094
	3	1	1	393934
	3	1	1	440313
	3	1	1	561273
	3	1	2	-1
	3	1	2	688652
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE