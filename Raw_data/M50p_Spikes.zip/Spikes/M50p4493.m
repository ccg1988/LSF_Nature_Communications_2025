function x = M50p4493()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'WB-noise';
x.analysis_code = 61;
x.animal = 'M50p';
x.datetime = '16-Jun-2005 11:15:06';
x.hemisphere = 'Left';
x.hole_number = 27;
x.track_number = 11;
x.starting_depth = 4000;
x.first_spike = 4257;
x.unit_depth = 4445;
x.unit_number = 681;
x.cf = 1.8000;
x.threshold = 30.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = 'Single-Unit';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 1;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 1'
'Signal = White Noise'
'Presentation Mode = Random'
'Duration = 200'
'Rise/Fall Time = 5'
'InterStimulus Interval = 1000'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' NOISE Center Frequency' ' Bandwidth' ' randn_seed' ' randn_seed' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	2.0000	30.0000	3.0000	200.0000	10.0000	2.0000	3211014007.0000	508115680.0000
	2.0000	14.0000	30.0000	3.0000	200.0000	10.0000	2.0000	3211014007.0000	508115680.0000
	3.0000	8.0000	30.0000	3.0000	200.0000	10.0000	2.0000	3211014007.0000	508115680.0000
	4.0000	3.0000	30.0000	3.0000	200.0000	10.0000	2.0000	3211014007.0000	508115680.0000
	5.0000	5.0000	30.0000	3.0000	200.0000	10.0000	2.0000	3211014007.0000	508115680.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3211014007 508115680'
	'Stimulus 2 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3211014007 508115680'
	'Stimulus 3 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3211014007 508115680'
	'Stimulus 4 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3211014007 508115680'
	'Stimulus 5 : NOISE: Center Frequency  10       Bandwidth  2, randn_seed 3211014007 508115680'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 200;
x.post_stimulus_record_time = 300;
x.iti_min = 0;
x.iti_max = 300;
x.iti = [
	102	124	236	31	152
	222	282	65	233	263
	121	88	182	31	283
 ];
x.attenuation = [	30.00	];
x.spkr_number = [	2.00	14.00	8.00	3.00	5.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	4	1	1	-1
	4	1	1	55876
	4	1	1	240654
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	3	1	1	-1
	3	1	1	259313
	3	1	1	313211
	3	1	1	568288
	3	1	2	-1
	3	1	2	565369
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	2	1	1	-1
	2	1	1	447442
	2	1	1	554904
	2	1	1	581122
	2	1	1	585961
	2	1	2	-1
	2	1	2	247166
	2	1	2	436465
	2	1	2	453685
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	5	1	1	-1
	5	1	1	201883
	5	1	1	528679
	5	1	1	627579
	5	1	1	629839
	5	1	2	-1
	5	1	2	109323
	5	1	2	200640
	5	1	2	363581
	5	1	2	431420
	5	1	2	675899
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	1	1	1	-1
	1	1	1	662691
	1	1	2	-1
	1	1	2	61939
	1	1	2	79579
	1	1	2	176718
	1	1	2	233637
	1	1	2	242236
	1	1	2	246537
	1	1	2	265557
	1	1	2	276596
	1	1	2	297137
	1	1	2	318816
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	4	2	1	-1
	4	2	1	157694
	4	2	1	195672
	4	2	2	-1
	4	2	2	23695
	4	2	2	80295
	4	2	2	331933
	4	2	2	363071
	4	2	2	379511
	4	2	2	417552
	4	2	2	434292
	4	2	2	439270
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	2	2	1	-1
	2	2	1	22109
	2	2	1	24349
	2	2	1	78527
	2	2	1	93708
	2	2	1	181525
	2	2	1	274924
	2	2	1	313666
	2	2	1	322566
	2	2	1	348205
	2	2	1	554243
	2	2	1	647623
	2	2	2	-1
	2	2	2	37509
	2	2	2	47208
	2	2	2	63209
	2	2	2	89007
	2	2	2	97009
	2	2	2	132148
	2	2	2	189927
	2	2	2	193625
	2	2	2	213405
	2	2	2	290065
	2	2	2	414446
	2	2	2	433303
	2	2	2	437685
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	5	2	1	-1
	5	2	1	73537
	5	2	1	132997
	5	2	1	596413
	5	2	1	598633
	5	2	1	606173
	5	2	1	609054
	5	2	1	675653
	5	2	1	692172
	5	2	2	-1
	5	2	2	8360
	5	2	2	21280
	5	2	2	78119
	5	2	2	139558
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	1	2	1	-1
	1	2	1	8072
	1	2	1	40492
	1	2	1	69509
	1	2	1	72291
	1	2	1	79370
	1	2	1	221331
	1	2	1	239230
	1	2	1	242129
	1	2	1	261529
	1	2	1	265430
	1	2	1	267307
	1	2	1	353528
	1	2	1	355268
	1	2	1	382308
	1	2	1	415107
	1	2	1	448329
	1	2	1	655105
	1	2	1	671806
	1	2	2	-1
	1	2	2	248170
	1	2	2	256572
	1	2	2	280229
	1	2	2	288151
	1	2	2	363689
	1	2	2	408848
	1	2	2	424549
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	3	2	1	-1
	3	2	1	71104
	3	2	1	148825
	3	2	1	195745
	3	2	1	211923
	3	2	1	212942
	3	2	1	261923
	3	2	1	280283
	3	2	1	319462
	3	2	1	369282
	3	2	1	370903
	3	2	1	390822
	3	2	1	413322
	3	2	1	453702
	3	2	1	461281
	3	2	2	-1
	3	2	2	206825
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	3	1	-1
	1	3	1	89759
	1	3	1	160638
	1	3	1	184598
	1	3	2	-1
	1	3	2	220558
	1	3	2	259679
	1	3	2	282378
	1	3	2	307540
	1	3	2	372758
	1	3	2	400178
	1	3	2	438238
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	4	3	1	-1
	4	3	2	-1
	4	3	2	290234
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	5	3	1	-1
	5	3	1	17953
	5	3	1	100876
	5	3	1	109555
	5	3	1	174013
	5	3	1	551350
	5	3	1	560990
	5	3	1	588031
	5	3	1	591968
	5	3	2	-1
	5	3	2	434433
	5	3	2	537669
	5	3	2	584550
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	3	3	1	-1
	3	3	1	74726
	3	3	1	119926
	3	3	1	152984
	3	3	1	188664
	3	3	1	193406
	3	3	1	204564
	3	3	1	239406
	3	3	1	244384
	3	3	1	400644
	3	3	1	439422
	3	3	1	548680
	3	3	1	549920
	3	3	1	698559
	3	3	2	-1
	3	3	2	72167
	3	3	2	92327
	3	3	2	146147
	3	3	2	212026
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	1	19622
	2	3	1	25440
	2	3	1	72479
	2	3	1	79299
	2	3	1	104658
	2	3	1	112738
	2	3	1	133099
	2	3	1	438537
	2	3	1	453596
	2	3	1	456476
	2	3	1	630875
	2	3	2	-1
	2	3	2	28021
	2	3	2	98560
	2	3	2	250379
	2	3	2	289158
	2	3	2	416917
	2	3	2	428517
	2	3	2	435777
	2	3	2	442817
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE