function x = M43s4022()
% Data File Format Version 4.00
% Returns structure with header and data for this file

x = []; % initialize structure

% BEGIN HEADER
x.chamber = 1;
x.data_format = 4.00;
x.crown_amplifier_setting = 16;
x.ampl_dBSPL_at_1000Hz_0dB_att = 90;
x.analysis_type = 'sAM';
x.analysis_code = 51;
x.animal = 'M43s';
x.datetime = '01-Feb-2007 16:55:42';
x.hemisphere = 'Right';
x.hole_number = 21;
x.track_number = 5;
x.starting_depth = 14000;
x.first_spike = 14986;
x.unit_depth = 15134;
x.unit_number = 256;
x.cf = -1.0000;
x.threshold = -1.0000;
x.latency = -1.0000;
x.bandwidth = -1.0000;
x.spikesort_ch1 = 'Single-Unit';
x.spikesort_ch2 = '';
x.spikesort_ch3 = '';
x.spikesort_ch4 = '';
x.spikesort_ch5 = '';
x.spikesort_ch6 = '';
x.spikesort_ch7 = '';
x.spikesort_ch8 = '';
x.nstim = 8;
x.general_header = {
 % COMMON HEADER INFO
'Number of Stimuli = 8'
'Sinusoidal AM, Change Modulation Frequency'
'Presentation Mode = Random'
'Duration = 1000'
'InterStimulus Interval = 500'
'InterStimulus Interval = 1000'
'Frequency is being changed'
'Bandwidth is in Octaves'
};
x.stimulus_tags_ch1 = { 'stim_num' 'spkr' 'attn(dB)' 'rep' 'len(ms)' ' Sinusoidal AM CF' ' KHz Depth' ' Modulation' };
x.stimulus_ch1 = [
 % BEGIN STIMULUS CH 1
	1.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	4.0000
	2.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	8.0000
	3.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	16.0000
	4.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	32.0000
	5.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	64.0000
	6.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	128.0000
	7.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	256.0000
	8.0000	7.0000	10.0000	5.0000	1000.0000	0.5000	1.0000	512.0000
 % END STIMULUS CH 1
 ];
x.user_stimulus_desc_ch1 = {
	'Stimulus 1 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 4 (Hz)'
	'Stimulus 2 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 8 (Hz)'
	'Stimulus 3 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 16 (Hz)'
	'Stimulus 4 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 32 (Hz)'
	'Stimulus 5 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 64 (Hz)'
	'Stimulus 6 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 128 (Hz)'
	'Stimulus 7 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 256 (Hz)'
	'Stimulus 8 : Sinusoidal AM: CF = 0.5 (KHz), Depth = 1, Modulation = 512 (Hz)'
 };
x.user_parms_formatted_ch1 = 'true';
x.stimulus_tags_ch2 = { };
x.stimulus_ch2 = [
 % BEGIN STIMULUS CH 2
 % END STIMULUS CH 2
 ];
x.user_stimulus_desc_ch2 = {
 };
x.user_parms_formatted_ch2 = 'true';
x.presentation_mode = 'Random';
x.pre_stimulus_record_time = 500;
x.post_stimulus_record_time = 500;
x.iti_min = 0;
x.iti_max = 0;
x.iti = [
	0
 ];
x.attenuation = [	10.00	];
x.spkr_number = [	7.00	];
x.spkr_tags = { 'speaker' 'azimuth' 'elevation' 'type' };
x.spkr = {
 % BEGIN SPEAKER
 % END SPEAKER
 };
x.data_tags = { 'stim_num' 'stim_rep' 'ch_num' 'event_time_microsecs' };
x.data = [
 % BEGIN DATA
	2	1	1	-1
	2	1	1	573275
	2	1	1	585913
	2	1	1	687352
	2	1	1	936550
	2	1	1	1053827
	2	1	1	1182067
	2	1	1	1197946
	2	1	1	1319905
	2	1	2	-1
	2	1	3	-1
	2	1	4	-1
	2	1	5	-1
	2	1	6	-1
	2	1	7	-1
	1	1	1	-1
	1	1	1	590341
	1	1	1	1326991
	1	1	1	1352613
	1	1	2	-1
	1	1	3	-1
	1	1	4	-1
	1	1	5	-1
	1	1	6	-1
	1	1	7	-1
	7	1	1	-1
	7	1	2	-1
	7	1	3	-1
	7	1	4	-1
	7	1	5	-1
	7	1	6	-1
	7	1	7	-1
	5	1	1	-1
	5	1	2	-1
	5	1	3	-1
	5	1	4	-1
	5	1	5	-1
	5	1	6	-1
	5	1	7	-1
	4	1	1	-1
	4	1	1	559001
	4	1	1	613562
	4	1	1	695139
	4	1	2	-1
	4	1	3	-1
	4	1	4	-1
	4	1	5	-1
	4	1	6	-1
	4	1	7	-1
	8	1	1	-1
	8	1	1	585728
	8	1	2	-1
	8	1	3	-1
	8	1	4	-1
	8	1	5	-1
	8	1	6	-1
	8	1	7	-1
	3	1	1	-1
	3	1	1	550279
	3	1	1	558336
	3	1	1	569397
	3	1	1	586337
	3	1	1	660036
	3	1	1	687636
	3	1	1	802094
	3	1	1	812915
	3	1	1	975733
	3	1	2	-1
	3	1	3	-1
	3	1	4	-1
	3	1	5	-1
	3	1	6	-1
	3	1	7	-1
	6	1	1	-1
	6	1	2	-1
	6	1	3	-1
	6	1	4	-1
	6	1	5	-1
	6	1	6	-1
	6	1	7	-1
	2	2	1	-1
	2	2	1	557492
	2	2	1	568013
	2	2	1	574190
	2	2	1	698130
	2	2	1	806169
	2	2	1	827987
	2	2	1	1204583
	2	2	1	1332763
	2	2	2	-1
	2	2	3	-1
	2	2	4	-1
	2	2	5	-1
	2	2	6	-1
	2	2	7	-1
	4	2	1	-1
	4	2	2	-1
	4	2	3	-1
	4	2	4	-1
	4	2	5	-1
	4	2	6	-1
	4	2	7	-1
	5	2	1	-1
	5	2	2	-1
	5	2	3	-1
	5	2	4	-1
	5	2	5	-1
	5	2	6	-1
	5	2	7	-1
	8	2	1	-1
	8	2	2	-1
	8	2	3	-1
	8	2	4	-1
	8	2	5	-1
	8	2	6	-1
	8	2	7	-1
	7	2	1	-1
	7	2	2	-1
	7	2	3	-1
	7	2	4	-1
	7	2	5	-1
	7	2	6	-1
	7	2	7	-1
	6	2	1	-1
	6	2	2	-1
	6	2	3	-1
	6	2	4	-1
	6	2	5	-1
	6	2	6	-1
	6	2	7	-1
	3	2	1	-1
	3	2	1	567693
	3	2	1	582151
	3	2	1	819350
	3	2	1	948488
	3	2	1	1492701
	3	2	2	-1
	3	2	3	-1
	3	2	4	-1
	3	2	5	-1
	3	2	6	-1
	3	2	7	-1
	1	2	1	-1
	1	2	2	-1
	1	2	3	-1
	1	2	4	-1
	1	2	5	-1
	1	2	6	-1
	1	2	7	-1
	8	3	1	-1
	8	3	2	-1
	8	3	3	-1
	8	3	4	-1
	8	3	5	-1
	8	3	6	-1
	8	3	7	-1
	4	3	1	-1
	4	3	1	551734
	4	3	1	712872
	4	3	2	-1
	4	3	3	-1
	4	3	4	-1
	4	3	5	-1
	4	3	6	-1
	4	3	7	-1
	6	3	1	-1
	6	3	2	-1
	6	3	3	-1
	6	3	4	-1
	6	3	5	-1
	6	3	6	-1
	6	3	7	-1
	3	3	1	-1
	3	3	1	564547
	3	3	1	584167
	3	3	1	623787
	3	3	1	633588
	3	3	1	696966
	3	3	1	774443
	3	3	1	884043
	3	3	1	1025404
	3	3	1	1059042
	3	3	1	1093202
	3	3	1	1134662
	3	3	2	-1
	3	3	3	-1
	3	3	4	-1
	3	3	5	-1
	3	3	6	-1
	3	3	7	-1
	2	3	1	-1
	2	3	1	711731
	2	3	1	1071728
	2	3	2	-1
	2	3	3	-1
	2	3	4	-1
	2	3	5	-1
	2	3	6	-1
	2	3	7	-1
	5	3	1	-1
	5	3	2	-1
	5	3	3	-1
	5	3	4	-1
	5	3	5	-1
	5	3	6	-1
	5	3	7	-1
	1	3	1	-1
	1	3	1	597445
	1	3	2	-1
	1	3	3	-1
	1	3	4	-1
	1	3	5	-1
	1	3	6	-1
	1	3	7	-1
	7	3	1	-1
	7	3	2	-1
	7	3	3	-1
	7	3	4	-1
	7	3	5	-1
	7	3	6	-1
	7	3	7	-1
	7	4	1	-1
	7	4	2	-1
	7	4	3	-1
	7	4	4	-1
	7	4	5	-1
	7	4	6	-1
	7	4	7	-1
	3	4	1	-1
	3	4	1	555189
	3	4	2	-1
	3	4	3	-1
	3	4	4	-1
	3	4	5	-1
	3	4	6	-1
	3	4	7	-1
	8	4	1	-1
	8	4	1	547876
	8	4	2	-1
	8	4	3	-1
	8	4	4	-1
	8	4	5	-1
	8	4	6	-1
	8	4	7	-1
	4	4	1	-1
	4	4	1	580944
	4	4	1	640264
	4	4	2	-1
	4	4	3	-1
	4	4	4	-1
	4	4	5	-1
	4	4	6	-1
	4	4	7	-1
	2	4	1	-1
	2	4	1	560251
	2	4	1	577392
	2	4	1	595610
	2	4	1	945467
	2	4	2	-1
	2	4	3	-1
	2	4	4	-1
	2	4	5	-1
	2	4	6	-1
	2	4	7	-1
	5	4	1	-1
	5	4	2	-1
	5	4	3	-1
	5	4	4	-1
	5	4	5	-1
	5	4	6	-1
	5	4	7	-1
	6	4	1	-1
	6	4	2	-1
	6	4	3	-1
	6	4	4	-1
	6	4	5	-1
	6	4	6	-1
	6	4	7	-1
	1	4	1	-1
	1	4	1	581750
	1	4	1	833430
	1	4	2	-1
	1	4	3	-1
	1	4	4	-1
	1	4	5	-1
	1	4	6	-1
	1	4	7	-1
	7	5	1	-1
	7	5	1	569358
	7	5	2	-1
	7	5	3	-1
	7	5	4	-1
	7	5	5	-1
	7	5	6	-1
	7	5	7	-1
	3	5	1	-1
	3	5	1	555926
	3	5	1	567964
	3	5	1	581845
	3	5	1	625645
	3	5	1	652385
	3	5	1	680482
	3	5	1	802903
	3	5	1	839082
	3	5	1	870260
	3	5	1	1225417
	3	5	1	1274139
	3	5	1	1309295
	3	5	1	1643394
	3	5	1	1727752
	3	5	2	-1
	3	5	3	-1
	3	5	4	-1
	3	5	5	-1
	3	5	6	-1
	3	5	7	-1
	2	5	1	-1
	2	5	1	573093
	2	5	1	1307524
	2	5	1	1328302
	2	5	2	-1
	2	5	3	-1
	2	5	4	-1
	2	5	5	-1
	2	5	6	-1
	2	5	7	-1
	4	5	1	-1
	4	5	1	616157
	4	5	2	-1
	4	5	3	-1
	4	5	4	-1
	4	5	5	-1
	4	5	6	-1
	4	5	7	-1
	6	5	1	-1
	6	5	2	-1
	6	5	3	-1
	6	5	4	-1
	6	5	5	-1
	6	5	6	-1
	6	5	7	-1
	5	5	1	-1
	5	5	2	-1
	5	5	3	-1
	5	5	4	-1
	5	5	5	-1
	5	5	6	-1
	5	5	7	-1
	1	5	1	-1
	1	5	1	581761
	1	5	2	-1
	1	5	3	-1
	1	5	4	-1
	1	5	5	-1
	1	5	6	-1
	1	5	7	-1
	8	5	1	-1
	8	5	2	-1
	8	5	3	-1
	8	5	4	-1
	8	5	5	-1
	8	5	6	-1
	8	5	7	-1
 % END DATA
 ];

x.trial_complete = 'true';

% END DATA FILE